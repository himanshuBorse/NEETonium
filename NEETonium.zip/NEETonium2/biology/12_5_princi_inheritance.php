 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Principles of Inheritance and Variation</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Principles of Inheritance and Variation</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Principles of Inheritance and Variation</h3>
            <p class="chapSummary">Genetics is a branch of biology which deals with principles of inheritance
and its practices. Progeny resembling the parents in morphological and
physiological features has attracted the attention of many biologists.
Mendel was the first to study this phenomenon systematically. While
studying the pattern of inheritance in pea plants of contrasting
characters, Mendel proposed the principles of inheritance, which are
today referred to as ‘Mendel’s Laws of Inheritance’. He proposed that
the ‘factors’ (later named as genes) regulating the characters are found
in pairs known as alleles. He observed that the expression of the
characters in the offspring follow a definite pattern in different–first
generations (F1
), second (F2
) and so on. Some characters are dominant
over others. The dominant characters are expressed when factors are
in heterozygous condition (Law of Dominance). The recessive characters
are only expressed in homozygous conditions. The characters never
blend in heterozygous condition. A recessive character that was not
expressed in heterozygous conditon may be expressed again when it
becomes homozygous. Hence, characters segregate while formation of
gametes (Law of Segregation).
Not all characters show true dominance. Some characters show
incomplete, and some show co-dominance. When Mendel studied the
inheritance of two characters together, it was found that the factors
independently assort and combine in all permutations and
combinations (Law of Independent Assortment). Different combinations
of gametes are theoretically represented in a square tabular form known
as ‘Punnett Square’. The factors (now known as gene) on chromosomes
regulating the characters are called the genotype and the physical
expression of the chraracters is called phenotype.
After knowing that the genes are located on the chromosomes, a
good correlation was drawn between Mendel’s laws : segregation and
assortment of chromosomes during meiosis. The Mendel’s laws were
extended in the form of ‘Chromosomal Theory of Inheritance’. Later, it
was found that Mendel’s law of independent assortment does not hold
true for the genes that were located on the same chromosomes. These
genes were called as ‘linked genes’. Closely located genes assorted
together, and distantly located genes, due to recombination, assorted
independently. Linkage maps, therefore, corresponded to arrangement
of genes on a chromosome.
Many genes were linked to sexes also, and called as sex-linked
genes. The two sexes (male and female) were found to have a set of
chromosomes which were common, and another set which was
different. The chromosomes which were different in two sexes were
named as sex chromosomes. The remaining set was named as
autosomes. In humans, a normal female has 22 pairs of autosomes
and a pair of sex chromosomes (XX). A male has 22 pairs of autosomes
and a pair of sex chromosome as XY. In chicken, sex chromosomes in
male are ZZ, and in females are ZW.
Mutation is defined as change in the genetic material. A point
mutation is a change of a single base pair in DNA. Sickle-cell anemia is
caused due to change of one base in the gene coding for beta-chain of
hemoglobin. Inheritable mutations can be studied by generating a
pedigree of a family. Some mutations involve changes in whole set of
chromosomes (polyploidy) or change in a subset of chromosome number
(aneuploidy). This helped in understanding the mutational basis of
genetic disorders. Down’s syndrome is due to trisomy of chromosome 21,
where there is an extra copy of chromosome 21 and consequently the
total number of chromosome becomes 47. In Turner’s syndrome, one X
chromosome is missing and the sex chromosome is as XO, and in
Klinefelter’s syndrome, the condition is XXY. These can be easily studied
by analysis of Karyotypes.
</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->