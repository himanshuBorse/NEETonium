 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Transport in Plants</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Transport in Plants</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Transport in Plants</h3>
            <p class="chapSummary">Plants obtain a variety of inorganic elements (ions) and salts from their
surroundings especially from water and soil. The movement of these nutrients
from environment into the plant as well as from one plant cell to another plant cell
essentially involves movement across a cell membrane. Transport across cell
membrane can be through diffusion, facilitated transport or active transport. Water
and minerals absorbed by roots are transported by xylem and the organic material
synthesised in the leaves is transported to other parts of plant through phloem.
Passive transport (diffusion, osmosis) and active transport are the two modes
of nutrient transport across cell membranes in living organisms. In passive
transport, nutrients move across the membrane by diffusion, without any use of
energy as it is always down the concentration gradient and hence entropy driven.
This diffusion of substances depends on their size, solubility in water or organic
solvents. Osmosis is the special type of diffusion of water across a selectively
permeable membrane which depends on pressure gradient and concentration
gradient. In active transport, energy in the form of ATP is utilised to pump
molecules against a concentration gradient across membranes. Water potential is
the potential energy of water molecules which helps in the movement of water. It is
determined by solute potential and pressure potential. The osmotic behaviour of
cells depends on the surrounding solution. If the surrounding solution of the cell
is hypertonic, it gets plasmolysed. The absorption of water by seeds and drywood
takes place by a special type of diffusion called imbibition.
In higher plants, there is a vascular system comprising of xylem and phloem,
responsible for translocation. Water minerals and food cannot be moved within
the body of a plant by diffusion alone. They are therefore, transported by a mass
flow system – movement of substance in bulk from one point to another as a
result of pressure differences between the two points.
Water absorbed by root hairs moves into the root tissue by two distinct
pathways, i.e., apoplast and symplast. Various ions, and water from soil can be
transported upto a small height in stems by root pressure. Transpiration pull
model is the most acceptable to explain the transport of water. Transpiration is
the loss of water in the form of vapours from the plant parts through stomata.
Temperature, light, humidity, wind speed and number of stomata affect the rate
of transpiration. Excess water is also removed through tips of leaves of plants by
guttation.
Phloem is responsible for transport of food (primarily) sucrose from the source
to the sink. The translocation in phloem is bi-directional; the source-sink
relationship is variable. The translocation in phloem is explained by the pressureflow hypothesis.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->