 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Sexual Reporduction in Flowering Plants</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Sexual Reporduction in Flowering Plants</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Sexual Reporduction in Flowering Plants</h3>
            <p class="chapSummary">Flowers are the seat of sexual reproduction in angiosperms. In the flower,
androecium consisting of stamens represents the male reproductive
organs and gynoecium consisting of pistils represents the female
reproductive organs.
A typical anther is bilobed, dithecous and tetrasporangiate. Pollen
grains develop inside the microsporangia. Four wall layers, the
epidermis, endothecium, middle layers and the tapetum surround the
microsporangium. Cells of the sporogenous tissue lying in the centre of
the microsporangium, undergo meiosis (microsporogenesis) to form
tetrads of microspores. Individual microspores mature into pollen grains.
Pollen grains represents the male gametophytic generation. The
pollen grains have a two-layered wall, the outer exine and inner intine.
The exine is made up of sporopollenin and has germ pores. Pollen grains
may have two cells (a vegetative cell and generative cell) or three cells (a
vegetative cell and two male gametes) at the time of shedding.
The pistil has three parts – the stigma, style and the ovary. Ovules
are present in the ovary. The ovules have a stalk called funicle, protective
integument(s), and an opening called micropyle. The central tissue is
the nucellus in which the archesporium differentiates. A cell of the
archesporium, the megaspore mother cell divides meiotically and one of
the megaspores forms the embryo sac (the female gametophyte). The
mature embryo sac is 7-celled and 8-nucleate. At the micropylar end is
the egg apparatus consisting of two synergids and an egg cell. At the
chalazal end are three antipodals. At the centre is a large central cell
with two polar nuclei.
Pollination is the mechanism to transfer pollen grains from the
anther to the stigma. Pollinating agents are either abiotic (wind and
water) or biotic (animals).
Pollen-pistil interaction involves all events from the landing of pollen
grains on the stigma until the pollen tube enters the embryo sac (when
the pollen is compatible) or pollen inhibition (when the pollen is
incompatible). Following compatible pollination, pollen grain germinates
on the stigma and the resulting pollen tube grow through the style,
enter the ovules and finally discharges two male gametes in one of the
synergids. Angiosperms exhibit double fertilisation because two fusion
events occur in each embryo sac, namely syngamy and triple fusion.
The products of these fusions are the diploid zygote and the triploid
primary endosperm nucleus (in the primary endosperm cell). Zygote
develops into the embryo and the primary endosperm cell forms the
endosperm tissue. Formation of endosperm always precedes
development of the embryo.
The developing embryo passes through different stages such as
the proembryo, globular and heart-shaped stages before maturation.
Mature dicotyledonous embryo has two cotyledons and an embryonal
axis with epicotyl and hypocotyl. Embryos of monocotyledons have a
single cotyledon. After fertilisation, ovary develops into fruit and ovules
develop into seeds.
A phenomenon called apomixis is found in some angiosperms,
particularly in grasses. It results in the formation of seeds without
fertilisation. Apomicts have several advantages in horticulture and
agriculture.
Some angiosperms produce more than one embryo in their seed.
This phenomenon is called polyembryony.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->