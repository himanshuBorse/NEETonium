 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Structural Organisation in Animals</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Structural Organisation in Animals</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Structural Organisation in Animals</h3>
            <p class="chapSummary">Cells, tissues, organs and organ systems split up the work in a way that ensures
the survival of the body as a whole and exhibit division of labour. A tissue is
defined as group of cells along with intercellular substances performing one or
more functions in the body. Epithelia are sheet like tissues lining the body’s surface
and its cavities, ducts and tubes. Epithelia have one free surface facing a body
fluid or the outside environment. Their cells are structurally and functionally
connected at junctions.
Diverse types of connective tissues bind together, support, strengthen, protect,
and insulate other tissue in the body. Soft connective tissues consist of protein
fibres as well as a variety of cells arranged in a ground substance. Cartilage, bone,
blood, and adipose tissue are specialised connective tissues. Cartilage and bone
are both structural materials. Blood is a fluid tissue with transport functions.
Adipose tissue is a reservoir of stored energy. Muscle tissue, which can contract
(shorten) in response to stimulation, helps in movement of the body and specific
body parts. Skeletal muscle is the muscle tissue attached to bones. Smooth muscle
is a component of internal organs. Cardiac muscle makes up the contractile walls
of the heart. Connective tissue covers all three types of tissues. Nervous tissue
exerts greatest control over the response of body. Neurons are the basic units of
nervous tissue.
Earthworm, Cockroach and Frog show characteristic features in body
organisation. In Pheretima posthuma (earthworm), the body is covered by cuticle.
All segments of its body are alike except the 14th, 15th and 16th segment, which are
thick and dark and glandular, forming clitellum. A ring of S-shaped chitinous
setae is found in each segment. These setae help in locomotion. On the ventral
side spermathecal openings are present in between the grooves of 5 and 6, 6 and
7, 7 and 8 and 8 and 9 segments. Female genital pores are present on 14th segment
and male genital pores on 18th segment. The alimentary canal is a narrow tube
made of mouth, buccal cavity, pharynx, gizzard, stomach, intestine and anus.
The blood vascular system is of closed type with heart and valves. Nervous system
is represented by ventral nerve cord. Earthworm is hermaphorodite. Two pairs of 
testes occur in the 10th and 11th segment, respectively. A pair of ovaries are present
on 12 and 13th intersegmental septum. It is a protandrous animal with crossfertilisation.
 Fertilisation and development take place in cocoon secreted by the
glands of clitellum.
The body of Cockroach (Periplaneta americana) is covered by chitinous
exoskeleton. It is divided into head, thorax and abdomen. Segments bear jointed
appendages. There are three segments of thorax, each bearing a pair of walking
legs. Two pairs of wings are present, one pair each on 2nd and 3rd segment. There
are ten segments in abdomen. Alimentary canal is well developed with a mouth
surrounded by mouth parts, a pharynx, oesophagus, crop, gizzard, midgut,
hindgut and anus. Hepatic caecae are present at the junction of foregut and
midgut. Malpighian tubules are present at the junction of midgut and hindgut
and help in excretion. A pair of salivary gland is present near crop. The blood
vascular system is of open type. Respiration takes place by network of tracheae.
Trachea opens outside with spiracles. Nervous system is represented by
segmentally arranged ganglia and ventral nerve cord. A pair of testes is present in
4
th-6th segments and ovaries in 2nd-6th segments. Fertilisation is internal. Female
produces 9-10 ootheca bearing developing embryos. After rupturing of single
ootheca sixteen young ones, called nymphs come out.
The Indian bullfrog, Rana tigrina, is the common frog found in India. Body is
covered by skin. Mucous glands are present in the skin which is highly vascularised
and helps in respiration in water and on land. Body is divisible into head and trunk.
A muscular tongue is present, which is bilobed at the tip and is used in capturing
the prey. The alimentary canal consists of oesophagous, stomach, intestine and
rectum, which open into the cloaca. The main digestive glands are liver and pancreas.
It can respire in water through skin and through lungs on land. Circulatory system
is closed with single circulation. RBCs are nucleated. Nervous system is organised
into central, peripheral and autonomic. The organs of urinogenital system are kidneys
and urinogenital ducts, which open into the cloaca. The male reproductive organ is
a pair of testes. The female reproductive organ is a pair of ovaries. A female lays
2500-3000 ova at a time. The fertilisation and development are external. The eggs
hatch into tadpoles, which metamorphose into frogs.
</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->