 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Body Fluids and Circulation</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Body Fluids and Circulation</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Body Fluids and Circulation</h3>
            <p class="chapSummary">Vertebrates circulate blood, a fluid connective tissue, in their body, to transport essential
substances to the cells and to carry waste substances from there. Another fluid, lymph
(tissue fluid) is also used for the transport of certain substances.
Blood comprises of a fluid matrix, plasma and formed elements. Red blood cells (RBCs,
erythrocytes), white blood cells (WBCs, leucocytes) and platelets (thrombocytes) constitute
the formed elements. Blood of humans are grouped into A, B, AB and O systems based
on the presence or absence of two surface antigens, A, B on the RBCs. Another blood
grouping is also done based on the presence or absence of another antigen called Rhesus
factor (Rh) on the surface of RBCs. The spaces between cells in the tissues contain a fluid
derived from blood called tissue fluid. This fluid called lymph is almost similar to blood
except for the protein content and the formed elements.
All vertebrates and a few invertebrates have a closed circulatory system. Our circulatory
system consists of a muscular pumping organ, heart, a network of vessels and a fluid, blood.
Heart has two atria and two ventricles. Cardiac musculature is auto-excitable. Sino-atrial node
(SAN) generates the maximum number of action protentials per minute (70-75/min) and
therefore, it sets the pace of the activities of the heart. Hence it is called the Pacemaker. The
action potential causes the atria and then the ventricles to undergo contraction (systole) followed
by their relaxation (diastole). The systole forces the blood to move from the atria to the ventricles
and to the pulmonary artery and the aorta. The cardiac cycle is formed by sequential events in
the heart which is cyclically repeated and is called the cardiac cycle. A healthy person shows 72
such cycles per minute. About 70 mL of blood is pumped out by each ventricle during a
cardiac cycle and it is called the stroke or beat volume. Volume of blood pumped out by each
ventricle of heart per minute is called the cardiac output and it is equal to the product of stroke
volume and heart rate (approx 5 litres). The electrical activity of the heart can be recorded from
the body surface by using electrocardiograph and the recording is called
electrocardiogram (ECG) which is of clinical importance.
We have a complete double circulation, i.e., two circulatory pathways, namely,
pulmonary and systemic are present. The pulmonary circulation starts by the
pumping of deoxygenated blood by the right ventricle which is carried to the lungs
where it is oxygenated and returned to the left atrium. The systemic circulation
starts with the pumping of oxygenated blood by the left ventricle to the aorta
which is carried to all the body tissues and the deoxygenated blood from there is
collected by the veins and returned to the right atrium. Though the heart is
autoexcitable, its functions can be moderated by neural and hormonal mechanisms.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->