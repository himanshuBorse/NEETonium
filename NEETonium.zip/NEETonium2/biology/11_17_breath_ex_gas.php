 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Breathing and Exchange of Gases</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Breathing and Exchange of Gases</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Breathing and Exchange of Gases</h3>
            <p class="chapSummary">Cells utilise oxygen for metabolism and produce energy along with substances
like carbon dioxide which is harmful. Animals have evolved different mechanisms
for the transport of oxygen to the cells and for the removal of carbon dioxide from
there. We have a well developed respiratory system comprising two lungs and
associated air passages to perform this function.
The first step in respiration is breathing by which atmospheric air is taken in
(inspiration) and the alveolar air is released out (expiration). Exchange of O2
 and
CO2
 between deoxygenated blood and alveoli, transport of these gases throughout
the body by blood, exchange of O2
 and CO2
 between the oxygenated blood and
tissues and utilisation of O2
 by the cells (cellular respiration) are the other steps
involved.
Inspiration and expiration are carried out by creating pressure gradients
between the atmosphere and the alveoli with the help of specialised muscles –
intercostals and diaphragm. Volumes of air involved in these activities can be
estimated with the help of spirometer and are of clinical significance.
Exchange of O2
 and CO2
 at the alveoli and tissues occur by diffusion. Rate of
diffusion is dependent on the partial pressure gradients of O2
 (pO2
) and CO2
 (pCO2
),
their solubility as well as the thickness of the diffusion surface. These factors in
our body facilitate diffusion of O2
 from the alveoli to the deoxygenated blood as
well as from the oxygenated blood to the tissues. The factors are favourable for the
diffusion of CO2
 in the opposite direction, i.e., from tissues to alveoli.
Oxygen is transported mainly as oxyhaemoglobin. In the alveoli where pO2
 is
higher, O2
 gets bound to haemoglobin which is easily dissociated at the tissues
where pO2
 is low and pCO2
 and H+
 concentration are high. Nearly 70 per cent of
carbon dioxide is transported as bicarbonate (HCO3
–
) with the help of the enzyme
carbonic anhydrase. 20-25 per cent of carbon dioxide is carried by haemoglobin
as carbamino-haemoglobin. In the tissues where pCO2
 is high, it gets bound to
blood whereas in the alveoli where pCO2 is low and pO2
 is high, it gets removed
from the blood.
Respiratory rhythm is maintained by the respiratory centre in the medulla
region of brain. A pneumotaxic centre in the pons region of the brain and a
chemosensitive area in the medulla can alter respiratory mechanism.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->