 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Human Reproduction</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Human Reproduction</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Human Reproduction</h3>
            <p class="chapSummary">Humans are sexually reproducing and viviparous. The male
reproductive system is composed of a pair of testes, the male sex
accessory ducts and the accessory glands and external genitalia. Each
testis has about 250 compartments called testicular lobules, and each
lobule contains one to three highly coiled seminiferous tubules. Each
seminiferous tubule is lined inside by spermatogonia and Sertoli cells.
The spermatogonia undergo meiotic divisions leading to sperm formation,
while Sertoli cells provide nutrition to the dividing germ cells. The Leydig
cells outside the seminiferous tubules, synthesise and secrete testicular
hormones called androgens. The male external genitalia is called penis.
The female reproductive system consists of a pair of ovaries, a pair
of oviducts, a uterus, a vagina, external genitalia, and a pair of
mammary glands. The ovaries produce the female gamete (ovum) and
some steroid hormones (ovarian hormones). Ovarian follicles in different
stages of development are embedded in the stroma. The oviducts, uterus
and vagina are female accessory ducts. The uterus has three layers
namely perimetrium, myometrium and endometrium. The female
external genitalia includes mons pubis, labia majora, labia minora,
hymen and clitoris. The mammary glands are one of the female
secondary sexual characteristics.
Spermatogenesis results in the formation of sperms that are
transported by the male sex accessory ducts. A normal human sperm
is composed of a head, neck, a middle piece and tail. The process of
formation of mature female gametes is called oogenesis. The
reproductive cycle of female primates is called menstrual cycle.
Menstrual cycle starts only after attaining sexual maturation (puberty).
During ovulation only one ovum is released per menstrual cycle. The
cyclical changes in the ovary and the uterus during menstrual cycle
are induced by changes in the levels of pituitary and ovarian hormones.
After coitus, sperms are transported to the junction of the isthmus and
ampulla, where the sperm fertilises the ovum leading to formation of a
diploid zygote. The presence of X or Y chromosome in the sperm
determines the sex of the embryo. The zygote undergoes repeated mitotic
division to form a blastocyst, which is implanted in the uterus resulting
in pregnancy. After nine months of pregnancy, the fully developed foetus
is ready for delivery. The process of childbirth is called parturition which
is induced by a complex neuroendocrine mechanism involving cortisol,
estrogens and oxytocin. Mammary glands differentiate during pregnancy
and secrete milk after child-birth. The new-born baby is fed milk by the
mother (lactation) during the initial few months of growth.
</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->