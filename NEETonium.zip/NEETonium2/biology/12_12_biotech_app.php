 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Biotechnology and its Applications</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Biotechnology and its Applications</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Biotechnology and its Applications</h3>
            <p class="chapSummary">Biotechnology has given to humans several useful products by using
microbes, plant, animals and their metabolic machinery. Recombinant
DNA technology has made it possible to engineer microbes, plants
and animals such that they have novel capabilities. Genetically
Modified Organisms have been created by using methods other than
natural methods to transfer one or more genes from one organism to
another, generally using techniques such as recombinant DNA
technology.
GM plants have been useful in increasing crop yields, reduce postharvest losses and make crops more tolerant of stresses. There are
several GM crop plants with improved nutritional value of foods and
reduced the reliance on chemical pesticides (pest-resistant crops).
Recombinant DNA technological processes have made immense
impact in the area of healthcare by enabling mass production of safe
and more effective therapeutics. Since the recombinant therapeutics
are identical to human proteins, they do not induce unwanted
immunological responses and are free from risk of infection as was
observed in case of similar products isolated from non-human sources.
Human insulin is made in bacteria yet its structure is absolutely
identical to that of the natural molecule.
Transgenic animals are also used to understand how genes
contribute to the development of a disease by serving as models for
human diseases, such as cancer, cystic fibrosis, rheumatoid arthritis
and Alzheimer’s.
Gene therapy is the insertion of genes into an individual’s cells
and tissues to treat diseases especially hereditary diseases. It does
so by replacing a defective mutant allele with a functional one or
gene targeting which involves gene amplification. Viruses that attack
their hosts and introduce their genetic material into the host cell as
part of their replication cycle are used as vectors to transfer healthy
genes or more recently portions of genes.
The current interest in the manipulation of microbes, plants, and
animals has raised serious ethical questions.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->