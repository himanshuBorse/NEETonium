<?php
    include "../resources/header.php";
?>

<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->


<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Animal Kingdom</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology Mcq</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Animal Kingdom</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="page-section">
    <div class="container">
    <div class="widget-wrap">
        <h3 class="widget-title">Animal Kingdom</h3>
        <p class="chapSummary">The basic fundamental features such as level of organisation, symmetry, cell
            organisation, coelom, segmentation, notochord, etc., have enabled us to broadly
            classify the animal kingdom. Besides the fundamental features, there are many
            other distinctive characters which are specific for each phyla or class.
            Porifera includes multicellular animals which exhibit cellular level of
            organisation and have characteristic flagellated choanocytes. The coelenterates
            have tentacles and bear cnidoblasts. They are mostly aquatic, sessile or free-floating.
            The ctenophores are marine animals with comb plates. The platyhelminths have
            flat body and exhibit bilateral symmetry. The parasitic forms show distinct suckers
            and hooks. Aschelminthes are pseudocoelomates and include parasitic as well as
            non-parasitic round worms.
            Annelids are metamerically segmented animals with a true coelom. The
            arthropods are the most abundant group of animals characterised by the presence
            of jointed appendages. The molluscs have a soft body surrounded by an external
            calcareous shell. The body is covered with external skeleton made of chitin. The
            echinoderms possess a spiny skin. Their most distinctive feature is the presence
            of water vascular system. The hemichordates are a small group of worm-like marine
            animals. They have a cylindrical body with proboscis, collar and trunk.
            Phylum Chordata includes animals which possess a notochord either
            throughout or during early embryonic life. Other common features observed in
            the chordates are the dorsal, hollow nerve cord and paired pharyngeal gill slits.
            Some of the vertebrates do not possess jaws (Agnatha) whereas most of them possess
            jaws (Gnathostomata). Agnatha is represented by the class, Cyclostomata. They
            are the most primitive chordates and are ectoparasites on fishes. Gnathostomata
            has two super classes, Pisces and Tetrapoda. Classes Chondrichthyes and
            Osteichthyes bear fins for locomotion and are grouped under Pisces. The
            Chondrichthyes are fishes with cartilaginous endoskeleton and are marine. Classes,
            Amphibia, Reptilia, Aves and Mammalia have two pairs of limbs and are thus
            grouped under Tetrapoda. The amphibians have adapted to live both on land and
            water. Reptiles are characterised by the presence of dry and cornified skin. Limbs
            are absent in snakes. Fishes, amphibians and reptiles are poikilothermous (coldblooded). Aves are warm-blooded animals with feathers on their bodies and
            forelimbs modified into wings for flying. Hind limbs are adapted for walking,
            swimming, perching or clasping. The unique features of mammals are the presence
            of mammary glands and hairs on the skin. They commonly exhibit viviparity.</p>
    </div>
        <div class="row">
            <div class="col-lg-8 py-3">
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">1</span>
                            <span class="question">What is common about Trypanosoma, Noctiluca, Monocystis and Giardia</span>
                            <div class="option"><span class="optionNum">A</span>These are all parasites</div>
                            <div class="option"><span class="optionNum">B</span>These are all unicellular protists</div>
                            <div class="option"><span class="optionNum">C</span>They have flagella</div>
                            <div class="option"><span class="optionNum">D</span>They produces spores</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These are all unicellular protists</div>

                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">2</span>
                            <span class="question">Choose the correct statement</span>
                            <div class="option"><span class="optionNum">A</span>All reptiles have a three-chambered heart</div>
                            <div class="option"><span class="optionNum">B</span>All pices have gills covered by an operculum</div>
                            <div class="option"><span class="optionNum">C</span>All mammals are viviparous</div>
                            <div class="option"><span class="optionNum">D</span>All cyclostomes do not possess jaws and paired fins.</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol2')">
                            <div id="textsol2" class="textSolution" style="display:none">All cyclostomes do not possess jaws and paired fins.</div>

                        </form>
                    </div>

                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">3</span>
                            <span class="question">Which one of the following characteristics is not shared by birds and mammals</span>
                            <div class="option"><span class="optionNum">A</span>Ossified endoskeleton</div>
                            <div class="option"><span class="optionNum">B</span>Breathing using lungs</div>
                            <div class="option"><span class="optionNum">C</span>Vivparity</div>
                            <div class="option"><span class="optionNum">D</span>Warm blooded nature</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol3')">
                            <div id="textsol3" class="textSolution" style="display:none">Vivparity</div>

                        </form>
                    </div>

                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">4</span>
                            <span class="question">A jawless fish, which lays eggs in fresh water and whose ammocoetes larvae after metamorphosis return to the ocean is</span>
                            <div class="option"><span class="optionNum">A</span>Petromyzon</div>
                            <div class="option"><span class="optionNum">B</span>Eptatretus</div>
                            <div class="option"><span class="optionNum">C</span>Myxine</div>
                            <div class="option"><span class="optionNum">D</span>Neomyxine</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol4')">
                            <div id="textsol4" class="textSolution" style="display:none">Petromyzon</div>

                        </form>
                    </div>

                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">5</span>
                            <span class="question">Which of the following pairs of organisms, possess stinging cells (nematocytes)?</span>
                            <div class="option"><span class="optionNum">A</span>Sea fan and Sea pen</div>
                            <div class="option"><span class="optionNum">B</span>Cobra and Scorpion</div>
                            <div class="option"><span class="optionNum">C</span>Cockroach and Mosquito</div>
                            <div class="option"><span class="optionNum">D</span>Wasp and Honey bee</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol5')">
                            <div id="textsol5" class="textSolution" style="display:none">Sea fan and Sea pen</div>

                        </form>
                    </div>

                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">6</span>
                            <span class="question">Infection of Ascaris usually occurs by</span>
                            <div class="option"><span class="optionNum">A</span>Mosquito bite</div>
                            <div class="option"><span class="optionNum">B</span>drinking water containing eggs of Ascaris</div>
                            <div class="option"><span class="optionNum">C</span>eating imperfectly cooked pork</div>
                            <div class="option"><span class="optionNum">D</span>Tse-tse fly</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol6')">
                            <div id="textsol6" class="textSolution" style="display:none">drinking water containig eggs of Ascaris</div>

                        </form>
                    </div>

                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">7</span>
                            <span class="question">Jaw suspension characteristics of mammals is</span>
                            <div class="option"><span class="optionNum">A</span>Amphistylic</div>
                            <div class="option"><span class="optionNum">B</span>Craniostylic</div>
                            <div class="option"><span class="optionNum">C</span>Autodiastylic</div>
                            <div class="option"><span class="optionNum">D</span>Hyostylic</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol7')">
                            <div id="textsol7" class="textSolution" style="display:none">Craniostylic</div>

                        </form>
                    </div>

                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">8</span>
                            <span class="question">When Paramoecium was subjected to X-ray its macronucleus degenerate and one of the following stopped</span>
                            <div class="option"><span class="optionNum">A</span>Locomotion, digestion, osmoregulation</div>
                            <div class="option"><span class="optionNum">B</span>Reproduction, digestion, locomotion</div>
                            <div class="option"><span class="optionNum">C</span>Reproduction, Locomotion, osmoregulation</div>
                            <div class="option"><span class="optionNum">D</span>Reproduction, osmoregulation</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol8')">
                            <div id="textsol8" class="textSolution" style="display:none">Locomotion, digestion, osmoregulation</div>

                        </form>
                    </div>

                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">9</span>
                            <span class="question">Chemoreceptor of Pila is?</span>
                            <div class="option"><span class="optionNum">A</span>Ctenidium</div>
                            <div class="option"><span class="optionNum">B</span>Radula</div>
                            <div class="option"><span class="optionNum">C</span>Osphardium</div>
                            <div class="option"><span class="optionNum">D</span>Statocyst</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol9')">
                            <div id="textsol9" class="textSolution" style="display:none">Osphardium</div>

                        </form>
                    </div>

                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">10</span>
                            <span class="question">Member of Echinodermata has a specific system, which is not found in other phylum, it is</span>
                            <div class="option"><span class="optionNum">A</span>Canal system</div>
                            <div class="option"><span class="optionNum">B</span>Water Vascular System</div>
                            <div class="option"><span class="optionNum">C</span>Respiratory system</div>
                            <div class="option"><span class="optionNum">D</span>Jointed appendages</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol10')">
                            <div id="textsol10" class="textSolution" style="display:none">Water Vascular system</div>

                        </form>
                    </div>


                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">11</span>
                            <span class="question">Aristotle lantern is found in </span>
                            <div class="option"><span class="optionNum">A</span>Sea-urchin</div>
                            <div class="option"><span class="optionNum">B</span>Sepia</div>
                            <div class="option"><span class="optionNum">C</span>Grass-hopper</div>
                            <div class="option"><span class="optionNum">D</span>Silver fish</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol11')">
                            <div id="textsol11" class="textSolution" style="display:none">Sea-urchin</div>

                        </form>
                    </div>

                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">12</span>
                            <span class="question">Which of the following group of animals have a constant body temperature</span>
                            <div class="option"><span class="optionNum">A</span>Reptiles, aves and mammalia</div>
                            <div class="option"><span class="optionNum">B</span>Aves and cyclostomata</div>
                            <div class="option"><span class="optionNum">C</span>Pisces and amphibia</div>
                            <div class="option"><span class="optionNum">D</span>Aves and mammalia</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol12')">
                            <div id="textsol12" class="textSolution" style="display:none">Aves and mammalia</div>

                        </form>
                    </div>

                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">13</span>
                            <span class="question">Kidney in amphibians is</span>
                            <div class="option"><span class="optionNum">A</span>Pronephric</div>
                            <div class="option"><span class="optionNum">B</span>Mesonephric</div>
                            <div class="option"><span class="optionNum">C</span>Archaeonephric</div>
                            <div class="option"><span class="optionNum">D</span>Metanephric</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol13')">
                            <div id="textsol13" class="textSolution" style="display:none">Mesonephric</div>

                        </form>
                    </div>

                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">14</span>
                            <span class="question">Select the pseudocoelomates from the list of organism given below</span>
                            <div class="option"><span class="optionNum">A</span>Ascaris, Fasicola, Taenia</div>
                            <div class="option"><span class="optionNum">B</span>Culex, Locusta, Limulus</div>
                            <div class="option"><span class="optionNum">C</span>Wuchereria, Ascaris, Ancylostoma</div>
                            <div class="option"><span class="optionNum">D</span>Neries, Hirundinariam, Wuchereria</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol14')">
                            <div id="textsol14" class="textSolution" style="display:none">Wuchereria, Ascaris, Ancylostoma</div>

                        </form>
                    </div>

                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">15</span>
                            <span class="question">How many in the given examples are Coelentrates. (Physalia, Obelia, Plannaria, Pennatula, Gorgonia, Pleurobrachia, Meandrina and Nereis)</span>
                            <div class="option"><span class="optionNum">A</span>Three</div>
                            <div class="option"><span class="optionNum">B</span>Four</div>
                            <div class="option"><span class="optionNum">C</span>Five</div>
                            <div class="option"><span class="optionNum">D</span>Six</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol15')">
                            <div id="textsol15" class="textSolution" style="display:none">Five</div>

                        </form>
                    </div>

                   


                    <div class="customPagination">

                        <li class="custom-page-item previous-page disable"><a class="custom-page-link" href="#">Prev</a></li>
                        <li class="custom-page-item current-page active"><a class="custom-page-link" href="#">1</a></li>
                        <li class="custom-page-item dots"><a class="custom-page-link" href="#">...</a></li>
                        <li class="custom-page-item current-page"><a class="custom-page-link" href="#">5</a></li>
                        <li class="custom-page-item current-page"><a class="custom-page-link" href="#">6</a></li>
                        <li class="custom-page-item dots"><a class="custom-page-link" href="#">...</a></li>
                        <li class="custom-page-item current-page"><a class="custom-page-link" href="#">10</a></li>

                    </div>
                </div>
            </div>
            <!-- start sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
        </div>
    </div>
    
</div>

<!-- end sidebar -->
</div>



</div>


<script src="../assets/js/solutionScript.js"></script>
<?php
include "../resources/footer.php";
?>