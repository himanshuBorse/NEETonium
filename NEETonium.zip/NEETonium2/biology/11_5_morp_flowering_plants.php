 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Morphology of Flowering Plants</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Morphology of Flowering Plants</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Morphology of Flowering Plants</h3>
            <p class="chapSummary">Flowering plants exhibit enormous variation in shape, size, structure, mode of
nutrition, life span, habit and habitat. They have well developed root and shoot
systems. Root system is either tap root or fibrous. Generally, dicotyledonous plants
have tap roots while monocotyledonous plants have fibrous roots. The roots in
some plants get modified for storage of food, mechanical support and respiration.
The shoot system is differentiated into stem, leaves, flowers and fruits. The
morphological features of stems like the presence of nodes and internodes,
multicellular hair and positively phototropic nature help to differentiate the stems
from roots. Stems also get modified to perform diverse functions such as storage
of food, vegetative propagation and protection under different conditions. Leaf is a
lateral outgrowth of stem developed exogeneously at the node. These are green in
colour to perform the function of photosynthesis. Leaves exhibit marked variations
in their shape, size, margin, apex and extent of incisions of leaf blade (lamina).
Like other parts of plants, the leaves also get modified into other structures such
as tendrils, spines for climbing and protection respectively.
The flower is a modified shoot, meant for sexual reproduction. The flowers are
arranged in different types of inflorescences. They exhibit enormous variation in
structure, symmetry, position of ovary in relation to other parts, arrangement of
petals, sepals, ovules etc. After fertilisation, the ovary is converted into fruits and
ovules into seeds. Seeds either may be monocotyledonous or dicotyledonous. They
vary in shape, size and period of viability. The floral characteristics form the basis
of classification and identification of flowering plants. This can be illustrated
through semi-technical descriptions of families. Hence, a flowering plant is
described in a definite sequence by using scientific terms. The floral features are
represented in the summarised form as floral diagrams and floral formula.
</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->