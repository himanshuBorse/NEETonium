 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Respiration in Plants</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Respiration in Plants</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Respiration in Plants</h3>
            <p class="chapSummary">Plants unlike animals have no special systems for breathing or gaseous exchange.
Stomata and lenticels allow gaseous exchange by diffusion. Almost all living cells
in a plant have their surfaces exposed to air.
The breaking of C-C bonds of complex organic molecules by oxidation cells
leading to the release of a lot of energy is called cellular respiration. Glucose is the
favoured substrate for respiration. Fats and proteins can also be broken down to
yield energy. The initial stage of cellular respiration takes place in the cytoplasm.
Each glucose molecule is broken through a series of enzyme catalysed reactions
into two molecules of pyruvic acid. This process is called glycolysis. The fate of the
pyruvate depends on the availability of oxygen and the organism. Under anaerobic
conditions either lactic acid fermentation or alcohol fermentation occurs.
Fermentation takes place under anaerobic conditions in many prokaryotes,
unicellular eukaryotes and in germinating seeds. In eukaryotic organisms aerobic
respiration occurs in the presence of oxygen. Pyruvic acid is transported into the
mitochondria where it is converted into acetyl CoA with the release of CO2
. Acetyl
CoA then enters the tricarboxylic acid pathway or Krebs’ cycle operating in the
matrix of the mitochondria. NADH + H+
 and FADH2
 are generated in the Krebs’
cycle. The energy in these molecules as well as that in the NADH+ H+
 synthesised
during glycolysis are used to synthesise ATP. This is accomplished through a
system of electron carriers called electron transport system (ETS) located on the
inner membrane of the mitochondria. The electrons, as they move through the
system, release enough energy that are trapped to synthesise ATP. This is called
oxidative phosphorylation. In this process O2
 is the ultimate acceptor of electrons
and it gets reduced to water.
The respiratory pathway is an amphibolic pathway as it involves both anabolism
and catabolism. The respiratory quotient depends upon the type of respiratory
substance used during respiration.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->