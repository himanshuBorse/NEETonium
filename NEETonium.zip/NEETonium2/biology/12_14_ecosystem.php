 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Ecosystem</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Ecosystem</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Ecosystem</h3>
            <p class="chapSummary">An ecosystem is a structural and functional unit of nature and it
comprises abiotic and biotic components. Abiotic components are
inorganic materials- air, water and soil, whereas biotic components
are producers, consumers and decomposers. Each ecosystem has
characteristic physical structure resulting from interaction amongst
abiotic and biotic components. Species composition and stratification
are the two main structural features of an ecosystem. Based on source
of nutrition every organism occupies a place in an ecosystem.
Productivity, decomposition, energy flow, and nutrient cycling are
the four important components of an ecosystem. Primary productivity
is the rate of capture of solar energy or biomass production of the
producers. It is divided into two types: gross primary productivity (GPP)
and net primary productivity (NPP). Rate of capture of solar energy or
total production of organic matter is called as GPP. NPP is the remaining
biomass or the energy left after utilisation of producers. Secondary
productivity is the rate of assimilation of food energy by the consumers.
In decomposition, complex organic compounds of detritus are converted
to carbon dioxide, water and inorganic nutrients by the decomposers.
Decomposition involves three processes, namely fragmentation of
detritus, leaching and catabolism.
Energy flow is unidirectional. First, plants capture solar energy
and then, food is transferred from the producers to decomposers.
Organisms of different trophic levels in nature are connected to each
other for food or energy relationship forming a food chain. The storage
and movement of nutrient elements through the various components
of the ecosystem is called nutrient cycling; nutrients are repeatedly
used through this process. Nutrient cycling is of two types—gaseous
and sedimentary. Atmosphere or hydrosphere is the reservoir for the
gaseous type of cycle (carbon), whereas Earth’s crust is the reservoir
for sedimentary type (phosphorus). Products of ecosystem processes
are named as ecosystem services, e.g., purification of air and water by
forests.
The biotic community is dynamic and undergoes changes with the
passage of time. These changes are sequentially ordered and constitute
ecological succession. Succession begins with invasion of a bare lifeless
area by pioneers which later pave way for successors and ultimately a
stable climax community is formed. The climax community remains
stable as long as the environment remains unchanged.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->