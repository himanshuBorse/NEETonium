 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Locomotion and Movement</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Locomotion and Movement</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Locomotion and Movement</h3>
            <p class="chapSummary">Movement is an essential feature of all living beings. Protoplasmic streaming, ciliary
movements, movements of fins, limbs, wings, etc., are some forms exhibited by
animals. A voluntary movement which causes the animal to change its place, is
called locomotion. Animals move generally in search of food, shelter, mate, breeding
ground, better climate or to protect themselves.
The cells of the human body exhibit amoeboid, ciliary and muscular
movements. Locomotion and many other movements require coordinated muscular
activities. Three types of muscles are present in our body. Skeletal muscles are
attached to skeletal elements. They appear striated and are voluntary in nature.
Visceral muscles, present in the inner walls of visceral organs are nonstriated and
involuntary. Cardiac muscles are the muscles of the heart. They are striated,
branched and involuntary. Muscles possess excitability, contractility, extensibility
and elasticity.
Muscle fibre is the anatomical unit of muscle. Each muscle fibre has many
parallelly arranged myofibrils. Each myofibril contains many serially arranged
units called sarcomere which are the functional units. Each sarcomere has a central
‘A’ band made of thick myosin filaments, and two half ‘I’ bands made of thin actin
filaments on either side of it marked by ‘Z’ lines. Actin and myosin are polymerised
proteins with contractility. The active sites for myosin on resting actin filament are
masked by a protein-troponin. Myosin head contains ATPase and has ATP binding
sites and active sites for actin. A motor neuron carries signal to the muscle fibre
which generates an action potential in it. This causes the release of Ca++ from
sarcoplasmic reticulum. Ca++ activates actin which binds to the myosin head to
form a cross bridge. These cross bridges pull the actin filaments causing them to
slide over the myosin filaments and thereby causing contraction. Ca++ are then
returned to sarcoplasmic reticulum which inactivate the actin. Cross bridges are
broken and the muscles relax.
Repeated stimulation of muscles leads to fatigue. Muscles are classified as
Red and White fibres based primarily on the amount of red coloured myoglobin
pigment in them.
Bones and cartilages constitute our skeletal system. The skeletal system is
divisible into axial and appendicular. Skull, vertebral column, ribs and sternum
constitute the axial skeleton. Limb bones and girdles form the appendicular
skeleton. Three types of joints are formed between bones or between bone and
cartilage – fibrous, cartilaginous and synovial. Synovial joints allow considerable
movements and therefore, play a significant role in locomotion.
</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->