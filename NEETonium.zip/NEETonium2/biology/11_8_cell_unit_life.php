 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Cell: Unit of Life</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Cell: Unit of Life</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Cell: Unit of Life</h3>
            <p class="chapSummary">All organisms are made of cells or aggregates of cells. Cells vary in their shape, size
and activities/functions. Based on the presence or absence of a membrane bound
nucleus and other organelles, cells and hence organisms can be named as
eukaryotic or prokaryotic.
A typical eukaryotic cell consists of a cell membrane, nucleus and cytoplasm.
Plant cells have a cell wall outside the cell membrane. The plasma membrane is
selectively permeable and facilitates transport of several molecules. The
endomembrane system includes ER, golgi complex, lysosomes and vacuoles. All
the cell organelles perform different but specific functions. Centrosome and centriole
form the basal body of cilia and flagella that facilitate locomotion. In animal cells,
centrioles also form spindle apparatus during cell division. Nucleus contains
nucleoli and chromatin network. It not only controls the activities of organelles
but also plays a major role in heredity.
Endoplasmic reticulum contains tubules or cisternae. They are of two types:
rough and smooth. ER helps in the transport of substances, synthesis of
proteins, lipoproteins and glycogen. The golgi body is a membranous organelle
composed of flattened sacs. The secretions of cells are packed in them and
transported from the cell. Lysosomes are single membrane structures
containing enzymes for digestion of all types of macromolecules. Ribosomes
are involved in protein synthesis. These occur freely in the cytoplasm or are
associated with ER. Mitochondria help in oxidative phosphorylation and
generation of adenosine triphosphate. They are bound by double membrane;
the outer membrane is smooth and inner one folds into several cristae. Plastids
are pigment containing organelles found in plant cells only. In plant cells,
chloroplasts are responsible for trapping light energy essential for
photosynthesis. The grana, in the plastid, is the site of light reactions and the
stroma of dark reactions. The green coloured plastids are chloroplasts, which
contain chlorophyll, whereas the other coloured plastids are chromoplasts,
which may contain pigments like carotene and xanthophyll. The nucleus is
enclosed by nuclear envelope, a double membrane structure with nuclear pores.
The inner membrane encloses the nucleoplasm and the chromatin material.
Thus, cell is the structural and functional unit of life.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->