 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Biodiversity and Conversation</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Biodiversity and Conversation</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Biodiversity and Conversation</h3>
            <p class="chapSummary">Since life originated on earth nearly 3.8 billion years ago, there had
been enormous diversification of life forms on earth. Biodiversity refers
to the sum total of diversity that exists at all levels of biological
organisation. Of particular importance is the diversity at genetic, species
and ecosystem levels and conservation efforts are aimed at protecting
diversity at all these levels.
More than 1.5 million species have been recorded in the world, but
there might still be nearly 6 million species on earth waiting to be
discovered and named. Of the named species, > 70 per cent are animals,
of which 70 per cent are insects. The group Fungi has more species
than all the vertebrate species combined. India, with about 45,000
species of plants and twice as many species of animals, is one of the 12
mega diversity countries of the world.
Species diversity on earth is not uniformly distributed but shows
interesting patterns. It is generally highest in the tropics and decreases
towards the poles. Important explanations for the species richness of
the tropics are: Tropics had more evolutionary time; they provide a
relatively constant environment and, they receive more solar energy
which contributes to greater productivity. Species richness is also
function of the area of a region; the species-area relationship is generally
a rectangular hyperbolic function.
It is believed that communities with high diversity tend to be less
variable, more productive and more resistant to biological invasions.
Earth’s fossil history reveals incidence of mass extinctions in the past,
but the present rates of extinction, largely attributed to human activities,
are 100 to 1000 times higher. Nearly 700 species have become extinct
in recent times and more than 15,500 species (of which > 650 are from
India) currently face the threat of extinction. The causes of high
extinction rates at present include habitat (particularly forests) loss
and fragmentation, over -exploitation, biological invasions and
co-extinctions.
Earth’s rich biodiversity is vital for the very survival of mankind.
The reasons for conserving biodiversity are narrowly utilitarian, broadly
utilitarian and ethical. Besides the direct benefits (food, fibre, firewood,
pharmaceuticals, etc.), there are many indirect benefits we receive
through ecosystem services such as pollination, pest control, climate
moderation and flood control. We also have a moral responsibility to
take good care of earth’s biodiversity and pass it on in good order to our
next generation.
Biodiversity conservation may be in situ as well as ex situ. In in situ
conservation, the endangered species are protected in their natural
habitat so that the entire ecosystem is protected. Recently, 34
‘biodiversity hotspots’ in the world have been proposed for intensive
conservation efforts. Of these, three (Western Ghats-Sri Lanka,
Himalaya and Indo-Burma) cover India’s rich biodiversity regions. Our
country’s in situ conservation efforts are reflected in its 14 biosphere
reserves, 90 national parks, > 450 wildlife sanctuaries and many sacred
groves. Ex situ conservation methods include protective maintenance
of threatened species in zoological parks and botanical gardens, in vitro
fertilisation, tissue culture propagation and cryopreservation of
gametes.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->