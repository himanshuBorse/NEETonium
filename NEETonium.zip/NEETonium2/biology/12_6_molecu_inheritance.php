 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Molecular Basis of Inheritance</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Molecular Basis of Inheritance</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Molecular Basis of Inheritance</h3>
            <p class="chapSummary">Nucleic acids are long polymers of nucleotides. While DNA stores genetic
information, RNA mostly helps in transfer and expression of information.
Though DNA and RNA both function as genetic material, but DNA being
chemically and structurally more stable is a better genetic material.
However, RNA is the first to evolve and DNA was derived from RNA. The
hallmark of the double stranded helical structure of DNA is the hydrogen
bonding between the bases from opposite strands. The rule is that
Adenine pairs with Thymine through two H-bonds, and Guanine with
Cytosine through three H-bonds. This makes one strand
complementary to the other. The DNA replicates semiconservatively,
the process is guided by the complementary H-bonding. A segment of
DNA that codes for RNA may in a simplistic term can be referred as
gene. During transcription also, one of the strands of DNA acts a
template to direct the synthesis of complementary RNA. In bacteria,
the transcribed mRNA is functional, hence can directly be translated.
In eukaryotes, the gene is split. The coding sequences, exons, are
interrupted by non-coding sequences, introns. Introns are removed
and exons are joined to produce functional RNA by splicing. The
messenger RNA contains the base sequences that are read in a
combination of three (to make triplet genetic code) to code for an amino
acid. The genetic code is read again on the principle of complementarity
by tRNA that acts as an adapter molecule. There are specific tRNAs for
every amino acid. The tRNA binds to specific amino acid at one end
and pairs through H-bonding with codes on mRNA through its
anticodons. The site of translation (protein synthesis) is ribosomes,
which bind to mRNA and provide platform for joining of amino acids.
One of the rRNA acts as a catalyst for peptide bond formation, which is
an example of RNA enzyme (ribozyme). Translation is a process that
has evolved around RNA, indicating that life began around RNA. Since,
transcription and translation are energetically very expensive
processes, these have to be tightly regulated. Regulation of transcription
is the primary step for regulation of gene expression. In bacteria, more
than one gene is arranged together and regulated in units called as
operons. Lac operon is the prototype operon in bacteria, which codes
for genes responsible for metabolism of lactose. The operon is regulated
by the amount of lactose in the medium where the bacteria are grown.
Therefore, this regulation can also be viewed as regulation of enzyme
synthesis by its substrate.
Human genome project was a mega project that aimed to sequence
every base in human genome. This project has yielded much new
information. Many new areas and avenues have opened up as a
consequence of the project. DNA Fingerprinting is a technique to find
out variations in individuals of a population at DNA level. It works on
the principle of polymorphism in DNA sequences. It has immense
applications in the field of forensic science, genetic biodiversity and
evolutionary biology.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer --> 