 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Reproduction in Organisms</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Reproduction in Organisms</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Reproduction in Organisms</h3>
            <p class="chapSummary">Reproduction enables a species to live generation after generation.
Reproduction in organisms can be broadly classified into asexual and
sexual reproduction. Asexual reproduction does not involve the fusion
of gametes. It is common in organisms that have a relatively simple
organisation such as the fungi, algae and some invertebrate animals.
The offspring formed by asexual reproduction are identical and can be
referred to as clones. Zoospores, conidia, etc., are the most common
asexual structures formed in several algae and fungi. Budding
and gemmule formation are the common asexual methods seen in
lower animals.
Prokaryotes and unicellular organisms reproduce asexually by
cell division or binary fission of the parent cell. In several aquatic and
terrestrial species of angiosperms, structures such as runners,
rhizomes, suckers, tubers, offsets, etc., are capable of giving rise to
new offspring. This method of asexual reproduction is generally
referred to as vegetative propagation.
Sexual reproduction involves the formation and fusion of gametes.
It is a complex and slower process as compared to asexual reproduction.
Most of the higher animals reproduce almost entirely by sexual method.
Events of sexual reproduction may be categorised into pre-fertilisation,
fertilisation and post-fertilisation events. Pre-fertilisation events include
gametogenesis and gamete transfer while post-fertilisation events
include the formation of zygote and embryogenesis.
Organisms may be bisexual or unisexual. Sexuality in plants is
varied, particularly in angiosperms, due to the production of diverse
types of flowers. Plants are defined as monoecious and dioecious.
Flowers may be bisexual or unisexual flowers.
Gametes are haploid in nature and usually a direct product of meiotic
division except in haploid organisms where gametes are formed by mitosis.
Transfer of male gametes is an essential event in sexual reproduction.
It is relatively easy in bisexual organisms. In unisexual animals it occurs
by copulation or simultaneous release. In angiosperms, a special process
called pollination ensures transfer of pollen grains which carry the pollen
grains to the stigma.
Syngamy (fertilisation) occurs between the male and female gametes.
Syngamy may occur either externally, outside the body of organisms or
internally, inside the body. Syngamy leads to formation of a specialised
cell called zygote.
 The process of development of embryo from the zygote is called
embryogenesis. In animals, the zygote starts developing soon after its
formation. Animals may be either oviparous or viviparous. Embryonal
protection and care are better in viviparous organisms.
 In flowering plants, after fertilisation, ovary develops into fruit and
ovules mature into seeds. Inside the mature seed is the progenitor of
the next generation, the embryo.
</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->