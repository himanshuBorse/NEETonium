<?php
    include "../resources/header.php";
?>

<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<script src="../assets/js/seeMore.js"></script>

<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">The Living World</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.html">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.html">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology Mcq</a></li>
                            <li class="breadcrumb-item active" aria-current="page">The Living World</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="page-section">
    <div class="container">
        <div class="widget-wrap">
            <h3 class="widget-title">The Living World</h3>
            <p class="chapSummary"> The living world is rich in variety. Millions of plants and animals have been
                identified and described but a large number still remains unknown. The very
                range of organisms in terms of size, colour, habitat, physiological and
                morphological features make us seek the defining characteristics of living
                organisms. In order to facilitate the study of kinds and diversity of organisms,
                biologists have evolved certain rules and principles for identification, nomenclature
                and classification of organisms. The branch of knowledge dealing with these aspects
                is referred to as taxonomy. The taxonomic studies of various species of plants
                and animals are useful in agriculture, forestry, industry and in general for knowing
                our bio-resources and their diversity. The basics of taxonomy like identification,
                naming and classification of organisms are universally evolved under international
                codes. Based on the resemblances and distinct differences, each organism is
                identified and assigned a correct scientific/biological name comprising two words
                as per the binomial system of nomenclature. An organism represents/occupies a
                place or position in the system of classification. There are many categories/ranks
                and are generally referred to as taxonomic categories or taxa. All the categories
                constitute a taxonomic hierarchy.
                Taxonomists have developed a variety of taxonomic aids to facilitate
                identification, naming and classification of organisms. These studies are carried
                out from the actual specimens which are collected from the field and preserved as
                referrals in the form of herbaria, museums and in botanical gardens and zoological
                parks. It requires special techniques for collection and preservation of specimens
                in herbaria and museums. Live specimens, on the other hand, of plants and
                animals, are found in botanical gardens or in zoological parks. Taxonomists also
                prepare and disseminate information through manuals and monographs for
                further taxonomic studies. Taxonomic keys are tools that help in identification
                based on characteristics.</p>
        </div>
    
        <div class="row">
            <div class="col-lg-8 py-3">
                <div class="ques-content" style="display: none">

                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What is common about Trypanosoma, Noctiluca, Monocystis and Giardia</span>
                            <div class="option"><span class="optionNum">A</span>These are all parasites</div>
                            <div class="option"><span class="optionNum">B</span>These are all unicellular protists</div>
                            <div class="option"><span class="optionNum">C</span>They have flagella</div>
                            <div class="option"><span class="optionNum">D</span>They produces spores</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These are all unicellular protists</div>

                        </form> -->
                    </div>
                </div>             
                <?php
               
                            include "../pagination/customPageList.php";
                        ?>
            </div>
            

            <!-- start sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
            <!-- end sidebar -->
        </div>
    </div>
</div>

<script src="../assets/js/solutionScript.js"></script>
<?php
include "../resources/footer.php";
?>