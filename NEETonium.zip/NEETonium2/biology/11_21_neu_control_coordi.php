 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Neural Control and Coordination</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Neural Control and Coordination</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Neural Control and Coordination</h3>
            <p class="chapSummary">The neural system coordinates and integrates functions as well as metabolic
and homeostatic activities of all the organs. Neurons, the functional units of
neural system are excitable cells due to a differential concentration gradient of
ions across the membrane. The electrical potential difference across the resting
neural membrane is called the ‘resting potential’. The nerve impulse is conducted
along the axon membrane in the form of a wave of depolarisation and
repolarisation. A synapse is formed by the membranes of a pre-synaptic neuron
and a post-synaptic neuron which may or may not be separated by a gap called
synaptic cleft. Chemicals involved in the transmission of impulses at chemical
synapses are called neurotransmitters.
Human neural system consists of two parts : (i) central neural system (CNS)
and (ii) the peripheral neural system. The CNS consists of the brain and spiral
cord. The brain can be divided into three major parts : (i) forebrain, (ii) midbrain
and (iii) hindbrain. The forebrain consists of cerebrum, thalamus and
hypothalamus. The cerebrum is longitudinally divided into two halves that are
connected by the corpus callosum. A very important part of the forebrain called
hypothalamus controls the body temperature, eating and drinking. Inner parts
of cerebral hemispheres and a group of associated deep structures form a
complex structure called limbic system which is concerned with olfaction,
autonomic responses, regulation of sexual behaviour, expression of emotional
reactions, and motivation. The midbrain receives and integrates visual, tactile
and auditory inputs. The hindbrain comprises pons, cerebellum and medulla.
The cerebellum integrates information received from the semicircular canals of
the ear and the auditory system. The medulla contains centres, which control
respiration, cardiovascular reflexes, and gastric secretions. Pons consist of fibre
tracts that interconnect different regions of the brain. The entire process of
involuntary response to a peripheral nervous stimulation is called reflex action.
Information regarding changes in the environment is received by the CNS
through the sensory organs which are processed and analysed. Signals are then
sent for necessary adjustments. The wall of the human eye ball is composed of
three layers. The external layer is composed of cornea and sclera. Inside sclera is
the middle layer, which is called the choroid. Retina, the innermost layer, contains
two types of photoreceptor cells, namely rods and cones. The daylight (photopic)
vision and colour vision are functions of cones and twilight (scotopic) vision is the
function of the rods. The light enters through cornea, the lens and the images of
objects are formed on the retina.
The ear can be divided into the outer ear, the middle ear and the inner ear. The
middle ear contains three ossicles called malleus, incus and stapes. The fluid
filled inner ear is called the labyrinth, and the coiled portion of the labyrinth is
called cochlea. The organ of corti is a structure which contains hair cells that act
as auditory receptors and is located on the basilar membrane. The vibrations
produced in the ear drum are transmitted through the ear ossicles and oval window
to the fluid-filled inner ear. Nerve impulses are generated and transmitted by the
afferent fibres to the auditory cortex of the brain. The inner ear also contains a
complex system located above the cochlea called vestibular apparatus. It is
influenced by gravity and movements, and helps us in maintaining balance of the
body and posture.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->