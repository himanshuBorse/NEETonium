 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Excretory Products and Their Elimination</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Excretory Products and Their Elimination</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Excretory Products and Their Elimination</h3>
            <p class="chapSummary">Many nitrogen containing substances, ions, CO2
, water, etc., that accumulate in
the body have to be eliminated. Nature of nitrogenous wastes formed and their
excretion vary among animals, mainly depending on the habitat (availability of
water). Ammonia, urea and uric acid are the major nitrogenous wastes excreted.
Protonephridia, nephridia, malpighian tubules, green glands and the kidneys are
the common excretory organs in animals. They not only eliminate nitrogenous wastes
but also help in the maintenance of ionic and acid-base balance of body fluids.
In humans, the excretory system consists of one pair of kidneys, a pair of ureters,
a urinary bladder and a urethra. Each kidney has over a million tubular structures
called nephrons. Nephron is the functional unit of kidney and has two portions –
glomerulus and renal tubule. Glomerulus is a tuft of capillaries formed from afferent
arterioles, fine branches of renal artery. The renal tubule starts with a double walled
Bowman’s capsule and is further differentiated into a proximal convoluted tubule
(PCT), Henle’s loop (HL) and distal convoluted tubule (DCT). The DCTs of many
nephrons join to a common collecting duct many of which ultimately open into the
renal pelvis through the medullary pyramids. The Bowman’s capsule encloses the
glomerulus to form Malpighian or renal corpuscle.
Urine formation involves three main processes, i.e., filtration, reabsorption and
secretion. Filtration is a non-selective process performed by the glomerulus using
the glomerular capillary blood pressure. About 1200 ml of blood is filtered by the
glomerulus per minute to form 125 ml of filtrate in the Bowman’s capsule per
minute (GFR). JGA, a specialised portion of the nephrons, plays a significant role
in the regulation of GFR. Nearly 99 per cent reabsorption of the filtrate takes place
through different parts of the nephrons. PCT is the major site of reabsorption and
selective secretion. HL primarily helps to maintain osmolar gradient
(300 mOsmolL–1 -1200 mOsmolL–1) within the kidney interstitium. DCT and
collecting duct allow extensive reabsorption of water and certain electrolytes, which
help in osmoregulation: H+
, K+
 and NH3
 could be secreted into the filtrate by the
tubules to maintain the ionic balance and pH of body fluids.
A counter current mechanism operates between the two limbs of the loop of
Henle and those of vasa recta (capillary parallel to Henle’s loop). The filtrate gets
concentrated as it moves down the descending limb but is diluted by the ascending
limb. Electrolytes and urea are retained in the interstitium by this arrangement.
DCT and collecting duct concentrate the filtrate about four times, i.e., from 300
mOsmolL–1 to 1200 mOsmolL–1, an excellent mechanism of conservation of water.
Urine is stored in the urinary bladder till a voluntary signal from CNS carries out
its release through urethra, i.e., micturition. Skin, lungs and liver also assist in
excretion.
</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->