 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Plant Growth and Development</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Plant Growth and Development</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Plant Growth and Development</h3>
            <p class="chapSummary">Growth is one of the most conspicuous events in any living organism. It is an
irreversible increase expressed in parameters such as size, area, length, height,
volume, cell number etc. It conspicuously involves increased protoplasmic material.
In plants, meristems are the sites of growth. Root and shoot apical meristems
sometimes alongwith intercalary meristem, contribute to the elongation growth of
plant axes. Growth is indeterminate in higher plants. Following cell division in root
and shoot apical meristem cells, the growth could be arithmetic or geometrical.
Growth may not be and generally is not sustained at a high rate throughout the life
of cell/tissue/organ/organism. One can define three principle phases of growth –
the lag, the log and the senescent phase. When a cell loses the capacity to divide, it
leads to differentiation. Differentiation results in development of structures that is
commensurate with the function the cells finally has to perform. General principles
for differentiation for cell, tissues and organs are similar. A differentiated cell may
dedifferentiate and then redifferentiate. Since differentiation in plants is open, the
development could also be flexible, i.e., the development is the sum of growth and
differentiation. Plant exhibit plasticity in development.
Plant growth and development are under the control of both intrinsic and
extrinsic factors. Intercellular intrinsic factors are the chemical substances, called
plant growth regulators (PGR). There are diverse groups of PGRs in plants, principally
belonging to five groups: auxins, gibberellins, cytokinins, abscisic acid and ethylene.
These PGRs are synthesised in various parts of the plant; they control different
differentiation and developmental events. Any PGR has diverse physiological effects
on plants. Diverse PGRs also manifest similar effects. PGRs may act synergistically
or antagonistically. Plant growth and development is also affected by light,
temperature, nutrition, oxygen status, gravity and such external factors.
Flowering in some plants is induced only when exposed to certain duration of
photoperiod. Depending on the nature of photoperiod requirements, the plants are
called short day plants, long day plants and day-neutral plants. Certain plants
also need to be exposed to low temperature so as to hasten flowering later in life.
This treatement is known as vernalisation.
</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->