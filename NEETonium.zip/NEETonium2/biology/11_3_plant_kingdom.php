 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Plant Kingdom</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Plant Kingdom</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Plant Kingdom</h3>
            <p class="chapSummary">Plant kingdom includes algae, bryophytes, pteridophytes, gymnosperms and
angiosperms. Algae are chlorophyll-bearing simple, thalloid, autotrophic and
largely aquatic organisms. Depending on the type of pigment possesed and the
type of stored food, algae are classfied into three classes, namely Chlorophyceae,
Phaeophyceae and Rhodophyceae. Algae usually reproduce vegetatively by
fragmentation, asexually by formation of different types of spores and sexually by
formation of gametes which may show isogamy, anisogamy or oogamy.
Bryophytes are plants which can live in soil but are dependent on water for
sexual reproduction. Their plant body is more differentiated than that of algae. It
is thallus-like and prostrate or erect and attached to the substratum by rhizoids.
They possess root-like, leaf-like and stem-like structures. The bryophytes are
divided into liverworts and mosses. The plant body of liverworts is thalloid and
dorsiventral whereas mosses have upright, slender axes bearing spirally arranged
leaves. The main plant body of a bryophyte is gamete-producing and is called a
gametophyte. It bears the male sex organs called antheridia and female sex organs
called archegonia. The male and female gametes produced fuse to form zygote
which produces a multicellular body called a sporophyte. It produces haploid
spores. The spores germinate to form gametophytes.
In pteridophytes the main plant is a sporophyte which is differentiated into
true root, stem and leaves. These organs possess well-differentiated vascular
tissues. The sporophytes bear sporangia which produce spores. The spores
germinate to form gametophytes which require cool, damp places to grow. The
gametophytes bear male and female sex organs called antheridia and archegonia,
respectively. Water is required for transfer of male gametes to archegonium where
zygote is formed after fertilisation. The zygote produces a sporophyte.
The gymnosperms are the plants in which ovules are not enclosed by any
ovary wall. After fertilisation the seeds remain exposed and therefore these plants
are called naked-seeded plants. The gymnosperms produce microspores and
megaspores which are produced in microsporangia and megasporangia borne on
the sporophylls. The sporophylls – microsporophylls and megasporophylls – are
arranged spirally on axis to form male and female cones, respectively. The pollen
grain germinates and pollen tube releases the male gamete into the ovule, where it
fuses with the egg cell in archegonia. Following fertilisation, the zygote develops
into embryo and the ovules into seeds.
In angiosperms, the male sex organs (stamen) and female sex organs (pistil)
are borne in a flower. Each stamen consists of a filament and an anther. The anther
produces pollen grains (male gametophyte) after meiosis. The pistil consists of an
ovary enclosing one to many ovules. Within the ovule is the female gametophyte
or embryo sac which contains the egg cell. The pollen tube enters the embryo-sac
where two male gametes are discharged. One male gamete fuses with egg cell
(syngamy) and other fuses with diploid secondary nucleus (triple fusion). This
phenomenon of two fusions is called double fertilisation and is unique to
angiosperms. The angiosperms are divided into two classes – the dicotyledons
and the monocotyledons.
During the life cycle of any sexually reproducing plant, there is alternation of
generations between gamete producing haploid gametophyte and spore producing
diploid sporophyte. However, different plant groups as well as individuals may
show different patterns of life cycles – haplontic, diplontic or intermediate.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->