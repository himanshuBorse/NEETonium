 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Cell Cycle and Cell Division</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Cell Cycle and Cell Division</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Cell Cycle and Cell Division</h3>
            <p class="chapSummary">According to the cell theory, cells arise from preexisting cells. The process by
which this occurs is called cell division. Any sexually reproducing organism
starts its life cycle from a single-celled zygote. Cell division does not stop with
the formation of the mature organism but continues throughout its life cycle.
The stages through which a cell passes from one division to the next is called
the cell cycle. Cell cycle is divided into two phases called (i) Interphase – a
period of preparation for cell division, and (ii) Mitosis (M phase) – the actual
period of cell division. Interphase is further subdivided into G1
, S and G2
. G1
phase is the period when the cell grows and carries out normal metabolism.
Most of the organelle duplication also occurs during this phase. S phase marks
the phase of DNA replication and chromosome duplication. G2
 phase is the
period of cytoplasmic growth. Mitosis is also divided into four stages namely
prophase, metaphase, anaphase and telophase. Chromosome condensation
occurs during prophase. Simultaneously, the centrioles move to the opposite
poles. The nuclear envelope and the nucleolus disappear and the spindle
fibres start appearing. Metaphase is marked by the alignment of chromosomes
at the equatorial plate. During anaphase the centromeres divide and the
chromatids start moving towards the two opposite poles. Once the chromatids
reach the two poles, the chromosomal elongation starts, nucleolus and the
nuclear membrane reappear. This stage is called the telophase. Nuclear
division is then followed by the cytoplasmic division and is called cytokinesis.
Mitosis thus, is the equational division in which the chromosome number of
the parent is conserved in the daughter cell.
In contrast to mitosis, meiosis occurs in the diploid cells, which are destined to
form gametes. It is called the reduction division since it reduces the chromosome
number by half while making the gametes. In sexual reproduction when the two
gametes fuse the chromosome number is restored to the value in the parent.
Meiosis is divided into two phases – meiosis I and meiosis II. In the first meiotic
division the homologous chromosomes pair to form bivalents, and undergo crossing
over. Meiosis I has a long prophase, which is divided further into five phases.
These are leptotene, zygotene, pachytene, diplotene and diakinesis. During
metaphase I the bivalents arrange on the equatorial plate. This is followed by
anaphase I in which homologous chromosomes move to the opposite poles with
both their chromatids. Each pole receives half the chromosome number of the
parent cell. In telophase I, the nuclear membrane and nucleolus reappear. Meiosis
II is similar to mitosis. During anaphase II the sister chromatids separate. Thus at
the end of meiosis four haploid cells are formed</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->