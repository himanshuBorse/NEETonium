 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Chemical Coordination and Integration</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/biology.php">Biology</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Chemical Coordination and Integration</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Chemical Coordination and Integration</h3>
            <p class="chapSummary">There are special chemicals which act as hormones and provide chemical
coordination, integration and regulation in the human body. These hormones
regulate metabolism, growth and development of our organs, the endocrine glands
or certain cells. The endocrine system is composed of hypothalamus, pituitary
and pineal, thyroid, adrenal, pancreas, parathyroid, thymus and gonads (testis
and ovary). In addition to these, some other organs, e.g., gastrointestinal tract,
kidney, heart etc., also produce hormones. The pituitary gland is divided into
three major parts, which are called as pars distalis, pars intermedia and pars
nervosa. Pars distalis produces six trophic hormones. Pars intermedia secretes
only one hormone, while pars nervosa (neurohypophysis) secretes two hormones.
The pituitary hormones regulate the growth and development of somatic tissues
and activities of peripheral endocrine glands. Pineal gland secretes melatonin, which
plays a very important role in the regulation of 24-hour (diurnal) rhythms of our
body (e.g., rhythms of sleep and state of being awake, body temperature, etc.). The
thyroid gland hormones play an important role in the regulation of the basal
metabolic rate, development and maturation of the central neural system,
erythropoiesis, metabolism of carbohydrates, proteins and fats, menstrual cycle.
Another thyroid hormone, i.e., thyrocalcitonin regulates calcium levels in our blood
by decreasing it. The parathyroid glands secrete parathyroid hormone (PTH) which
increases the blood Ca2+ levels and plays a major role in calcium homeostasis. The
thymus gland secretes thymosins which play a major role in the differentiation of
T-lymphocytes, which provide cell-mediated immunity. In addition, thymosins
also increase the production of antibodies to provide humoral immunity. The
adrenal gland is composed of the centrally located adrenal medulla and the outer
adrenal cortex. The adrenal medulla secretes epinephrine and norepinephrine.
These hormones increase alertness, pupilary dilation, piloerection, sweating, heart
beat, strength of heart contraction, rate of respiration, glycogenolysis, lipolysis,
proteolysis. The adrenal cortex secretes glucocorticoids and mineralocorticoids.
Glucocorticoids stimulate gluconeogenesis, lipolysis, proteolysis, erythropoiesis,
cardio-vascular system, blood pressure, and glomerular filtration rate and inhibit
inflammatory reactions by suppressing the immune response. Mineralocorticoids
regulate water and electrolyte contents of the body. The endocrine pancreas secretes
glucagon and insulin. Glucagon stimulates glycogenolysis and gluconeogenesis
resulting in hyperglycemia. Insulin stimulates cellular glucose uptake and
utilisation, and glycogenesis resulting in hypoglycemia. Insulin deficiency
and/or insulin resistance result in a disease called diabetes mellitus.
The testis secretes androgens, which stimulate the development, maturation
and functions of the male accessory sex organs, appearance of the male secondary
sex characters, spermatogenesis, male sexual behaviour, anabolic pathways and
erythropoiesis. The ovary secretes estrogen and progesterone. Estrogen stimulates
growth and development of female accessory sex organs and secondary sex
characters. Progesterone plays a major role in the maintenance of pregnancy as
well as in mammary gland development and lactation. The atrial wall of the heart
produces atrial natriuretic factor which decreases the blood pressure. Kidney
produces erythropoietin which stimulates erythropoiesis. The gastrointestinal tract
secretes gastrin, secretin, cholecystokinin and gastric inhibitory peptide. These
hormones regulate the secretion of digestive juices and help in digestion.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/biologySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->