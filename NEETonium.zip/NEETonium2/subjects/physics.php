<?php
    include "../resources/header.php";
?>
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Physics MCQs </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Physics Chapters</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="row justify-content-center align-items-center">
    
<div class="col-lg-8 py-3">
<div class="widget-wrap">
            <h3 class="widget-title text-center"> Physics Chapter</h3>
            <div class="tag-clouds">
              <h4>11<sup>th</sup></h4>
              <a href="../physics/11_1_physical_world.php" class="tag-cloud-link">Physical World</a>
              <a href="../physics/11_2_unit_measure.php" class="tag-cloud-link">Units and Measurement</a>
              <a href="../physics/11_3_motion_straight_line.php" class="tag-cloud-link">Motion in a Straight Line</a>
              <a href="../physics/11_4_motion_plane.php" class="tag-cloud-link">Motion in a Plane</a>
              <a href="../physics/11_5_law_motion.php" class="tag-cloud-link">Laws of Motion</a>
              <a href="../physics/11_6_work_energy_power.php" class="tag-cloud-link">Work, Energy and Power</a>
              <a href="../physics/11_7_sys_particle_rotate.php" class="tag-cloud-link">Systems of Partilces and Rotational Motion</a>
              <a href="../physics/11_8_gravitation.php" class="tag-cloud-link">Gravitation</a>
              <a href="../physics/11_9_mech_prop_solid.php" class="tag-cloud-link">Mechanical Properties of Solids</a>
              <a href="../physics/11_10_mech_prop_fluid.php" class="tag-cloud-link">Mechanical Properties of Fluids</a>
              <a href="../physics/11_11_term_prop_matter.php" class="tag-cloud-link">Termal Properties of Matters</a>
              <a href="../physics/11_12_thermodynamic.php" class="tag-cloud-link">Mineral Thermodynamics</a>
              <a href="../physics/11_13_kinetic_theory.php" class="tag-cloud-link">Kinetic Theory</a>
              <a href="../physics/11_14_oscilation.php" class="tag-cloud-link">Oscilations</a>
              <a href="../physics/11_15_waves.php" class="tag-cloud-link">Waves</a>

              <h4>12<sup>th</sup></h4>
              <a href="../physics/12_1_elec_charge_field.php" class="tag-cloud-link">Electric Charges and Fields</a>
              <a href="../physics/12_2_elecstat_capaci.php" class="tag-cloud-link">Electrostatic Potential and Capacitance</a>
              <a href="../physics/12_3_current_elec.php" class="tag-cloud-link">Current Electricity</a>
              <a href="../physics/12_4_mov_charge_magnet.php" class="tag-cloud-link">Moving Charge and Magnetism</a>
              <a href="../physics/12_5_mag_matter.php" class="tag-cloud-link">Magnetism and Matter</a>
              <a href="../physics/12_6_electromag_induc.php" class="tag-cloud-link">Electromagnetic Induction</a>
              <a href="../physics/12_7_alter_current.php" class="tag-cloud-link">Alternating Current</a>
              <a href="../physics/12_8_elecmag_wave.php" class="tag-cloud-link">Electromagnetic Waves</a>
              <a href="../physics/12_9_ray_optic_instru.php" class="tag-cloud-link">Ray Optics and Optical Instruments</a>
              <a href="../physics/12_10_wave_optic.php" class="tag-cloud-link">Wave Optics</a>
              <a href="../physics/12_11_dual_nature_rad_matter.php" class="tag-cloud-link">Dual Nature of Radiation and Matters</a>
              <a href="../physics/12_12_atoms.php" class="tag-cloud-link">Atoms</a>
              <a href="../physics/12_13_nucles.php" class="tag-cloud-link">Nucles</a>
              <a href="../physics/12_14_semiconductor.php" class="tag-cloud-link">Semiconductor Electronics: Materials, Devices and Simple Circuits</a>
            </div>
          </div>
</div>
</div>

<?php
    include "../resources/footer.php";
?>