<?php
    include "../resources/header.php";
?>
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Biology MCQs </h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Biology Chapters</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="row justify-content-center align-items-center">
    
<div class="col-lg-8 py-3">
<div class="widget-wrap">
            <h3 class="widget-title text-center"> Biology Chapter</h3>
            <div class="tag-clouds">
                <h4>11<sup>th</sup></h4>
              <a href="../biology/11_1_the_living_world.php" class="tag-cloud-link">The Living World</a>
              <a href="../biology/11_2_bio_classification.php" class="tag-cloud-link">Biological Classification</a>
              <a href="../biology/11_3_plant_kingdom.php" class="tag-cloud-link">Plant Kingdom</a>
              <a href="../biology/11_4_animal_kingdom.php" class="tag-cloud-link">Animal Kingdom</a>
              <a href="../biology/11_5_morp_flowering_plants.php" class="tag-cloud-link">Morphology of Flowering Plants</a>
              <a href="../biology/11_6_anto_flowering_plants.php" class="tag-cloud-link">Anatomy of Flowering Plants</a>
              <a href="../biology/11_7_struc_org_animals.php" class="tag-cloud-link">Anatomy of Flowering Plants</a>
              <a href="../biology/11_8_cell_unit_life.php" class="tag-cloud-link">Cell The Unit of Life</a>
              <a href="../biology/11_9_biomolecules.php" class="tag-cloud-link">Biomolecules</a>
              <a href="../biology/11_10_cell_cycle_div.php" class="tag-cloud-link">Cell Cycle and Cell Division</a>
              <a href="../biology/11_11_tans_plants.php" class="tag-cloud-link">Transport in Plants</a>
              <a href="../biology/11_12_mineral_nutri.php" class="tag-cloud-link">Mineral Nutrition</a>
              <a href="../biology/11_13_photo_higher_plants.php" class="tag-cloud-link">Photosynthesis in Higher Plants</a>
              <a href="../biology/11_14_resp_in_plants.php" class="tag-cloud-link">Respiration in Plants</a>
              <a href="../biology/11_15_plant_grow_dev.php" class="tag-cloud-link">Plant Growth and Development</a>
              <a href="../biology/11_16_digestion_absorp.php" class="tag-cloud-link">Digestion and Absorption</a>
              <a href="../biology/11_17_breath_ex_gas.php" class="tag-cloud-link">Breathing and Exchange of Gases</a>
              <a href="../biology/11_18_body_fluid_circu.php" class="tag-cloud-link">Body Fluids and Circulation</a>
              <a href="../biology/11_19_excreation_elimini.php" class="tag-cloud-link">Excretory Products and their Elimination</a>
              <a href="../biology/11_20_loco_movement.php" class="tag-cloud-link">Locomotion and Movement</a>
              <a href="../biology/11_21_neu_control_coordi.php" class="tag-cloud-link">Neural Control and Coordination</a>
              <a href="../biology/11_22_chemi_coordination.php" class="tag-cloud-link">Chemical Coordination and integration</a>

              <h4>12<sup>th</sup></h4>
              <a href="../biology/12_1_repro_organism.php" class="tag-cloud-link">Reproduction in Organisms</a>
              <a href="../biology/12_2_repro_flowering_plants.php" class="tag-cloud-link">Sexual Reproduction in Flowering Plants</a>
              <a href="../biology/12_3_human_repro.php" class="tag-cloud-link">Human Reproduction</a>
              <a href="../biology/12_4_repro_health.php" class="tag-cloud-link">Reproductive Health</a>
              <a href="../biology/12_5_princi_inheritance.php" class="tag-cloud-link">Principles of Inheritance and Variation</a>
              <a href="../biology/12_6_molecu_inheritance.php" class="tag-cloud-link">Molecular Basis of Inheritance</a>
              <a href="../biology/12_7_evolution.php" class="tag-cloud-link">Evolution</a>
              <a href="../biology/12_8_human_health_dis.php" class="tag-cloud-link">Human Health and Diseases</a>
              <a href="../biology/12_9_strat_food_pro.php" class="tag-cloud-link">Strategies for Enhancement in Food Production</a>
              <a href="../biology/12_10_micro_human_wel.php" class="tag-cloud-link">Microbes in Human Welfarev</a>
              <a href="../biology/12_11_biotech_princi.php" class="tag-cloud-link">Biotechnology Principles and Processes</a>
              <a href="../biology/12_12_biotect_app.php" class="tag-cloud-link">Biotechnology: and its Application</a>
              <a href="../biology/12_13_org_popul.php" class="tag-cloud-link">Organisms and Populations</a>
              <a href="../biology/12_14_ecosystem.php" class="tag-cloud-link">Ecosystem</a>
              <a href="../biology/12_15_biodiv_conserve.php" class="tag-cloud-link">Biodiversity and Conservation</a>
              <a href="../biology/12_16_environ_issue.php" class="tag-cloud-link">Environmental Issues</a>

            </div>
          </div>
</div>
</div>

<?php
    include "../resources/footer.php";
?>