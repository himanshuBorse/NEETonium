<div class="customPagination">

                        <li class="custom-page-item previous-page disable"><a class="custom-page-link" href="#">Prev</a></li>
                        <li class="custom-page-item current-page active"><a class="custom-page-link" href="#">1</a></li>
                        <li class="custom-page-item dots"><a class="custom-page-link" href="#">...</a></li>
                        <li class="custom-page-item current-page"><a class="custom-page-link" href="#">5</a></li>
                        <li class="custom-page-item current-page"><a class="custom-page-link" href="#">6</a></li>
                        <li class="custom-page-item dots"><a class="custom-page-link" href="#">...</a></li>
                        <li class="custom-page-item current-page"><a class="custom-page-link" href="#">10</a></li>

                    </div>