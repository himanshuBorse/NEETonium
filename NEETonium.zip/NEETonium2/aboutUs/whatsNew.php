<!--Start header -->
<?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">What's New</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">What's New</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="card-page mt-3">
          <h3>NEETonium 1.1</h3>
          <p>NEETonium, 1.1 includes </p>
          <ul class="theme-list">
            <li class="list-item">Chapter Wise Summaty (NCERT referral)</li>
            <li class="list-item">15 Selected question for every chapters</li>
            <li class="list-item">No Solution are provided for the selected question. Try your best to solve thme</li> 
          </ul>
        </div>
        <div class="card-page mt-3">
          <h3>NEETonium 1.2 (upcoming)</h3>
          <p>NEETonium, 1.2 will include </p>
          <ul class="theme-list">
            <li class="list-item">Full chapter of the NCERT with bifurcated topics</li>
            <li class="list-item">Seperate previous year questions prepartion feature</li>
          </ul>
          
        </div>
        <div class="card-page mt-3">
          <h3>NEETonium</h3>
          <p>For information on the updates regarding NEETonium, please contact us on mail  :&nbsp;<a href="mailto:neetonium@gmail.com" target="_newtab">neetonium@gmail.com</a>&nbsp;</p>
        </div>
      </div>
    </div>
  </div>
</div>



<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->