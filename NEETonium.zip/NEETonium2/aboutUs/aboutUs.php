<!--Start header -->
<?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">About Us</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">About Us</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section pt-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-8">
        <div class="card-page">
          <h5 class="fg-primary">NEETonium</h5>
          <hr>
          <p>NEETonium is the platform for the preparation of National Eligibilituy cum Entrance Test. In its version 1.1 the NEETonium provides
             the chapterwise summary  and 15 verified questions of each chapter for the pracitice purpose</p>
          <p>The new features will be made available by upgrading NEETonium version by version.</p>

          <!-- Video -->
          <div class="text-center py-5">
            <!-- <embed class="embed-video" src="https://www.youtube.com/embed/k1D0_wFlXgo?list=PLl-K7zZEsYLmnJ_FpMOZgyg6XcIGBu2OX"> -->
            <video class="embed-video" src="../aboutUs/aboutNEET.mp4" controls muted autoplay></video>
          </div>
        </div>
        
        
      </div>
    </div>
  </div>
</div>



<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->