
    function func(solid) {
        console.log(solid);
        console.log("dsglsjg;larg");
        var text = solid.toString();
        var status = document.getElementById(text);
        console.log(status);
        if (status.style.display === "none") {
            status.style.display = "block";
        } else {
            status.style.display = "none";
        }
    }
