 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">The p-Block Elements</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">The p-Block Elements</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">The p-Block Elements</h3>
            <p class="chapSummary">
            p-Block of the periodic table is unique in terms of having all types of elements – metals,
non-metals and metalloids. There are six groups of p-block elements in the periodic
table numbering from 13 to 18. Their valence shell electronic configuration is ns2
np1–6
(except for He). Differences in the inner core of their electronic configuration greatly
influence their physical and chemical properties. As a consequence of this, a lot of
variation in properties among these elements is observed. In addition to the group oxidation
state, these elements show other oxidation states differing from the total number of valence
electrons by unit of two. While the group oxidation state is the most stable for the lighter
elements of the group, lower oxidation states become progressively more stable for the
heavier elements. The combined effect of size and availability of d orbitals considerably
influences the ability of these elements to form π-bonds. While the lighter elements form
pπ–pπ bonds, the heavier ones form dπ–pπ or dπ–dπ bonds. Absence of d orbital in
second period elements limits their maximum covalence to 4 while heavier ones can
exceed this limit.
Boron is a typical non-metal and the other members are metals. The availability of 3
valence electrons (2s
2
2p1
) for covalent bond formation using four orbitals (2s, 2px, 2py and
2pz
) leads to the so called electron deficiency in boron compounds. This deficiency
makes them good electron acceptor and thus boron compounds behave as Lewis acids.
Boron forms covalent molecular compounds with dihydrogen as boranes, the simplest of
which is diborane, B2H6. Diborane contains two bridging hydrogen atoms between two
boron atoms; these bridge bonds are considered to be three-centre two-electron bonds.
The important compounds of boron with dioxygen are boric acid and borax. Boric acid,
B(OH)3 is a weak monobasic acid; it acts as a Lewis acid by accepting electrons from
hydroxyl ion. Borax is a white crystalline solid of formula Na2[B4O5(OH)4]·8H2O. The borax
bead test gives characteristic colours of transition metals.
Aluminium exhibits +3 oxidation state. With heavier elements +1 oxidation state gets
progressively stabilised on going down the group. This is a consequence of the so called
inert pair effect.
Carbon is a typical non-metal forming covalent bonds employing all its four valence
electrons (2s2
2p2
). It shows the property of catenation, the ability to form chains or
rings, not only with C–C single bonds but also with multiple bonds (C=C or C≡C). The
tendency to catenation decreases as C>>Si>Ge ~ Sn > Pb. Carbon provides one of the
best examples of allotropy. Three important allotropes of carbon are diamond, graphite
and fullerenes. The members of the carbon family mainly exhibit +4 and +2 oxidation
states; compouds in +4 oxidation states are generally covalent in nature. The tendency
to show +2 oxidation state increases among heavier elements. Lead in +2 state is stable
whereas in +4 oxidation state it is a strong oxidising agent. Carbon also exhibits negative
oxidation states. It forms two important oxides: CO and CO2. Carbon monoxide is neutral
whereas CO2 is acidic in nature. Carbon monoxide having lone pair of electrons on C
forms metal carbonyls. It is deadly poisonous due to higher stability of its haemoglobin
complex as compared to that of oxyhaemoglobin complex. Carbon dioxide as such is not
toxic. However, increased content of CO2 in atmosphere due to combustion of fossil fuels
and decomposition of limestone is feared to cause increase in ‘green house effect’. This,
in turn, raises the temperature of the atmosphere and causes serious complications.
Silica, silicates and silicones are important class of compounds and find applications
in industry and technology
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer --> 