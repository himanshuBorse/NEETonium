 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">asphtesfgj123</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">asphtesfgj123</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Chemistry in Everyday Life</h3>
            <p class="chapSummary">
            Chemistry is essentially the study of materials and the development of new
materials for the betterment of humanity. A drug is a chemical agent, which
affects human metabolism and provides cure from ailment. If taken in doses
higher than recommended, these may have poisonous effect. Use of chemicals
for therapeutic effect is called chemotherapy. Drugs usually interact with
biological macromolecules such as carbohydrates, proteins, lipids and nucleic
acids. These are called target molecules. Drugs are designed to interact with
specific targets so that these have the least chance of affecting other targets.
This minimises the side effects and localises the action of the drug. Drug chemistry
centres around arresting microbes/destroying microbes, preventing the body
from various infectious diseases, releasing mental stress, etc. Thus, drugs like
analgesics, antibiotics, antiseptics, disinfectants, antacids and tranquilizers are
used for specific purpose. To check the population explosion, antifertility drugs
have also become prominent in our life.
Food additives such as preservatives, sweetening agents, flavours,
antioxidants, edible colours and nutritional supplements are added to the
food to make it attractive, palatable and add nutritive value. Preservatives are
added to the food to prevent spoilage due to microbial growth. Artificial sweeteners
are used by those who need to check the calorie intake or are diabetic and want
to avoid taking sucrose.
These days, detergents are much in vogue and get preference over soaps
because they work even in hard water. Synthetic detergents are classified into
three main categories, namely: anionic, cationic and non-ionic, and each
category has its specific uses. Detergents with straight chain of hydrocarbons
are preferred over branched chain as the latter are non-biodegradable and
consequently cause environmental pollution.
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->