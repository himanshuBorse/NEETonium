 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Biomolecules</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Biomolecules</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Biomolecules</h3>
            <p class="chapSummary">
            Carbohydrates are optically active polyhydroxy aldehydes or ketones or molecules which
provide such units on hydrolysis. They are broadly classified into three groups —
monosaccharides, disaccharides and polysaccharides. Glucose, the most important
source of energy for mammals, is obtained by the digestion of starch. Monosaccharides
are held together by glycosidic linkages to form disaccharides or polysaccharides.
Proteins are the polymers of about twenty different α-amino acids which are
linked by peptide bonds. Ten amino acids are called essential amino acids because
they cannot be synthesised by our body, hence must be provided through diet. Proteins
perform various structural and dynamic functions in the organisms. Proteins which
contain only α-amino acids are called simple proteins. The secondary or tertiary
structure of proteins get disturbed on change of pH or temperature and they are not
able to perform their functions. This is called denaturation of proteins. Enzymes are
biocatalysts which speed up the reactions in biosystems. They are very specific and
selective in their action and chemically majority of enzymes are proteins.
Vitamins are accessory food factors required in the diet. They are classified as
fat soluble (A, D, E and K) and water soluble (Β group and C). Deficiency of vitamins
leads to many diseases.
Nucleic acids are the polymers of nucleotides which in turn consist of a base,
a pentose sugar and phosphate moiety. Nucleic acids are responsible for the transfer
of characters from parents to offsprings. There are two types of nucleic acids —
DNA and RNA. DNA contains a five carbon sugar molecule called 2-deoxyribose
whereas RNA contains ribose. Both DNA and RNA contain adenine, guanine and
cytosine. The fourth base is thymine in DNA and uracil in RNA. The structure of
DNA is a double strand whereas RNA is a single strand molecule. DNA is the
chemical basis of heredity and have the coded message for proteins to be synthesised
in the cell. There are three types of RNA — mRNA, rRNA and tRNA which actually
carry out the protein synthesis in the cell.
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->