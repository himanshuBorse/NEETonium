 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Solutions</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Solutions</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Solutions</h3>
            <p class="chapSummary">
            A solution is a homogeneous mixture of two or more substances. Solutions are
classified as solid, liquid and gaseous solutions. The concentration of a solution is
expressed in terms of mole fraction, molarity, molality and in percentages. The
dissolution of a gas in a liquid is governed by Henry’s law, according to which, at a
given temperature, the solubility of a gas in a liquid is directly proportional to
the partial pressure of the gas. The vapour pressure of the solvent is lowered by
the presence of a non-volatile solute in the solution and this lowering of vapour
pressure of the solvent is governed by Raoult’s law, according to which the relative
lowering of vapour pressure of the solvent over a solution is equal to the mole
fraction of a non-volatile solute present in the solution. However, in a binary
liquid solution, if both the components of the solution are volatile then another
form of Raoult’s law is used. Solutions which obey Raoult’s law over the entire range
of concentration are called ideal solutions. Two types of deviations from Raoult’s
law, called positive and negative deviations are observed. Azeotropes arise due to
very large deviations from Raoult’s law.
The properties of solutions which depend on the number of solute particles and
are independent of their chemical identity are called colligative properties. These
are lowering of vapour pressure, elevation of boiling point, depression of freezing
point and osmotic pressure. The process of osmosis can be reversed if a pressure
higher than the osmotic pressure is applied to the solution. Colligative properties
have been used to determine the molar mass of solutes. Solutes which dissociate in
solution exhibit molar mass lower than the actual molar mass and those which
associate show higher molar mass than their actual values.
Quantitatively, the extent to which a solute is dissociated or associated can be
expressed by van’t Hoff factor i. This factor has been defined as ratio of normal
molar mass to experimentally determined molar mass or as the ratio of observed
colligative property to the calculated colligative property.
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->