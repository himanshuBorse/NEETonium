 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Some Basic Concepts of Chemistry</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Some Basic Concepts of Chemistry</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Some Basic Concepts of Chemistry</h3>
            <p class="chapSummary">
            Chemistry, as we understand it today is not a very old discipline. People in ancient
India, already had the knowledge of many scientific phenomenon much before the
advent of modern science. They applied the knowledge in various walks of life.
The study of chemistry is very important as its domain encompasses every sphere
of life. Chemists study the properties and structure of substances and the changes
undergone by them. All substances contain matter, which can exist in three states
– solid, liquid or gas. The constituent particles are held in different ways in these
states of matter and they exhibit their characteristic properties. Matter can also be
classified into elements, compounds or mixtures. An element contains particles of
only one type, which may be atoms or molecules. The compounds are formed where
atoms of two or more elements combine in a fixed ratio to each other. Mixtures occur
widely and many of the substances present around us are mixtures.
When the properties of a substance are studied, measurement is inherent. The
quantification of properties requires a system of measurement and units in which
the quantities are to be expressed. Many systems of measurement exist, of which
the English and the Metric Systems are widely used. The scientific community, however,
has agreed to have a uniform and common system throughout the world, which is
abbreviated as SI units (International System of Units).
Since measurements involve recording of data, which are always associated with a
certain amount of uncertainty, the proper handling of data obtained by measuring the
quantities is very important. The measurements of quantities in chemistry are spread
over a wide range of 10^–31 to 10^+23. Hence, a convenient system of expressing the numbers
in scientific notation is used. The uncertainty is taken care of by specifying the number
of significant figures, in which the observations are reported. The dimensional analysis
helps to express the measured quantities in different systems of units. Hence, it is possible
to interconvert the results from one system of units to another.
The combination of different atoms is governed by basic laws of chemical combination
— these being the Law of Conservation of Mass, Law of Definite Proportions, Law of
Multiple Proportions, Gay Lussac’s Law of Gaseous Volumes and Avogadro Law. All
these laws led to the Dalton’s atomic theory, which states that atoms are building
blocks of matter. The atomic mass of an element is expressed relative to 12C isotope of
carbon, which has an exact value of 12u. Usually, the atomic mass used for an element is
the average atomic mass obtained by taking into account the natural abundance of
different isotopes of that element. The molecular mass of a molecule is obtained by
taking sum of the atomic masses of different atoms present in a molecule. The molecular
formula can be calculated by determining the mass per cent of different elements present
in a compound and its molecular mass.
The number of atoms, molecules or any other particles present in a given system are
expressed in the terms of Avogadro constant (6.022 × 10^23). This is known as 1 mol of
the respective particles or entities.
Chemical reactions represent the chemical changes undergone by different elements
and compounds. A balanced chemical equation provides a lot of information. The
coefficients indicate the molar ratios and the respective number of particles taking part
in a particular reaction. The quantitative study of the reactants required or the products
formed is called stoichiometry. Using stoichiometric calculations, the amount of one or
more reactant(s) required to produce a particular amount of product can be determined
and vice-versa. The amount of substance present in a given volume of a solution is
expressed in number of ways, e.g., mass per cent, mole fraction, molarity and molality.

            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                        <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->