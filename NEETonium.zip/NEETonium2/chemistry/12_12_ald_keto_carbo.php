 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Aldehydes, Ketones and Carboxylic Acids</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Aldehydes, Ketones and Carboxylic Acids</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Aldehydes, Ketones and Carboxylic Acids</h3>
            <p class="chapSummary">
            Aldehydes, ketones and carboxylic acids are some of the important classes of
organic compounds containing carbonyl group. These are highly polar molecules.
Therefore, they boil at higher temperatures than the hydrocarbons and weakly
polar compounds such as ethers of comparable molecular masses. The lower
members are more soluble in water because they form hydrogen bonds with water.
The higher members, because of large size of hydrophobic chain of carbon atoms,
are insoluble in water but soluble in common organic solvents. Aldehydes are
prepared by dehydrogenation or controlled oxidation of primary alcohols and
controlled or selective reduction of acyl halides. Aromatic aldehydes may also be
prepared by oxidation of (i) methylbenzene with chromyl chloride or CrO3 in the
presence of acetic anhydride, (ii) formylation of arenes with carbon monoxide and
hydrochloric acid in the presence of anhydrous aluminium chloride, and (iii) cuprous
chloride or by hydrolysis of benzal chloride. Ketones are prepared by oxidation of
secondary alcohols and hydration of alkynes. Ketones are also prepared by reaction
of acyl chloride with dialkylcadmium. A good method for the preparation of aromatic
ketones is the Friedel-Crafts acylation of aromatic hydrocarbons with acyl chlorides
or anhydrides. Both aldehydes and ketones can be prepared by ozonolysis of alkenes.
Aldehydes and ketones undergo nucleophilic addition reactions onto the carbonyl
group with a number of nucleophiles such as, HCN, NaHSO3, alcohols (or diols),
ammonia derivatives, and Grignard reagents. The α-hydrogens in aldehydes and
ketones are acidic. Therefore, aldehydes and ketones having at least one α-hydrogen,
undergo Aldol condensation in the presence of a base to give α-hydroxyaldehydes
(aldol) and α-hydroxyketones(ketol), respectively. Aldehydes having no α-hydrogen
undergo Cannizzaro reaction in the presence of concentrated alkali. Aldehydes
and ketones are reduced to alcohols with NaBH4, LiAlH4, or by catalytic hydrogenation.
The carbonyl group of aldehydes and ketones can be reduced to a methylene group
by Clemmensen reduction or Wolff-Kishner reduction. Aldehydes are easily
oxidised to carboxylic acids by mild oxidising reagents such as Tollens’ reagent and
Fehling’s reagent. These oxidation reactions are used to distinguish aldehydes from
ketones. Carboxylic acids are prepared by the oxidation of primary alcohols, aldehydes
and alkenes by hydrolysis of nitriles, and by treatment of Grignard reagents with
carbon dioxide. Aromatic carboxylic acids are also prepared by side-chain oxidation
of alkylbenzenes. Carboxylic acids are considerably more acidic than alcohols and
most of simple phenols. Carboxylic acids are reduced to primary alcohols with LiAlH4,
or better with diborane in ether solution and also undergo α-halogenation with Cl2
and Br2 in the presence of red phosphorus (Hell-Volhard Zelinsky reaction).
Methanal, ethanal, propanone, benzaldehyde, formic acid, acetic acid and benzoic
acid are highly useful compounds in industry.

            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->