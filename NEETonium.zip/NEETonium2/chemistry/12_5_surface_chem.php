 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Surface Chemistry</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Surface Chemistry</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Surface Chemistry</h3>
            <p class="chapSummary">
            Adsorption is the phenomenon of attracting and retaining the molecules of a
substance on the surface of a solid resulting into a higher concentration on the
surface than in the bulk. The substance adsorbed is known as adsorbate and the
substance on which adsorption takes place is called adsorbent. In physisorption,
adsorbate is held to the adsorbent by weak van der Waals forces, and in
chemisorption, adsorbate is held to the adsorbent by strong chemical bond. Almost
all solids adsorb gases. The extent of adsorption of a gas on a solid depends upon
nature of gas, nature of solid, surface area of the solid, pressure of gas and
temperature of gas. The relationship between the extent of adsorption (x/m) and
pressure of the gas at constant temperature is known as adsorption isotherm.
A catalyst is a substance which enhances the rate of a chemical reaction without
itself getting used up in the reaction. The phenomenon using catalyst is known as
catalysis. In homogeneous catalysis, the catalyst is in the same phase as are the
reactants, and in heterogeneous catalysis the catalyst is in a different phase from
that of the reactants.
Colloidal solutions are intermediate between true solutions and suspensions.
The size of the colloidal particles range from 1 to 1000 nm. A colloidal system consists
of two phases - the dispersed phase and the dispersion medium. Colloidal systems
are classified in three ways depending upon (i) physical states of the dispersed phase
and dispersion medium (ii) nature of interaction between the dispersed phase and
dispersion medium and (iii) nature of particles of dispersed phase. The colloidal
systems show interesting optical, mechanical and electrical properties. The process
of changing the colloidal particles in a sol into the insoluble precipitate by addition
of some suitable electrolytes is known as coagulation. Emulsions are colloidal systems
in which both dispersed phase and dispersion medium are liquids. These can be of:
(i) oil in water type and (ii) water in oil type. The process of making emulsion is
known as emulsification. To stabilise an emulsion, an emulsifying agent or emulsifier
is added. Soaps and detergents are most frequently used as emulsifiers. Colloids find
several applications in industry as well as in daily life.
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->