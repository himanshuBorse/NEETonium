 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Coordination Compounds</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Coordination Compounds</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Coordination Compounds</h3>
            <p class="chapSummary">
            The chemistry of coordination compounds is an important and challenging
area of modern inorganic chemistry. During the last fifty years, advances in this
area, have provided development of new concepts and models of bonding and
molecular structure, novel breakthroughs in chemical industry and vital
insights into the functioning of critical components of biological systems.
The first systematic attempt at explaining the formation, reactions, structure
and bonding of a coordination compound was made by A. Werner. His theory
postulated the use of two types of linkages (primary and secondary) by a
metal atom/ion in a coordination compound. In the modern language of chemistry
these linkages are recognised as the ionisable (ionic) and non-ionisable (covalent)
bonds, respectively. Using the property of isomerism, Werner predicted the
geometrical shapes of a large number of coordination entities.
The Valence Bond Theory (VBT) explains with reasonable success, the
formation, magnetic behaviour and geometrical shapes of coordination compounds.
It, however, fails to provide a quantitative interpretation of magnetic behaviour
and has nothing to say about the optical properties of these compounds.
The Crystal Field Theory (CFT) to coordination compounds is based on
the effect of different crystal fields (provided by the ligands taken as point charges),
on the degeneracy of d orbital energies of the central metal atom/ion. The
splitting of the d orbitals provides different electronic arrangements in strong
and weak crystal fields. The treatment provides for quantitative estimations of
orbital separation energies, magnetic moments and spectral and stability
parameters. However, the assumption that ligands consititute point charges
creates many theoretical difficulties.
The metal–carbon bond in metal carbonyls possesses both σ and π character.
The ligand to metal is σ bond and metal to ligand is π bond. This unique synergic
bonding provides stability to metal carbonyls.
Coordination compounds are of great importance. These compounds provide
critical insights into the functioning and structures of vital components of
biological systems. Coordination compounds also find extensive applications in
metallurgical processes, analytical and medicinal chemistry.
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->