 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">The p-block Elements</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">The p-block Elements</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">The p-block Elements</h3>
            <p class="chapSummary">
            Groups 13 to 18 of the periodic table consist of p-block elements with their valence
shell electronic configuration ns2
np1–6. Groups 13 and 14 were dealt with in Class
XI. In this Unit remaining groups of the p-block have been discussed.
Group 15 consists of five elements namely, N, P, As, Sb and Bi which have
general electronic configuration ns2
np3
. Nitrogen differs from other elements of this
group due to small size, formation of pπ–pπ multiple bonds with itself and with
highly electronegative atom like O or C and non-availability of d orbitals to expand
its valence shell. Elements of group 15 show gradation in properties. They react with
oxygen, hydrogen and halogens. They exhibit two important oxidation states, + 3
and + 5 but +3 oxidation is favoured by heavier elements due to ‘inert pair effect’.
Dinitrogen can be prepared in laboratory as well as on industrial scale. It forms
oxides in various oxidation states as N2O, NO, N2O3, NO2, N2O4 and N2O5. These
oxides have resonating structures and have multiple bonds. Ammonia can be
prepared on large scale by Haber’s process. HNO3 is an important industrial
chemical. It is a strong monobasic acid and is a powerful oxidising agent. Metals
and non-metals react with HNO3 under different conditions to give NO or NO2.
Phosphorus exists as P4 in elemental form. It exists in several allotropic forms.
It forms hydride, PH3 which is a highly poisonous gas. It forms two types of halides as
PX3 and PX5. PCl3 is prepared by the reaction of white phosphorus with dry chlorine
while PCl5 is prepared by the reaction of phosphorus with SO2Cl2. Phosphorus forms
a number of oxoacids. Depending upon the number of P–OH groups, their basicity
varies. The oxoacids which have P–H bonds are good reducing agents.
The Group 16 elements have general electronic configuration ns2
np4
. They show
maximum oxidation state, +6. Gradation in physical and chemical properties is
observed in the group 16 elements. In laboratory, dioxygen is prepared by heating
KClO3 in presence of MnO2. It forms a number of oxides with metals. Allotropic form
of oxygen is O3 which is a highly oxidising agent. Sulphur forms a number of allotropes.
Of these, α– and β– forms of sulphur are the most important. Sulphur combines with
oxygen to give oxides such as SO2 and SO3. SO2 is prepared by the direct union of
sulphur with oxygen. SO2 is used in the manufacture of H2SO4. Sulphur forms a
number of oxoacids. Amongst them, the most important is H2SO4. It is prepared by
contact process. It is a dehydrating and oxidising agent. It is used in the manufacture
of several compounds.
Group 17 of the periodic table consists of the following elements F, Cl, Br, I and
At.These elements are extremely reactive and as such they are found in the
combined state only. The common oxidation state of these elements is –1. However,
highest oxidation state can be +7. They show regular gradation in physical and
chemical properties. They form oxides, hydrogen halides, interhalogen compounds
and oxoacids. Chlorine is conveniently obtained by the reaction of HCl with KMnO4.
HCl is prepared by heating NaCl with concentrated H2SO4. Halogens combine with
one another to form interhalogen compounds of the type XX1
n (n = 1, 3, 5, 7)
where X1 is lighter than X. A number of oxoacids of halogens are known. In the
structures of these oxoacids, halogen is the central atom which is bonded in each
case with one OH bond as X–OH. In some cases X = 0 bonds are also found.
Group 18 of the periodic table consists of noble gases. They have ns2 np6
 valence
shell electronic configuration except He which has 1s2
. All the gases except Rn
occur in atmosphere. Rn is obtained as the decay product of 226Ra.
Due to complete octet of outermost shell, they have less tendency to form
compounds. The best characterised compounds are those of xenon with fluorine
and oxygen only under certain conditions. These gases have several uses. Argon is
used to provide inert atmosphere, helium is used in filling balloons for meteorological
observations, neon is used in discharge tubes and fluorescent bulbs.
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->