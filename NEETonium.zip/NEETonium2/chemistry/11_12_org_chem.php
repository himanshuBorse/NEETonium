 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Organic Chemistry - Some Basic Principles and Techniques</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Organic Chemistry - Some Basic Principles and Techniques</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Organic Chemistry - Some Basic Principles and Techniques</h3>
            <p class="chapSummary">
            In this unit, we have learnt some basic concepts in structure and reactivity of organic
compounds, which are formed due to covalent bonding. The nature of the covalent bonding
in organic compounds can be described in terms of orbitals hybridisation concept,
according to which carbon can have sp3, sp2 and sp hybridised orbitals. The sp3, sp2 and
sp hybridised carbons are found in compounds like methane, ethene and ethyne
respectively. The tetrahedral shape of methane, planar shape of ethene and linear shape
of ethyne can be understood on the basis of this concept. A sp3 hybrid orbital can overlap
with 1s orbital of hydrogen to give a carbon - hydrogen (C–H) single bond (sigma, σ bond).
Overlap of a sp2 orbital of one carbon with sp2 orbital of another results in the formation
of a carbon–carbon σ bond. The unhybridised p orbitals on two adjacent carbons can
undergo lateral (side-by-side) overlap to give a pi (π) bond. Organic compounds can be
represented by various structural formulas. The three dimensional representation of
organic compounds on paper can be drawn by wedge and dash formula.
Organic compounds can be classified on the basis of their structure or the functional
groups they contain. A functional group is an atom or group of atoms bonded together
in a unique fashion and which determines the physical and chemical properties of the
compounds. The naming of the organic compounds is carried out by following a set of
rules laid down by the International Union of Pure and Applied Chemistry (IUPAC). In
IUPAC nomenclature, the names are correlated with the structure in such a way that
the reader can deduce the structure from the name.
Organic reaction mechanism concepts are based on the structure of the substrate
molecule, fission of a covalent bond, the attacking reagents, the electron displacement
effects and the conditions of the reaction. These organic reactions involve breaking and
making of covalent bonds. A covalent bond may be cleaved in heterolytic or homolytic
fashion. A heterolytic cleavage yields carbocations or carbanions, while a homolytic
cleavage gives free radicals as reactive intermediate. Reactions proceeding through
heterolytic cleavage involve the complimentary pairs of reactive species. These are electron
pair donor known as nucleophile and an electron pair acceptor known as electrophile.
The inductive, resonance, electromeric and hyperconjugation effects may help in
the polarisation of a bond making certain carbon atom or other atom positions as places
of low or high electron densities.
Organic reactions can be broadly classified into following types; substitution,
addition, elimination and rearrangement reactions.
Purification, qualitative and quantitative analysis of organic compounds are carried
out for determining their structures. The methods of purification namely : sublimation,
distillation and differential extraction are based on the difference in one or more physical
properties. Chromatography is a useful technique of separation, identification and
purification of compounds. It is classified into two categories : adsorption and partition
chromatography. Adsorption chromatography is based on differential adsorption of various
components of a mixture on an adsorbent. Partition chromatography involves continuous
partitioning of the components of a mixture between stationary and mobile phases. After
getting the compound in a pure form, its qualitative analysis is carried out for detection
of elements present in it. Nitrogen, sulphur, halogens and phosphorus are detected by
Lassaigne’s test. Carbon and hydrogen are estimated by determining the amounts of
carbon dioxide and water produced. Nitrogen is estimated by Dumas or Kjeldahl’s method
and halogens by Carius method. Sulphur and phosphorus are estimated by oxidising
them to sulphuric and phosphoric acids respectively. The percentage of oxygen is usually
determined by difference between the total percentage (100) and the sum of percentages
of all other elements present.
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->