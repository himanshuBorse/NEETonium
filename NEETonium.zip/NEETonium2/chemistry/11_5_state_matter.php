 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">States of Matter</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">States of Matter</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">States of Matter</h3>
            <p class="chapSummary">Intermolecular forces operate between the particles of matter. These forces differ from
pure electrostatic forces that exist between two oppositely charged ions. Also, these do
not include forces that hold atoms of a covalent molecule together through covalent
bond. Competition between thermal energy and intermolecular interactions determines
the state of matter. “Bulk” properties of matter such as behaviour of gases, characteristics
of solids and liquids and change of state depend upon energy of constituent particles
and the type of interaction between them. Chemical properties of a substance do not
change with change of state, but the reactivity depends upon the physical state.
Forces of interaction between gas molecules are negligible and are almost independent
of their chemical nature. Interdependence of some observable properties namely
pressure, volume, temperature and mass leads to different gas laws obtained from
experimental studies on gases. Boyle’s law states that under isothermal condition,
pressure of a fixed amount of a gas is inversely proportional to its volume. Charles’ law
Avogadro law states that equal volumes of
all gases under same conditions of temperature and pressure contain equal number of
molecules. Dalton’s law of partial pressure states that total pressure exerted by a
mixture of non-reacting gases is equal to the sum of partial pressures exerted by them.
Thus p = p1
+p2
+p3
+ ... . Relationship between pressure, volume, temperature and number
of moles of a gas describes its state and is called equation of state of the gas. Equation
of state for ideal gas is pV=nRT, where R is a gas constant and its value depends upon
units chosen for pressure, volume and temperature.
At high pressure and low temperature intermolecular forces start operating strongly
between the molecules of gases because they come close to each other. Under suitable
temperature and pressure conditions gases can be liquified. Liquids may be considered
as continuation of gas phase into a region of small volume and very strong molecular
attractions. Some properties of liquids e.g., surface tension and viscosity are due to
strong intermolecular attractive forces.
</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->