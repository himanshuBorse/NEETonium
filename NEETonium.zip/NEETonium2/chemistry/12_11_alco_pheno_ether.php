 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Alcohols, Phenols and Ethers</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Alcohols, Phenols and Ethers</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Alcohols, Phenols and Ethers</h3>
            <p class="chapSummary">
            Alcohols and phenols are classified (i) on the basis of the number of hydroxyl
groups and (ii) according to the hybridisation of the carbon atom, sp
3
 or sp
2
 to
which the –OH group is attached. Ethers are classified on the basis of groups
attached to the oxygen atom.
Alcohols may be prepared (1) by hydration of alkenes (i) in presence of an
acid and (ii) by hydroboration-oxidation reaction (2) from carbonyl compounds by
(i) catalytic reduction and (ii) the action of Grignard reagents. Phenols may be
prepared by (1) substitution of (i) halogen atom in haloarenes and (ii) sulphonic
acid group in aryl sulphonic acids, by –OH group (2) by hydrolysis of diazonium
salts and (3) industrially from cumene.
Alcohols are higher boiling than other classes of compounds, namely
hydrocarbons, ethers and haloalkanes of comparable molecular masses. The
ability of alcohols, phenols and ethers to form intermolecular hydrogen bonding
with water makes them soluble in it.
Alcohols and phenols are acidic in nature. Electron withdrawing groups in
phenol increase its acidic strength and electron releasing groups decrease it.
Alcohols undergo nucleophilic substitution with hydrogen halides to yield
alkyl halides. Dehydration of alcohols gives alkenes. On oxidation, primary alcohols
yield aldehydes with mild oxidising agents and carboxylic acids with strong
oxidising agents while secondary alcohols yield ketones. Tertiary alcohols are
resistant to oxidation.
The presence of –OH group in phenols activates the aromatic ring towards
electrophilic substitution and directs the incoming group to ortho and para
positions due to resonance effect. Reimer-Tiemann reaction of phenol yields
salicylaldehyde. In presence of sodium hydroxide, phenol generates phenoxide
ion which is even more reactive than phenol. Thus, in alkaline medium, phenol
undergoes Kolbe’s reaction.
Ethers may be prepared by (i) dehydration of alcohols and (ii) Williamson
synthesis. The boiling points of ethers resemble those of alkanes while their
solubility is comparable to those of alcohols having same molecular mass. The
C–O bond in ethers can be cleaved by hydrogen halides. In electrophilic
substitution, the alkoxy group activates the aromatic ring and directs the incoming
group to ortho and para positions.

            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->