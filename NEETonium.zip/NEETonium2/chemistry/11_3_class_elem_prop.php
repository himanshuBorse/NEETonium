 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Classification of Elements and Periodicity in Properties</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemsitry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Classification of Elements and Periodicity in Properties</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Classification of Elements and Periodicity in Properties</h3>
            <p class="chapSummary">In this Unit, you have studied the development of the Periodic Law and the Periodic
Table. Mendeleev’s Periodic Table was based on atomic masses. Modern Periodic Table
arranges the elements in the order of their atomic numbers in seven horizontal rows
(periods) and eighteen vertical columns (groups or families). Atomic numbers in a period
are consecutive, whereas in a group they increase in a pattern. Elements of the same
group have similar valence shell electronic configuration and, therefore, exhibit similar
chemical properties. However, the elements of the same period have incrementally
increasing number of electrons from left to right, and, therefore, have different valencies.
Four types of elements can be recognized in the periodic table on the basis of their
electronic configurations. These are s-block, p-block, d-block and f-block elements.
Hydrogen with one electron in the 1s orbital occupies a unique position in the periodic
table. Metals comprise more than seventy eight per cent of the known elements. Nonmetals, which are located at the top of the periodic table, are less than twenty in number.
Elements which lie at the border line between metals and non-metals (e.g., Si, Ge, As)
are called metalloids or semi-metals. Metallic character increases with increasing atomic
number in a group whereas decreases from left to right in a period. The physical and
chemical properties of elements vary periodically with their atomic numbers.
Periodic trends are observed in atomic sizes, ionization enthalpies, electron
gain enthalpies, electronegativity and valence. The atomic radii decrease while going
from left to right in a period and increase with atomic number in a group. Ionization
enthalpies generally increase across a period and decrease down a group. Electronegativity
also shows a similar trend. Electron gain enthalpies, in general, become more negative
across a period and less negative down a group. There is some periodicity in valence, for
example, among representative elements, the valence is either equal to the number of
electrons in the outermost orbitals or eight minus this number. Chemical reactivity is
highest at the two extremes of a period and is lowest in the centre. The reactivity on the
left extreme of a period is because of the ease of electron loss (or low ionization enthalpy).
Highly reactive elements do not occur in nature in free state; they usually occur in the
combined form. Oxides formed of the elements on the left are basic and of the elements
on the right are acidic in nature. Oxides of elements in the centre are amphoteric or
neutral.

                
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->