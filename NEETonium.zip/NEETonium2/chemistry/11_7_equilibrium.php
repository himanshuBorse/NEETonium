 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Equilibrium</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Equilibrium</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Equilibrium</h3>
            <p class="chapSummary">When the number of molecules leaving the liquid to vapour equals the number of
molecules returning to the liquid from vapour, equilibrium is said to be attained and is
dynamic in nature. Equilibrium can be established for both physical and chemical
processes and at this stage rate of forward and reverse reactions are equal. Equilibrium
constant, Kc
 is expressed as the concentration of products divided by reactants, each
term raised to the stoichiometric coefficient.
Equilibrium constant has constant value at a fixed temperature and at this stage
all the macroscopic properties such as concentration, pressure, etc. become constant.
For a gaseous reaction equilibrium constant is expressed as Kp
 and is written by replacing
concentration terms by partial pressures in Kc
 expression. The direction of reaction can
be predicted by reaction quotient Qc
 which is equal to Kc
 at equilibrium. Le Chatelier’s
principle states that the change in any factor such as temperature, pressure,
concentration, etc. will cause the equilibrium to shift in such a direction so as to reduce
or counteract the effect of the change. It can be used to study the effect of various
factors such as temperature, concentration, pressure, catalyst and inert gases on the
direction of equilibrium and to control the yield of products by controlling these factors.
Catalyst does not effect the equilibrium composition of a reaction mixture but increases
the rate of chemical reaction by making available a new lower energy pathway for
conversion of reactants to products and vice-versa.
All substances that conduct electricity in aqueous solutions are called electrolytes.
Acids, bases and salts are electrolytes and the conduction of electricity by their aqueous
solutions is due to anions and cations produced by the dissociation or ionization of
electrolytes in aqueous solution. The strong electrolytes are completely dissociated. In
weak electrolytes there is equilibrium between the ions and the unionized electrolyte
molecules. According to Arrhenius, acids give hydrogen ions while bases produce
hydroxyl ions in their aqueous solutions. Brönsted-Lowry on the other hand, defined
an acid as a proton donor and a base as a proton acceptor. When a Brönsted-Lowry
acid reacts with a base, it produces its conjugate base and a conjugate acid corresponding
to the base with which it reacts. Thus a conjugate pair of acid-base differs only by one
proton. Lewis further generalised the definition of an acid as an electron pair acceptor
and a base as an electron pair donor. The expressions for ionization (equilibrium)
constants of weak acids (Ka
) and weak bases (Kb
) are developed using Arrhenius definition.
The degree of ionization and its dependence on concentration and common ion are
discussed. The pH scale (pH = -log[H+
]) for the hydrogen ion concentration (activity) has
been introduced and extended to other quantities (pOH = – log[OH–
]) ; pKa
= –log[Ka
] ;
pKb
 = –log[Kb
]; and pKw
 = –log[Kw
] etc.). The ionization of water has been considered and
we note that the equation: pH + pOH = pKw
 is always satisfied. The salts of strong acid
and weak base, weak acid and strong base, and weak acid and weak base undergo
hydrolysis in aqueous solution.The definition of buffer solutions, and their importance
are discussed briefly. The solubility equilibrium of sparingly soluble salts is discussed
and the equilibrium constant is introduced as solubility product constant (Ksp
). Its
relationship with solubility of the salt is established. The conditions of precipitation of
the salt from their solutions or their dissolution in water are worked out. The role of
common ion and the solubility of sparingly soluble salts is also discussed.
</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->