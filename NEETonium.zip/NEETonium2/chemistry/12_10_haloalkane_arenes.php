 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Haloalkanes and Haloarenes</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Haloalkanes and Haloarenes</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Haloalkanes and Haloarenes</h3>
            <p class="chapSummary">
            Alkyl/ Aryl halides may be classified as mono, di, or polyhalogen (tri-, tetra-, etc.)
compounds depending on whether they contain one, two or more halogen atoms in
their structures. Since halogen atoms are more electronegative than carbon, the carbonhalogen 
bond of alkyl halide is polarised; the carbon atom bears a partial positive
charge, and the halogen atom bears a partial negative charge.
Alkyl halides are prepared by the free radical halogenation of alkanes, addition
of halogen acids to alkenes, replacement of –OH group of alcohols with halogens using
phosphorus halides, thionyl chloride or halogen acids. Aryl halides are prepared by
electrophilic substitution to arenes. Fluorides and iodides are best prepared by halogen
exchange method.
The boiling points of organohalogen compounds are comparatively higher than the
corresponding hydrocarbons because of strong dipole-dipole and van der Waals forces
of attraction. These are slightly soluble in water but completely soluble in organic
solvents.
The polarity of carbon-halogen bond of alkyl halides is responsible for their
nucleophilic substitution, elimination and their reaction with metal atoms to form
organometallic compounds. Nucleophilic substitution reactions are categorised into
SN1 and SN2 on the basis of their kinetic properties. Chirality has a profound role in
understanding the reaction mechanisms of SN
1 and SN
2 reactions. SN
2 reactions of
chiral alkyl halides are characterised by the inversion of configuration while SN
1 reactions
are characterised by racemisation.
A number of polyhalogen compounds e.g., dichloromethane, chloroform, iodoform,
carbon tetrachloride, freon and DDT have many industrial applications. However,
some of these compounds cannot be easily decomposed and even cause depletion of
ozone layer and are proving environmental hazards.

            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->