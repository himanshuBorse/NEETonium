 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Electrochemistry</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Electrochemistry</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Electrochemistry</h3>
            <p class="chapSummary">
            An electrochemical cell consists of two metallic electrodes dipping in electrolytic
solution(s). Thus an important component of the electrochemical cell is the ionic
conductor or electrolyte. Electrochemical cells are of two types. In galvanic cell,
the chemical energy of a spontaneous redox reaction is converted into electrical
work, whereas in an electrolytic cell, electrical energy is used to carry out a nonspontaneous redox reaction. The standard electrode potential for any electrode
dipping in an appropriate solution is defined with respect to standard electrode
potential of hydrogen electrode taken as zero. Concentration dependence
of the potentials of the electrodes and the cells are given by Nernst equation.
The conductivity, κ, of an electrolytic solution depends on the concentration
of the electrolyte, nature of solvent and temperature. Molar conductivity, Λm, is
defined by = κ/c where c is the concentration. Conductivity decreases but molar
conductivity increases with decrease in concentration. It increases slowly with
decrease in concentration for strong electrolytes while the increase is very steep
for weak electrolytes in very dilute solutions. Kohlrausch found that molar
conductivity at infinite dilution, for an electrolyte is sum of the contribution of the
molar conductivity of the ions in which it dissociates. It is known as law of
independent migration of ions and has many applications. Ions conduct electricity
through the solution but oxidation and reduction of the ions take place at the
electrodes in an electrochemical cell. Batteries and fuel cells are very useful
forms of galvanic cell. Corrosion of metals is essentially an electrochemical
phenomenon. Electrochemical principles are relevant to the Hydrogen Economy
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->