 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Hydrogen</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Hydrogen</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Hydrogen</h3>
            <p class="chapSummary">
            The H–H bond dissociation enthalpy of dihydrogen (435.88 kJ mol–1) is the highest
for a single bond between two atoms of any elements. This property is made use of in the
atomic hydrogen torch which generates a temperature of ~4000K and is ideal for welding
of high melting metals.
Though dihydrogen is rather inactive at room temperature because of very high
negative dissociation enthalpy, it combines with almost all the elements under appropriate
conditions to form hydrides. All the type of hydrides can be classified into three categories:
ionic or saline hydrides, covalent or molecular hydrides and metallic or non-stoichiometric
hydrides. Alkali metal hydrides are good reagents for preparing other hydride compounds.
Molecular hydrides (e.g., B2H6, CH4, NH3, H2O) are of great importance in day-to-day life.
Metallic hydrides are useful for ultrapurification of dihydrogen and as dihydrogen storage
media.
Among the other chemical reactions of dihydrogen, reducing reactions leading to
the formation hydrogen halides, water, ammonia, methanol, vanaspati ghee, etc. are of
great importance. In metallurgical process, it is used to reduce metal oxides. In space
programmes, it is used as a rocket fuel. In fact, it has promising potential for use as a
non-polluting fuel of the near future (Hydrogen Economy).
Water is the most common and abundantly available substance. It is of a great
chemical and biological significance. The ease with which water is transformed from
liquid to solid and to gaseous state allows it to play a vital role in the biosphere. The
water molecule is highly polar in nature due to its bent structure. This property leads to
hydrogen bonding which is the maximum in ice and least in water vapour. The polar
nature of water makes it: (a) a very good solvent for ionic and partially ionic compounds;
(b) to act as an amphoteric (acid as well as base) substance; and (c) to form hydrates of
different types. Its property to dissolve many salts, particularly in large quantity, makes
it hard and hazardous for industrial use. Both temporary and permanent hardness can
be removed by the use of zeolites, and synthetic ion-exchangers.
Heavy water, D2O is another important compound which is manufactured by the
electrolytic enrichment of normal water. It is essentially used as a moderator in nuclear
reactors.
Hydrogen peroxide, H2O2 has an interesting non-polar structure and is widely used
as an industrial bleach and in pharmaceutical and pollution control treatment of
industrial and domestic effluents.+
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->