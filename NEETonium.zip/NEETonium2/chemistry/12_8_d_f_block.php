 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">The d- and f- block Elements</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">The d- and f- block Elements</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">The d- and f- block Elements</h3>
            <p class="chapSummary">
            The d-block consisting of Groups 3-12 occupies the large middle section of the periodic
table. In these elements the inner d orbitals are progressively filled. The f-block is placed
outside at the bottom of the periodic table and in the elements of this block, 4f and
5f orbitals are progressively filled.
Corresponding to the filling of 3d, 4d and 5d orbitals, three series of transition
elements are well recognised. All the transition elements exhibit typical metallic properties
such as –high tensile strength, ductility, malleability, thermal and electrical conductivity
and metallic character. Their melting and boiling points are high which are attributed
to the involvement of (n –1) d electrons resulting into strong interatomic bonding. In
many of these properties, the maxima occur at about the middle of each series which
indicates that one unpaired electron per d orbital is particularly a favourable configuration
for strong interatomic interaction.
Successive ionisation enthalpies do not increase as steeply as in the main group
elements with increasing atomic number. Hence, the loss of variable number of electrons
from (n –1) d orbitals is not energetically unfavourable. The involvement of (n–1) d electrons
in the behaviour of transition elements impart certain distinct characteristics to these
elements. Thus, in addition to variable oxidation states, they exhibit paramagnetic
behaviour, catalytic properties and tendency for the formation of coloured ions, interstitial
compounds and complexes.
The transition elements vary widely in their chemical behaviour. Many of them are
sufficiently electropositive to dissolve in mineral acids, although a few are ‘noble’. Of the
first series, with the exception of copper, all the metals are relatively reactive.
The transition metals react with a number of non-metals like oxygen, nitrogen,
sulphur and halogens to form binary compounds. The first series transition metal oxides
are generally formed from the reaction of metals with oxygen at high temperatures. These
oxides dissolve in acids and bases to form oxometallic salts. Potassium dichromate and
potassium permanganate are common examples. Potassium dichromate is prepared from
the chromite ore by fusion with alkali in presence of air and acidifying the extract.
Pyrolusite ore (MnO2) is used for the preparation of potassium permanganate. Both the
dichromate and the permanganate ions are strong oxidising agents.
The two series of inner transition elements, lanthanoids and actinoids constitute
the f-block of the periodic table. With the successive filling of the inner orbitals, 4f, there
is a gradual decrease in the atomic and ionic sizes of these metals along the series
(lanthanoid contraction). This has far reaching consequences in the chemistry of the
elements succeeding them. Lanthanum and all the lanthanoids are rather soft white
metals. They react easily with water to give solutions giving +3 ions. The principal
oxidation state is +3, although +4 and +2 oxidation states are also exhibited by some
occasionally. The chemistry of the actinoids is more complex in view of their ability to
exist in different oxidation states. Furthermore, many of the actinoid elements are radioactive
which make the study of these elements rather difficult.
There are many useful applications of the d- and f-block elements and their
compounds, notable among them being in varieties of steels, catalysts, complexes,
organic syntheses, etc.
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->