 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">General Principles and Processes of Isolation of Elements</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">General Principles and Processes of Isolation of Elements</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">General Principles and Processes of Isolation of Elements</h3>
            <p class="chapSummary">
            Although modern metallurgy had exponential growth after Industrial Revolution,
many modern concepts in metallurgy have their roots in ancient practices that
predated the Industrial Revolution. For over 7000 years, India has had high tradition
of metallurigical skills. Ancient Indian metallurgists have made major contributions
which deserve their place in metallurgical history of the world. In the case of zinc
and high–carbon steel, ancient India contributed significantly for the developemnt
of base for the modern metallurgical advancements which induced metallurgical
study leading to Industrial Revolution.
Metals are required for a variety of purposes. For this, we need their extraction from
the minerals in which they are present and from which their extraction is
commercially feasible.These minerals are known as ores. Ores of the metal are
associated with many impurities. Removal of these impurities to certain extent is
achieved in concentration steps. The concentrated ore is then treated chemically
for obtaining the metal. Usually the metal compounds (e.g., oxides, sulphides) are
reduced to the metal. The reducing agents used are carbon, CO or even some metals.
In these reduction processes, the thermodynamic and electrochemical concepts
are given due consideration. The metal oxide reacts with a reducing agent; the
oxide is reduced to the metal and the reducing agent is oxidised. In the two reactions,
the net Gibbs energy change is negative, which becomes more negative on raising
the temperature. Conversion of the physical states from solid to liquid or to gas,
and formation of gaseous states favours decrease in the Gibbs energy for the entire
system. This concept is graphically displayed in plots of ∆G0 vs T (Ellingham diagram)
for such oxidation/reduction reactions at different temperatures. The concept of
electrode potential is useful in the isolation of metals (e.g., Al, Ag, Au) where the
sum of the two redox couples is positive so that the Gibbs energy change is negative.
The metals obtained by usual methods still contain minor impurities. Getting pure
metals requires refining. Refining process depends upon the differences in
properties of the metal and the impurities. Extraction of aluminium is usually carried
out from its bauxite ore by leaching it with NaOH. Sodium aluminate, thus formed,
is separated and then neutralised to give back the hydrated oxide, which is then
electrolysed using cryolite as a flux. Extraction of iron is done by reduction of its
oxide ore in blast furnace. Copper is extracted by smelting and heating in a
reverberatory furnace. Extraction of zinc from zinc oxides is done using coke. Several
methods are employed in refining the metal. Metals, in general, are very widely
used and have contributed significantly in the development of a variety of industries.

            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->