 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">The s-block Elements</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">The s-block Elements</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">The s-block Elements</h3>
            <p class="chapSummary">
            The s-Block of the periodic table constitutes Group1 (alkali metals) and Group 2
(alkaline earth metals). They are so called because their oxides and hydroxides are alkaline
in nature. The alkali metals are characterised by one s-electron and the alkaline earth
metals by two s-electrons in the valence shell of their atoms. These are highly reactive
metals forming monopositive (M+
) and dipositve (M2+) ions respectively.
There is a regular trend in the physical and chemical properties of the alkali metal
with increasing atomic numbers. The atomic and ionic sizes increase and the ionization
enthalpies decrease systematically down the group. Somewhat similar trends are
observed among the properties of the alkaline earth metals.
 The first element in each of these groups, lithium in Group 1 and beryllium in
Group 2 shows similarities in properties to the second member of the next group. Such
similarities are termed as the ‘diagonal relationship’ in the periodic table. As such
these elements are anomalous as far as their group characteristics are concerned.
 The alkali metals are silvery white, soft and low melting. They are highly reactive.
The compounds of alkali metals are predominantly ionic. Their oxides and hydroxides
are soluble in water forming strong alkalies. Important compounds of sodium includes
sodium carbonate, sodium chloride, sodium hydroxide and sodium hydrogencarbonate.
Sodium hydroxide is manufactured by Castner-Kellner process and sodium carbonate
by Solvay process.
 The chemistry of alkaline earth metals is very much like that of the alkali metals.
However, some differences arise because of reduced atomic and ionic sizes and increased
cationic charges in case of alkaline earth metals. Their oxides and hydroxides are less
basic than the alkali metal oxides and hydroxides. Industrially important compounds of
calcium include calcium oxide (lime), calcium hydroxide (slaked lime), calcium sulphate
(Plaster of Paris), calcium carbonate (limestone) and cement. Portland cement is an
important constructional material. It is manufactured by heating a pulverised mixture
of limestone and clay in a rotary kiln. The clinker thus obtained is mixed with some
gypsum (2-3%) to give a fine powder of cement. All these substances find variety of uses
in different areas.
 Monovalent sodium and potassium ions and divalent magnesium and calcium ions
are found in large proportions in biological fluids. These ions perform important
biological functions such as maintenance of ion balance and nerve impulse conduction.

            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->