 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script> 
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Amines</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemistry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Amines</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Amines</h3>
            <p class="chapSummary">
            Amines can be considered as derivatives of ammonia obtained by replacement of
hydrogen atoms with alkyl or aryl groups. Replacement of one hydrogen atom of
ammonia gives rise to structure of the type R-NH2
, known as primary amine.
Secondary amines are characterised by the structure R2NH or R-NHR′ and tertiary
amines by R3N, RNR′R′′ or R2NR′. Secondary and tertiary amines are known as
simple amines if the alkyl or aryl groups are the same and mixed amines if the
groups are different. Like ammonia, all the three types of amines have one unshared
electron pair on nitrogen atom due to which they behave as Lewis bases.
Amines are usually formed from nitro compounds, halides, amides, imides, etc.
They exhibit hydrogen bonding which influence their physical properties. In
alkylamines, a combination of electron releasing, steric and H-bonding factors
influence the stability of the substituted ammonium cations in protic polar solvents
and thus affect the basic nature of amines. Alkyl amines are found to be stronger
bases than ammonia. In aromatic amines, electron releasing and withdrawing groups,
respectively increase and decrease their basic character. Aniline is a weaker base
than ammonia. Reactions of amines are governed by availability of the unshared pair
of electrons on nitrogen. Influence of the number of hydrogen atoms at nitrogen atom
on the type of reactions and nature of products is responsible for identification and
distinction between primary, secondary and tertiary amines. p-Toluenesulphonyl chloride
is used for the identification of primary, secondary and tertiary amines. Presence of
amino group in aromatic ring enhances reactivity of the aromatic amines. Reactivity of
aromatic amines can be controlled by acylation process, i.e., by treating with acetyl
chloride or acetic anhydride. Tertiary amines like trimethylamine are used as insect
attractants.
Aryldiazonium salts, usually obtained from arylamines, undergo replacement of
the diazonium group with a variety of nucleophiles to provide advantageous methods
for producing aryl halides, cyanides, phenols and arenes by reductive removal of the
diazo group. Coupling reaction of aryldiazonium salts with phenols or arylamines give
rise to the formation of azo dyes.
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->