 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Structure of Atom</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/chemistry.php">Chemsitry</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Structure of Atom</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Structure of Atom</h3>
            <p class="chapSummary">Atoms are the building blocks of elements. They are the smallest parts of an element
that chemically react. The first atomic theory, proposed by John Dalton in 1808, regarded
atom as the ultimate indivisible particle of matter. Towards the end of the nineteenth
century, it was proved experimentally that atoms are divisible and consist of three
fundamental particles: electrons, protons and neutrons. The discovery of sub-atomic
particles led to the proposal of various atomic models to explain the structure of atom.
Thomson in 1898 proposed that an atom consists of uniform sphere of positive electricity
with electrons embedded into it. This model in which mass of the atom is considered to be
evenly spread over the atom was proved wrong by Rutherford’s famous alpha-particle
scattering experiment in 1909. Rutherford concluded that atom is made of a tiny positively
charged nucleus, at its centre with electrons revolving around it in circular orbits.
Rutherford model, which resembles the solar system, was no doubt an improvement over
Thomson model but it could not account for the stability of the atom i.e., why the electron
does not fall into the nucleus. Further, it was also silent about the electronic structure of
atoms i.e., about the distribution and relative energies of electrons around the nucleus.
The difficulties of the Rutherford model were overcome by Niels Bohr in 1913 in his model
of the hydrogen atom. Bohr postulated that electron moves around the nucleus in circular
orbits. Only certain orbits can exist and each orbit corresponds to a specific energy. Bohr
calculated the energy of electron in various orbits and for each orbit predicted the distance
between the electron and nucleus. Bohr model, though offering a satisfactory model for
explaining the spectra of the hydrogen atom, could not explain the spectra of multi-electron
atoms. The reason for this was soon discovered. In Bohr model, an electron is regarded as
a charged particle moving in a well defined circular orbit about the nucleus. The wave
character of the electron is ignored in Bohr’s theory. An orbit is a clearly defined path and
this path can completely be defined only if both the exact position and the exact velocity of
the electron at the same time are known. This is not possible according to the Heisenberg
uncertainty principle. Bohr model of the hydrogen atom, therefore, not only ignores the
dual behaviour of electron but also contradicts Heisenberg uncertainty principle.
Erwin Schrödinger, in 1926, proposed an equation called Schrödinger equation to describe
the electron distributions in space and the allowed energy levels in atoms. This equation
incorporates de Broglie’s concept of wave-particle duality and is consistent with Heisenberg
uncertainty principle. When Schrödinger equation is solved for the electron in a hydrogen
atom, the solution gives the possible energy states the electron can occupy [and the
corresponding wave function(s) (ψ) (which in fact are the mathematical functions) of the
electron associated with each energy state]. These quantized energy states and corresponding
wave functions which are characterized by a set of three quantum numbers (principal
quantum number n, azimuthal quantum number l and magnetic quantum number ml)
arise as a natural consequence in the solution of the Schrödinger equation. The restrictions
on the values of these three quantum numbers also come naturally from this solution. The
quantum mechanical model of the hydrogen atom successfully predicts all aspects of the
hydrogen atom spectrum including some phenomena that could not be explained by the
Bohr model.
According to the quantum mechanical model of the atom, the electron distribution of an
atom containing a number of electrons is divided into shells. The shells, in turn, are thought
to consist of one or more subshells and subshells are assumed to be composed of one or
more orbitals, which the electrons occupy. While for hydrogen and hydrogen like systems
(such as He+
, Li2+ etc.) all the orbitals within a given shell have same energy, the energy of
the orbitals in a multi-electron atom depends upon the values of n and l: The lower the
value of (n + l ) for an orbital, the lower is its energy. If two orbitals have the same (n + l )
value, the orbital with lower value of n has the lower energy. In an atom many such orbitals
are possible and electrons are filled in those orbitals in order of increasing energy in
accordance with Pauli exclusion principle (no two electrons in an atom can have the
same set of four quantum numbers) and Hund’s rule of maximum multiplicity (pairing
of electrons in the orbitals belonging to the same subshell does not take place until
each orbital belonging to that subshell has got one electron each, i.e., is singly occupied).
This forms the basis of the electronic structure of atoms.</p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/chemistrySidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->