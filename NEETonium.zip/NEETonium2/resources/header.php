<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta property="name" content="NEETonium: Free NEET preparation platform">
    <meta  property="description" content="Start your prepartion today itself with NEETonium. Initially start with the MCQ's.">


  <!-- <meta name="copyright" content="MACode ID, https://www.macodeid.com/"> -->

  <title>NEETonium - NEET exam MCQs preparation</title>

  <link rel="shortcut icon" href="../assets/shortcutIcon.png" type="image/x-icon">

  <link rel="stylesheet" href="../assets/css/maicons.css">

  <link rel="stylesheet" href="../assets/vendor/animate/animate.css">

  <link rel="stylesheet" href="../assets/vendor/owl-carousel/css/owl.carousel.min.css">

  <link rel="stylesheet" href="../assets/css/bootstrap.css">

  <link rel="stylesheet" href="../assets/css/neetonium.css">

</head>
<body>
 

<nav class="navbar navbar-expand-lg navbar-dark navbar-floating">
  <div class="container">
    
      <!-- <img src="../assets/favicon-light.png" alt="" width="40"> -->
      <!-- <div class="logo-holder logo"> -->
        <a class="navbar-brand" href="../index.php">
        <h2>NEETonium</h2>
        <!-- <p>The best is yet to come</p> -->    
        </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggler" aria-controls="navbarToggler" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  
    <div class="collapse navbar-collapse" id="navbarToggler">
      <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
      <li class="nav-item active">
          <a class="nav-link" href="../index.php">Home</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Subjects</a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="../subjects/physics.php">Physics</a>
            <a class="dropdown-item" href="../subjects/chemistry.php">Chemistry</a>
            <a class="dropdown-item" href="../subjects/biology.php">Biology</a>
          </div>
        </li>
        <li class="nav-item ">
          <a class="nav-link" href="../aboutUs/aboutUs.php">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../aboutUs/whatsNew.php">What's New</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../aboutUs/contact.php">Contact</a>
        </li>
      </ul>
      <!-- <div class="ml-auto my-2 my-lg-0">
        <button class="btn btn-primary rounded-pill">Download Now</button>
      </div> -->
    </div>
  </div>
</nav>

<main class="bg-light">
