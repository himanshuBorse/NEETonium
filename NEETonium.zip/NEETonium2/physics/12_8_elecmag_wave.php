 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Electromagnetic Waves</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Electromagnetic Waves</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Electromagnetic Waves</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Maxwell found an inconsistency in the Ampere’s law and suggested the
existence of an additional current, called displacement current, to remove
this inconsistency. This displacement current is due to time-varying electric
field and acts as a source of magnetic field in exactly the same way as conduction
current.
                    </li>
                    <li>
                    An accelerating charge produces electromagnetic waves. An electric charge
oscillating harmonically with frequency ν, produces electromagnetic waves
of the same frequency ν. An electric dipole is a basic source of
electromagnetic waves
                    </li>
                    <li>
                    Electromagnetic waves with wavelength of the order of a few metres were
first produced and detected in the laboratory by Hertz in 1887. He thus
verified a basic prediction of Maxwell’s equations.
                    </li>
                    <li>
                    Electromagnetic waves carry energy as they travel through space and this
energy is shared equally by the electric and magnetic fields.
Electromagnetic waves transport momentum as well. When these waves
strike a surface, a pressure is exerted on the surface. If total energy
transferred to a surface in time t is U, total momentum delivered to this
surface is p = U/c.
                    </li>
                    <li>
                    The basic difference between various types of electromagnetic waves
lies in their wavelengths or frequencies since all of them travel through
vacuum with the same speed. Consequently, the waves differ
considerably in their mode of interaction with matter
                    </li>
                    <li>
                    The oscillating fields of an electromagnetic wave can accelerate charges
and can produce oscillating currents. Therefore, an apparatus designed
to detect electromagnetic waves is based on this fact. Hertz original
‘receiver’ worked in exactly this way. The same basic principle is utilised
in practically all modern receiving devices. High frequency
electromagnetic waves are detected by other means based on the
physical effects they produce on interacting with matter.
                    </li>
                    <li>
                    Infrared waves, with frequencies lower than those of visible light,
vibrate not only the electrons, but entire atoms or molecules of a
substance. This vibration increases the internal energy and
consequently, the temperature of the substance. This is why infrared
waves are often called heat waves.
                    </li>
                    <li>
                    The centre of sensitivity of our eyes coincides with the centre of the
wavelength distribution of the sun. It is because humans have evolved
with visions most sensitive to the strongest wavelengths from
the sun.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->