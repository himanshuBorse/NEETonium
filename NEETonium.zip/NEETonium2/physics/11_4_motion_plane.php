 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Motion in a Plane</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Motion in a Plane</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Motion in a Plane</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Scalar quantities are quantities with magnitudes only. Examples are distance, speed,
mass and temperature.
                    </li>
                    <li>
                    Vector quantities are quantities with magnitude and direction both. Examples are
displacement, velocity and acceleration. They obey special rules of vector algebra. 
                    </li>
                    <li>
                    A vector A multiplied by a real number λ is also a vector, whose magnitude is λ times
the magnitude of the vector A and whose direction is the same or opposite depending
upon whether λ is positive or negative.
                    </li>
                    <li>
                    Two vectors A and B may be added graphically using head-to-tail method or parallelogram
method
                    </li>
                    <li>
                    The path length traversed by an object between two points is, in general, not the same as
the magnitude of displacement. The displacement depends only on the end points; the
path length (as the name implies) depends on the actual path. The two quantities are
equal only if the object does not change its direction during the course of motion. In all
other cases, the path length is greater than the magnitude of displacement.
                    </li>
                    <li>
                    The average speed of an object is greater than or equal to the
magnitude of the average velocity over a given time interval. The two are equal only if the
path length is equal to the magnitude of displacement.
                    </li>
                    <li>
                    The kinematic equations for uniform acceleration do not apply to the case of uniform
circular motion since in this case the magnitude of acceleration is constant but its
direction is changing.
                    </li>
                    <li>
                    The resultant acceleration of an object in circular motion is towards the centre only if
the speed is constant.
                    </li>
                    <li>
                    The shape of the trajectory of the motion of an object is not determined by the acceleration
alone but also depends on the initial conditions of motion ( initial position and initial
velocity). For example, the trajectory of an object moving under the same acceleration
due to gravity can be a straight line or a parabola depending on the initial conditions
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">1</span>
                            <span class="question">Delhi is at a distance 200kn from Ambala. Car A sets out from Ambala at a speed of 30kn/hr. 
                                and a car B set out at the same time from Delhi at a speed of 20km/hr. What will be the distance of the crossing point from Ambala(in km)
                            </span>
                            <div class="option"><span class="optionNum">A</span>70</div>
                            <div class="option"><span class="optionNum">B</span>120</div>
                            <div class="option"><span class="optionNum">C</span>100</div>
                            <div class="option"><span class="optionNum">D</span>80</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">120</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">2</span>
                            <span class="question">Two bodies A and B are 10km apart such that B is to the south of A. A and B start moving with the 
                                same speed 20km/hr eastward and northward respectively then time elapsed from strating, to attain minimum seperation
                            </span>
                            <div class="option"><span class="optionNum">A</span>15min</div>
                            <div class="option"><span class="optionNum">B</span>20min</div>
                            <div class="option"><span class="optionNum">C</span>18min</div>
                            <div class="option"><span class="optionNum">D</span>60min</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol2')">
                            <div id="textsol2" class="textSolution" style="display:none">15min</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">3</span>
                            <span class="question">A man standing in the rain holds a umbrella at an angle of 30&deg; from vertical. He throws teh umbrella and starts running
                                 with 10km/hr. He finds that the rain drops are hitting his head vertically. What is the actual speed of rain drops.
                            </span>
                            <div class="option"><span class="optionNum">A</span>15km/hr</div>
                            <div class="option"><span class="optionNum">B</span>20km/hr</div>
                            <div class="option"><span class="optionNum">C</span>10km/hr</div>
                            <div class="option"><span class="optionNum">D</span>12km/hr</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol3')">
                            <div id="textsol3" class="textSolution" style="display:none">20km/hr</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">4</span>
                            <span class="question">A man can swim at a speed of 2m/s in still water. He starts swimming in a river at an angle 150&deg; to the direction
                                 of water flow and reaches the directly opposite point on the opposite bank. If width of river is 1km the calculate the time taken to 
                                 cross the river
                            </span>
                            <div class="option"><span class="optionNum">A</span>100s</div>
                            <div class="option"><span class="optionNum">B</span>1000s</div>
                            <div class="option"><span class="optionNum">C</span>500s</div>
                            <div class="option"><span class="optionNum">D</span>756s</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol4')">
                            <div id="textsol4" class="textSolution" style="display:none">1000s</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">5</span>
                            <span class="question">2 km wide river flowing at the rate of 5km/hr. A man can swim in still water with 10km/hr. He wants to cross the river along
                                the shortest path. find in which direction should the person swim
                            </span>
                            <div class="option"><span class="optionNum">A</span>Direction from up stream = 120&deg;</div>
                            <div class="option"><span class="optionNum">B</span>Direction from up stream = 160&deg;</div>
                            <div class="option"><span class="optionNum">C</span>Direction from down stream = 150&deg;</div>
                            <div class="option"><span class="optionNum">D</span>Direction from down stream = 120&deg;</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol5')">
                            <div id="textsol5" class="textSolution" style="display:none">Direction from down stream = 120&deg;</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">6</span>
                            <span class="question">Two traubs A and B each if length 50m, are moving with constant speeds. If one train A overtakes the other in 40s, 
                                while crosses the other in 20s. Find teh speeds of each train
                            </span>
                            <div class="option"><span class="optionNum">A</span>3.00m/s and 1.25m/s</div>
                            <div class="option"><span class="optionNum">B</span>0.75m/s and 1.25m/s</div>
                            <div class="option"><span class="optionNum">C</span>13.75m/s and 1.25m/s</div>
                            <div class="option"><span class="optionNum">D</span>3.75m/s and 1.25m/s</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol6')">
                            <div id="textsol6" class="textSolution" style="display:none">3.75m/s and 1.25m/s</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">7</span>
                            <span class="question">Water drops fall at regular intervals from a tap 5m above the ground. The third drop is leaving the tap at the instant the first drop 
                                touches the ground. How far above the ground is teh second drop at that instant?
                            </span>
                            <div class="option"><span class="optionNum">A</span>1.25m</div>
                            <div class="option"><span class="optionNum">B</span>3.75m</div>
                            <div class="option"><span class="optionNum">C</span>2.50m</div>
                            <div class="option"><span class="optionNum">D</span>4.00m</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol7')">
                            <div id="textsol7" class="textSolution" style="display:none">3.75m</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">8</span>
                            <span class="question">A ball is thrown upward with a velocity of 100m/s. It will reach the ground after</span>
                            <div class="option"><span class="optionNum">A</span>10s</div>
                            <div class="option"><span class="optionNum">B</span>20s</div>
                            <div class="option"><span class="optionNum">C</span>5s</div>
                            <div class="option"><span class="optionNum">D</span>40s</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol8')">
                            <div id="textsol8" class="textSolution" style="display:none">20s</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">9</span>
                            <span class="question">The range of a projectile when fired at 75&deg; to the horizontal is 0.5km. What will be its range when 
                                fired at 45&deg; with the same speed
                            </span>
                            <div class="option"><span class="optionNum">A</span>0.5km</div>
                            <div class="option"><span class="optionNum">B</span>1.0km</div>
                            <div class="option"><span class="optionNum">C</span>1.5km</div>
                            <div class="option"><span class="optionNum">D</span>2.0km</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol9')">
                            <div id="textsol9" class="textSolution" style="display:none">1.0km</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">10</span>
                            <span class="question">A man is walking on a road with a velocity of 3km/h when suddenly, it starts raining velocity of raind is 
                                10km/h in vertically downward direction, relative velocity of the rain with respect to man is
                            </span>
                            <div class="option"><span class="optionNum">A</span>&radic;13 km/hr</div>
                            <div class="option"><span class="optionNum">B</span>&radic;7 km/hr</div>
                            <div class="option"><span class="optionNum">C</span>&radic;109 km/hr</div>
                            <div class="option"><span class="optionNum">D</span>13 km/hr</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol10')">
                            <div id="textsol10" class="textSolution" style="display:none">&radic;109 km/hr</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">11</span>
                            <span class="question">A river is flowing at the rate of 6km/h. A swimmer swims across the river with a velocity of 9km/h w.r.t. water.
                                 The resultant velocity of the man will be in (km/h)
                            </span>
                            <div class="option"><span class="optionNum">A</span>&radic;117</div>
                            <div class="option"><span class="optionNum">B</span>&radic;340</div>
                            <div class="option"><span class="optionNum">C</span>&radic;17</div>
                            <div class="option"><span class="optionNum">D</span>3&radic;40</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol11')">
                            <div id="textsol11" class="textSolution" style="display:none">&radic;117</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">12</span>
                            <span class="question">A 210 meters long train is moving due north with a speed of 25m/s. A small bird is flying due south 
                                a little above the train with 5m/s speed. The time taken by the bird to cross train is
                            </span>
                            <div class="option"><span class="optionNum">A</span>6s</div>
                            <div class="option"><span class="optionNum">B</span>7s</div>
                            <div class="option"><span class="optionNum">C</span>9s</div>
                            <div class="option"><span class="optionNum">D</span>10s</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol12')">
                            <div id="textsol12" class="textSolution" style="display:none">7s</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">13</span>
                            <span class="question">A stone is thrown upwards and it rises to a height of 200m. The relative velocity of the stone 
                                with respect to the earth will be maximum at
                            </span>
                            <div class="option"><span class="optionNum">A</span>Height of 100m</div>
                            <div class="option"><span class="optionNum">B</span>Height of 150m</div>
                            <div class="option"><span class="optionNum">C</span>Highest point</div>
                            <div class="option"><span class="optionNum">D</span>The ground</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol13')">
                            <div id="textsol13" class="textSolution" style="display:none">The ground</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">14</span>
                            <span class="question">A man walks on a straight road from his home to a market 2.5km away with a speed of 5km/h. 
                                Finding the market closed, he instantly turns and walks back home with speed of 7.5km/h. The average speed of the man over the interval of time
                                0 to 40 min is equal to
                            </span>
                            <div class="option"><span class="optionNum">A</span>5 km/h</div>
                            <div class="option"><span class="optionNum">B</span>25/4 km/h</div>
                            <div class="option"><span class="optionNum">C</span>30/4 km/h</div>
                            <div class="option"><span class="optionNum">D</span>45/8 km/h</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol14')">
                            <div id="textsol14" class="textSolution" style="display:none">45/8 km/h</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">15</span>
                            <span class="question">The ceiling of a hall is 40m high. For maximum horizontal distance, the angle at which the ball can be 
                                thrown with a speed of 56m/s without hitting the ceiling of the hall is
                            </span>
                            <div class="option"><span class="optionNum">A</span>25&deg;</div>
                            <div class="option"><span class="optionNum">B</span>30&deg;</div>
                            <div class="option"><span class="optionNum">C</span>45&deg;</div>
                            <div class="option"><span class="optionNum">D</span>60&deg;</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol15')">
                            <div id="textsol15" class="textSolution" style="display:none">30&deg;</div>
                        </form>
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->