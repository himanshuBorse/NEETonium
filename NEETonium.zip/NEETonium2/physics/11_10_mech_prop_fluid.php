 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Mechanical Properties of Fluids</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Mechanical Properties of Fluids</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Mechanical Properties of Fluids</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    The basic property of a fluid is that it can flow. The fluid does not have any
resistance to change of its shape. Thus, the shape of a fluid is governed by the
shape of its container
                    </li>
                    <li>
                    A liquid is incompressible and has a free surface of its own. A gas is compressible
and it expands to occupy all the space available to it.
                    </li>
                    <li>
                    Pascal’s law states that: Pressure in a fluid at rest is same at all points which are at
the same height. A change in pressure applied to an enclosed fluid is transmitted
undiminished to every point of the fluid and the walls of the containing vessel.
                    </li>
                    <li>
                    The volume of an incompressible fluid passing any point every second in a pipe of
non uniform crossection is the same in the steady flow.
v A = constant ( v is the velocity and A is the area of crossection)
The equation is due to mass conservation in incompressible fluid flow.
                    </li>
                    <li>
                    Though shear strain in a fluid does not require shear stress, when a shear stress is
applied to a fluid, the motion is generated which causes a shear strain growing
with time. The ratio of the shear stress to the time rate of shearing strain is known
as coefficient of viscosity, η.
where symbols have their usual meaning and are defined in the text.
                    </li>
                    <li>
                    Stokes’ law states that the viscous drag force F on a sphere of radius a moving with
velocity v through a fluid of viscosity is, F = 6πηav.
                    </li>
                    <li>
                    Surface tension is a force per unit length (or surface energy per unit area) acting in
the plane of interface between the liquid and the bounding surface. It is the extra
energy that the molecules at the interface have as compared to the interior.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->