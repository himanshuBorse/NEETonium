<!-- <title>NEETonium- Physical World</title> -->
<!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Physical World</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Physical World</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Physical World</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Physics deals with the study of the basic laws of nature and their manifestation in
different phenomena. The basic laws of physics are universal and apply in widely different
contexts and conditions.
                    </li>
                    <li>
                    The scope of physics is wide, covering a tremendous range of magnitude of physical
quantities.
                    </li>
                    <li>
                    Physics and technology are related to each other. Sometimes technology gives rise to
new physics; at other times physics generates new technology. Both have direct impact
on society.
                    </li>
                    <li>
                    There are four fundamental forces in nature that govern the diverse phenomena of the
macroscopic and the microscopic world. These are the ‘gravitational force’, the
‘electromagnetic force’, the ‘strong nuclear force’, and the ‘weak nuclear force’. Unification
of different forces/domains in nature is a basic quest in physics.
                    </li>
                    <li>
                    The physical quantities that remain unchanged in a process are called conserved
quantities. Some of the general conservation laws in nature include the laws of
conservation of mass, energy, linear momentum, angular momentum, charge, parity,
etc. Some conservation laws are true for one fundamental force but not for the other.
                    </li>
                    <li>
                    Conservation laws have a deep connection with symmetries of nature. Symmetries of
space and time, and other types of symmetries play a central role in modern theories of
fundamental forces in nature.
                    </li>
                </ul>    
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">1</span>
                            <span class="question">A physical quantity which has a direction</span>
                            <div class="option"><span class="optionNum">A</span>must be a vector</div>
                            <div class="option"><span class="optionNum">B</span>may be a vector</div>
                            <div class="option"><span class="optionNum">C</span>must be a scalar</div>
                            <div class="option"><span class="optionNum">D</span>none of the above</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">may be a vector</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">2</span>
                            <span class="question">Which of the following statements is false</span>
                            <div class="option"><span class="optionNum">A</span>Mass, Speed and Energy are scalars</div>
                            <div class="option"><span class="optionNum">B</span>Momentum, force and torque are vectors</div>
                            <div class="option"><span class="optionNum">C</span>Distance is a scalar while displacement is a vector</div>
                            <div class="option"><span class="optionNum">D</span>A vector has only magnitude whereas a scalar has both magnitude and direction</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol2')">
                            <div id="textsol2" class="textSolution" style="display:none">A vector has only magnitude whereas a scalar has both magnitude and direction</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">3</span>
                            <span class="question">The forces, which meet at one point but their lines of action do not lie in one plane, are called</span>
                            <div class="option"><span class="optionNum">A</span>non-coplanar and non-concurrent forces</div>
                            <div class="option"><span class="optionNum">B</span>coplanar and non-concurrent forces</div>
                            <div class="option"><span class="optionNum">C</span>non-coplanar and concurrent forces</div>
                            <div class="option"><span class="optionNum">D</span>coplanar and concurrent forces</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol3')">
                            <div id="textsol3" class="textSolution" style="display:none">non-coplanar and concurrent forces</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">4</span>
                            <span class="question">Two vectors of equal magnitude have a resultant equal or either of them in magnitude.
                                the angle between them is 
                            </span>
                            <div class="option"><span class="optionNum">A</span>60</div>
                            <div class="option"><span class="optionNum">B</span>90</div>
                            <div class="option"><span class="optionNum">C</span>105</div>
                            <div class="option"><span class="optionNum">D</span>120</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol4')">
                            <div id="textsol4" class="textSolution" style="display:none">120</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">5</span>
                            <span class="question">Which of th following system of units is not based on units of mass, length and time alone</span>
                            <div class="option"><span class="optionNum">A</span>SI</div>
                            <div class="option"><span class="optionNum">B</span>MKS</div>
                            <div class="option"><span class="optionNum">C</span>FPS</div>
                            <div class="option"><span class="optionNum">D</span>CGS</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol5')">
                            <div id="textsol5" class="textSolution" style="display:none">These</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">6</span>
                            <span class="question">Forces 3N, 4N and 12N act at a poinnt in mutually perpendicular directions.
                             The magnitude of the resultant force is</span>
                            <div class="option"><span class="optionNum">A</span>5N</div>
                            <div class="option"><span class="optionNum">B</span>19N</div>
                            <div class="option"><span class="optionNum">C</span>13N</div>
                            <div class="option"><span class="optionNum">D</span>11N</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol6')">
                            <div id="textsol6" class="textSolution" style="display:none">13N</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">7</span>
                            <span class="question">Find the sum of  1+2+3+4+8+.....+256</span>
                            <div class="option"><span class="optionNum">A</span>510</div>
                            <div class="option"><span class="optionNum">B</span>511</div>
                            <div class="option"><span class="optionNum">C</span>512</div>
                            <div class="option"><span class="optionNum">D</span>513</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol7')">
                            <div id="textsol7" class="textSolution" style="display:none">511</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">8</span>
                            <span class="question">If two forces act in opposite then their resultant is 10N and if they act mutually 
                                perpendicular then their resultant is 50N. Find the magnitude of both the forces.
                            </span>
                            <div class="option"><span class="optionNum">A</span>40N & 50N</div>
                            <div class="option"><span class="optionNum">B</span>40N & 60N</div>
                            <div class="option"><span class="optionNum">C</span>40N & 30N</div>
                            <div class="option"><span class="optionNum">D</span>40N & 25N</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol8')">
                            <div id="textsol8" class="textSolution" style="display:none">40N & 30N</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">9</span>
                            <span class="question">What will be the sum of first 50 natural numbers</span>
                            <div class="option"><span class="optionNum">A</span>1000</div>
                            <div class="option"><span class="optionNum">B</span>1275</div>
                            <div class="option"><span class="optionNum">C</span>1270</div>
                            <div class="option"><span class="optionNum">D</span>1280</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol9')">
                            <div id="textsol9" class="textSolution" style="display:none">1275</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">10</span>
                            <span class="question">A particle moves along the straight line y = 3x + 5.
                                which coordinate changes at a faster rate </span>
                            <div class="option"><span class="optionNum">A</span>x-coordinate</div>
                            <div class="option"><span class="optionNum">B</span>y-coordinate</div>
                            <div class="option"><span class="optionNum">C</span>both x and y coordinate</div>
                            <div class="option"><span class="optionNum">D</span>Data insufficient</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol10')">
                            <div id="textsol10" class="textSolution" style="display:none">y-coordinate</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">11</span>
                            <span class="question">What is the maximum numbers of components into which a vector can be split</span>
                            <div class="option"><span class="optionNum">A</span>2</div>
                            <div class="option"><span class="optionNum">B</span>3</div>
                            <div class="option"><span class="optionNum">C</span>4</div>
                            <div class="option"><span class="optionNum">D</span>Infinite</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol11')">
                            <div id="textsol11" class="textSolution" style="display:none">Infinite</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">12</span>
                            <span class="question">The vector sum of the forces of 10 newton and 6 newton is</span>
                            <div class="option"><span class="optionNum">A</span>2N</div>
                            <div class="option"><span class="optionNum">B</span>8N</div>
                            <div class="option"><span class="optionNum">C</span>12N</div>
                            <div class="option"><span class="optionNum">D</span>20N</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol12')">
                            <div id="textsol12" class="textSolution" style="display:none">8N</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">13</span>
                            <span class="question">The vector sum of two forces is perpendicular to their vector difference.
                                 In that case, the force
                            </span>
                            <div class="option"><span class="optionNum">A</span>Are equal to each other</div>
                            <div class="option"><span class="optionNum">B</span>Are equal to each other in magnitude</div>
                            <div class="option"><span class="optionNum">C</span>Are not equal to each other in magnitude</div>
                            <div class="option"><span class="optionNum">D</span>Cannot be predictedd</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol13')">
                            <div id="textsol13" class="textSolution" style="display:none">Are equal to each other in magnitude</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">14</span>
                            <span class="question">Which of the following physical quantities is an axial vector</span>
                            <div class="option"><span class="optionNum">A</span>displacement</div>
                            <div class="option"><span class="optionNum">B</span>force</div>
                            <div class="option"><span class="optionNum">C</span>velocity</div>
                            <div class="option"><span class="optionNum">D</span>torque</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol14')">
                            <div id="textsol14" class="textSolution" style="display:none">torque</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">15</span>
                            <span class="question">The greatest value of the function -5sin&Theta; + 12cos&Theta;x is</span>
                            <div class="option"><span class="optionNum">A</span>12</div>
                            <div class="option"><span class="optionNum">B</span>13</div>
                            <div class="option"><span class="optionNum">C</span>7</div>
                            <div class="option"><span class="optionNum">D</span>17</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol15')">
                            <div id="textsol15" class="textSolution" style="display:none">13</div>
                        </form>
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->