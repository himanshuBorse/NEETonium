 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Mechanical Properties of Solids</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Mechanical Properties of Solids</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Mechanical Properties of Solids</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Stress is the restoring force per unit area and strain is the fractional change in dimension.
In general there are three types of stresses (a) tensile stress — longitudinal stress
(associated with stretching) or compressive stress (associated with compression),
(b) shearing stress, and (c) hydraulic stress.
                    </li>
                    <li>
                    For small deformations, stress is directly proportional to the strain for many materials.
This is known as Hooke’s law. The constant of proportionality is called modulus of
elasticity. Three elastic moduli viz., Young’s modulus, shear modulus and bulk modulus
are used to describe the elastic behaviour of objects as they respond to deforming forces
that act on them.
A class of solids called elastomers does not obey Hooke’s law
                    </li>
                    <li>
                    In the case of a wire, suspended from celing and stretched under the action of a weight (F)
suspended from its other end, the force exerted by the ceiling on it is equal and opposite
to the weight. However, the tension at any cross-section A of the wire is just F and not
2F. Hence, tensile stress which is equal to the tension per unit area is equal to F/A.
                    </li>
                    <li>
                    Hooke’s law is valid only in the linear part of stress-strain curve
                    </li>
                    <li>
                    The Young’s modulus and shear modulus are relevant only for solids since only solids
have lengths and shapes.
                    </li>
                    <li>
                    Bulk modulus is relevant for solids, liquid and gases. It refers to the change in volume
when every part of the body is under the uniform stress so that the shape of the body
remains unchanged
                    </li>
                    <li>
                    Metals have larger values of Young’s modulus than alloys and elastomers. A material
with large value of Young’s modulus requires a large force to produce small changes in
its length.
                    </li>
                    <li>
                    In daily life, we feel that a material which stretches more is more elastic, but it a is
misnomer. In fact material which stretches to a lesser extent for a given load is considered
to be more elastic.
                    </li>
                    <li>
                    In general, a deforming force in one direction can produce strains in other directions
also. The proportionality between stress and strain in such situations cannot be described
by just one elastic constant. For example, for a wire under longitudinal strain, the
lateral dimensions (radius of cross section) will undergo a small change, which is described
by another elastic constant of the material (called Poisson ratio).
                    </li>
                    <li>
                    Stress is not a vector quantity since, unlike a force, the stress cannot be assigned a
specific direction. Force acting on the portion of a body on a specified side of a section
has a definite direction.

                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->