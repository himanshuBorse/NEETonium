 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Thermal Properties of Matter</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Thermal Properties of Matter</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Thermal Properties of Matter</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Heat is a form of energy that flows between a body and its surrounding medium by
virtue of temperature difference between them. The degree of hotness of the body is
quantitatively represented by temperature.
                    </li>
                    <li>
                    A temperature-measuring device (thermometer) makes use of some measurable property
(called thermometric property) that changes with temperature. Different thermometers
lead to different temperature scales. To construct a temperature scale, two fixed points
are chosen and assigned some arbitrary values of temperature. The two numbers fix
the origin of the scale and the size of its unit.
                    </li>
                    <li>
                    The latent heat of fusion (Lf
) is the heat per unit mass required to change a substance
from solid into liquid at the same temperature and pressure. The latent heat of
vaporisation (Lv
) is the heat per unit mass required to change a substance from liquid
to the vapour state without change in the temperature and pressure
                    </li>
                    <li>
                    The three modes of heat transfer are conduction, convection and radiation.
                    </li>
                    <li>
                    A liquid in equilibrium with vapour has the same pressure and temperature throughout
the system; the two phases in equilibrium differ in their molar volume (i.e. density).
This is true for a system with any number of phases in equilibrium.
                    </li>
                    <li>
                    Heat transfer always involves temperature difference between two systems or two parts
of the same system. Any energy transfer that does not involve temperature difference
in some way is not heat.
                    </li>
                    <li>
                    Convection involves flow of matter within a fluid due to unequal temperatures of its
parts. A hot bar placed under a running tap loses heat by conduction between the
surface of the bar and water and not by convection within water.      
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->