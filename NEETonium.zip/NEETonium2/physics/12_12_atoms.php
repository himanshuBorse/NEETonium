 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Atoms</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Atoms</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Atoms</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Atom, as a whole, is electrically neutral and therefore contains equal
amount of positive and negative charges.
                    </li>
                    <li>
                    In Thomson’s model, an atom is a spherical cloud of positive charges
with electrons embedded in it.
                    </li>
                    <li>
                    In Rutherford’s model, most of the mass of the atom and all its positive
charge are concentrated in a tiny nucleus (typically one by ten thousand
the size of an atom), and the electrons revolve around it.
                    </li>
                    <li>
                    Rutherford nuclear model has two main difficulties in explaining the
structure of atom: (a) It predicts that atoms are unstable because the
accelerated electrons revolving around the nucleus must spiral into
the nucleus. This contradicts the stability of matter. (b) It cannot
explain the characteristic line spectra of atoms of different elements.
                    </li>
                    <li>
                    Atoms of most of the elements are stable and emit characteristic
spectrum. The spectrum consists of a set of isolated parallel lines
termed as line spectrum. It provides useful information about the
atomic structure.
                    </li>
                    <li>
                    de Broglie’s hypothesis that electrons have a wavelength λ = h/mv gave
an explanation for Bohr’s quantised orbits by bringing in the waveparticle duality. The orbits correspond to circular standing waves in
which the circumference of the orbit equals a whole number of
wavelengths.
                    </li>
                    <li>
                    Bohr’s model is applicable only to hydrogenic (single electron) atoms.
It cannot be extended to even two electron atoms such as helium.
This model is also unable to explain for the relative intensities of the
frequencies emitted even by hydrogenic atoms.
                    </li>
                    <li>
                    Both the Thomson’s as well as the Rutherford’s models constitute an
unstable system. Thomson’s model is unstable electrostatically, while
Rutherford’s model is unstable because of electromagnetic radiation
of orbiting electrons.
                    </li>
                    <li>
                    The orbital picture in Bohr’s model of the hydrogen atom was
inconsistent with the uncertainty principle. It was replaced by modern
quantum mechanics in which Bohr’s orbits are regions where the
electron may be found with large probability.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->