 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Work, Energy and Power</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Work, Energy and Power</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Work, Energy and Power</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    The work-energy theorem states that the change in kinetic energy of a body is the work
done by the net force on the body.
                    </li>
                    <li>
                    A force is conservative if (i) work done by it on an object is path independent and
depends only on the end points {xi, xjs}, or (ii) the work done by the force is zero for an
arbitrary closed path taken by the object such that it returns to its initial position
                    </li>
                    <li>
                    The principle of conservation of mechanical energy states that the total mechanical
energy of a body remains constant if the only forces that act on the body are conservative.
                    </li>
                    <li>
                    The scalar or dot product of two vectors A and B is written as A.B and is a scalar
quantity given by : A.B = AB cos θ, where θ is the angle between A and B. It can be
positive, negative or zero depending upon the value of θ. The scalar product of two
vectors can be interpreted as the product of magnitude of one vector and component
of the other vector along the first vector
                    </li>
                    <li>
                    The phrase ‘calculate the work done’ is incomplete. We should refer (or imply
clearly by context) to the work done by a specific force or a group of forces on a
given body over a certain displacement
                    </li>
                    <li>
                    Work done is a scalar quantity. It can be positive or negative unlike mass and
kinetic energy which are positive scalar quantitie
                    </li>
                    <li>
                    The work done by a force can be calculated sometimes even if the exact nature of
the force is not known. This is clear from Example 6.2 where the WE theorem is
used in such a situation.
                    </li>
                    <li>
                    The WE theorem is not independent of Newton’s Second Law. The WE theorem
may be viewed as a scalar form of the Second Law. The principle of conservation
of mechanical energ
                    </li>
                    <li>
                    The WE theorem holds in all inertial frames. It can also be extended to noninertial frames provided we include the pseudoforces in the calculation of the
net force acting on the body under consideration.   
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">1</span>
                            <span class="question">The kinetic energ of a body becomes four times of its initial value.
                                The new linear momentum will be
                            </span>
                            <div class="option"><span class="optionNum">A</span>Four times the initial value</div>
                            <div class="option"><span class="optionNum">B</span>Thrice the initial value</div>
                            <div class="option"><span class="optionNum">C</span>Twice the initial value</div>
                            <div class="option"><span class="optionNum">D</span>Same as the initial value</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">Twice the initial value</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">2</span>
                            <span class="question">If K.E. increases by 3%. Then momentum will increases by</span>
                            <div class="option"><span class="optionNum">A</span>1.5%</div>
                            <div class="option"><span class="optionNum">B</span>9%</div>
                            <div class="option"><span class="optionNum">C</span>3%</div>
                            <div class="option"><span class="optionNum">D</span>2%</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol2')">
                            <div id="textsol2" class="textSolution" style="display:none">1.5%</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">3</span>
                            <span class="question">A person of mss m is standing on one end of a plank of mass M and length L 
                                and floating in water. The person moves from one end to another and stops. Work done by normal force is 
                            </span>
                            <div class="option"><span class="optionNum">A</span>MgL</div>
                            <div class="option"><span class="optionNum">B</span>mgL</div>
                            <div class="option"><span class="optionNum">C</span>Mg/L</div>
                            <div class="option"><span class="optionNum">D</span>0</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol3')">
                            <div id="textsol3" class="textSolution" style="display:none">0</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">4</span>
                            <span class="question">The work done against gravity in taking 10 kg. mass at 1m height in 1s will be</span>
                            <div class="option"><span class="optionNum">A</span>49 J</div>
                            <div class="option"><span class="optionNum">B</span>98 J</div>
                            <div class="option"><span class="optionNum">C</span>196 J</div>
                            <div class="option"><span class="optionNum">D</span>None of these above</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol4')">
                            <div id="textsol4" class="textSolution" style="display:none">98 J</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">5</span>
                            <span class="question">A 2 kg mass lying on a table is displaced in the horizontal direction through 50 cm. 
                                The work done by the normal reaction will be
                            </span>
                            <div class="option"><span class="optionNum">A</span>0</div>
                            <div class="option"><span class="optionNum">B</span>100 joule</div>
                            <div class="option"><span class="optionNum">C</span>100 erg</div>
                            <div class="option"><span class="optionNum">D</span>10 joule</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol5')">
                            <div id="textsol5" class="textSolution" style="display:none">0</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">6</span>
                            <span class="question">The Potential energy of a system increases if work is done</span>
                            <div class="option"><span class="optionNum">A</span>Upon the system by a nonconservative force</div>
                            <div class="option"><span class="optionNum">B</span>By the system against a conservative force</div>
                            <div class="option"><span class="optionNum">C</span>By the system against a nonconservative force</div>
                            <div class="option"><span class="optionNum">D</span>Upon the system by a conservative force</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol6')">
                            <div id="textsol6" class="textSolution" style="display:none">By the system against a conservative force</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">7</span>
                            <span class="question">A block of mass 20 kg is moved with constant velocity along an inclined plane of 
                                inclination 37&deg; with help of a force of constant power 50 W. If the coefficient of kinetic friction between block 
                                and surface is 0.25, then what fraction of power is used against gravity
                            </span>
                            <div class="option"><span class="optionNum">A</span>3/4</div>
                            <div class="option"><span class="optionNum">B</span>1/4</div>
                            <div class="option"><span class="optionNum">C</span>1/2</div>
                            <div class="option"><span class="optionNum">D</span>1/8</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol7')">
                            <div id="textsol7" class="textSolution" style="display:none">3/4</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">8</span>
                            <span class="question">A machine which is 75% efficient, uses 12 J of energy in lifting 1 kg through a certain 
                                distance. The mass is then allowed to fall through the same distance, the velocity at the end of its fall is
                            </span>
                            <div class="option"><span class="optionNum">A</span>&radic;12 m/s</div>
                            <div class="option"><span class="optionNum">B</span>&radic;18 m/s</div>
                            <div class="option"><span class="optionNum">C</span>&radic;24 m/s</div>
                            <div class="option"><span class="optionNum">D</span>&radic;32 m/s</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol8')">
                            <div id="textsol8" class="textSolution" style="display:none">&radic;18 m/s</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">9</span>
                            <span class="question">A block of mass 10 kg, moving in x direction with a constant speed of 10 m/s, 
                                is subjected to a retarding force F=0.1x J/m during its travel from x=20 m to 30m. its final KE will be
                            </span>
                            <div class="option"><span class="optionNum">A</span>450 J</div>
                            <div class="option"><span class="optionNum">B</span>275 J</div>
                            <div class="option"><span class="optionNum">C</span>250 J</div>
                            <div class="option"><span class="optionNum">D</span>475 J</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol9')">
                            <div id="textsol9" class="textSolution" style="display:none">475 J</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">10</span>
                            <span class="question">A boy of mass 50 kg jumps to a height of 0.8m from the ground then momentum transferred by the ground 
                                to boy is
                            </span>
                            <div class="option"><span class="optionNum">A</span>400 kg m/s</div>
                            <div class="option"><span class="optionNum">B</span>200 kg m/s</div>
                            <div class="option"><span class="optionNum">C</span>800 kg m/s</div>
                            <div class="option"><span class="optionNum">D</span>500 kg m/s</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol10')">
                            <div id="textsol10" class="textSolution" style="display:none">200 kg m/s</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">11</span>
                            <span class="question">A 0.5 kg ball is thrown up with an initial speed 14 m/s and reaches a maximum height of 8.0 m.
                                 How much energy is dissipated by air drag acting on the ball during the ascent
                            </span>
                            <div class="option"><span class="optionNum">A</span>19.6 J</div>
                            <div class="option"><span class="optionNum">B</span>4.9  J</div>
                            <div class="option"><span class="optionNum">C</span>10 J</div>
                            <div class="option"><span class="optionNum">D</span>9.8 J</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol11')">
                            <div id="textsol11" class="textSolution" style="display:none">9.8 J</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">12</span>
                            <span class="question">A 2 g ball of glass is released from the edge of a hemispherical cup whose radius is 20 cm 
                                How much work is done on the ball by the gravitational force during the ball's motion to the bottom of the cup?
                            </span>
                            <div class="option"><span class="optionNum">A</span>1.96 mJ</div>
                            <div class="option"><span class="optionNum">B</span>3.92 mJ</div>
                            <div class="option"><span class="optionNum">C</span>4.90 mJ</div>
                            <div class="option"><span class="optionNum">D</span>5.88 mJ</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol12')">
                            <div id="textsol12" class="textSolution" style="display:none">3.92 mJ</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">13</span>
                            <span class="question">In stretching a spring by 2 cm energy stored is given by U, then stretching by 10 cm 
                                energy stored will be
                            </span>
                            <div class="option"><span class="optionNum">A</span>U</div>
                            <div class="option"><span class="optionNum">B</span>5U</div>
                            <div class="option"><span class="optionNum">C</span>U/25</div>
                            <div class="option"><span class="optionNum">D</span>25U</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol13')">
                            <div id="textsol13" class="textSolution" style="display:none">25U</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">14</span>
                            <span class="question">Which of the following is a non-conservative force</span>
                            <div class="option"><span class="optionNum">A</span>Electric force</div>
                            <div class="option"><span class="optionNum">B</span>Gravitational force</div>
                            <div class="option"><span class="optionNum">C</span>Spring force</div>
                            <div class="option"><span class="optionNum">D</span>Viscous force</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol14')">
                            <div id="textsol14" class="textSolution" style="display:none">Viscous force</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">15</span>
                            <span class="question">What average horsepower is developed by an 80kg man while 
                                climbing in 10s flight of stairs that rises 6m vertically
                            </span>
                            <div class="option"><span class="optionNum">A</span>0.63 hp</div>
                            <div class="option"><span class="optionNum">B</span>1.26 hp</div>
                            <div class="option"><span class="optionNum">C</span>1.8 hp</div>
                            <div class="option"><span class="optionNum">D</span>2.1 hp</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol15')">
                            <div id="textsol15" class="textSolution" style="display:none">0.63 hp</div>
                        </form>
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->