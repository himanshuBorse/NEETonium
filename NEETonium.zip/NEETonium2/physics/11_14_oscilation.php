 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Oscillations</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Oscillations</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Oscillations</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    The motion that repeats itself is called periodic motion
                    </li>
                    <li>
                    Simple harmonic motion can also be viewed as the projection of uniform circular
motion on the diameter of the circle in which the latter motion occurs.
                    </li>
                    <li>
                    The force acting in a simple harmonic motion is proportional to the displacement and
is always directed towards the centre of motion.
                    </li>
                    <li>
                    The period T is the least time after which motion repeats itself. Thus, motion repeats
itself after nT where n is an integer.
                    </li>
                    <li>
                    Every periodic motion is not simple harmonic motion. Only that periodic motion
governed by the force law F = – k x is simple harmonic.
                    </li>
                    <li>
                    Circular motion can arise due to an inverse-square law force (as in planetary motion)
as well as due to simple harmonic force in two dimensions equal to: –mω2
r. In the
latter case, the phases of motion, in two perpendicular directions (x and y) must differ
by π/2. Thus, for example, a particle subject to a force –mω2
r with initial position (0,
A) and velocity (ωA, 0) will move uniformly in a circle of radius A.
                    </li>
                    <li>
                    For linear simple harmonic motion with a given ω, two initial conditions are necessary
and sufficient to determine the motion completely. The initial conditions may be (i)
initial position and initial velocity or (ii) amplitude and phase or (iii) energy
and phase.
                    </li>
                    <li>
                    In the ideal case of zero damping, the amplitude of simple harmonic motion at resonance
is infinite. Since all real systems have some damping, however small, this situation is
never observed
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->