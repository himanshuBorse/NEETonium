 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Wave Optics</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Wave Optics</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Wave Optics</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Huygens’ principle tells us that each point on a wavefront is a source
of secondary waves, which add up to give the wavefront at a later time
                    </li>
                    <li>
                    Huygens’ construction tells us that the new wavefront is the forward
envelope of the secondary waves. When the speed of light is
independent of direction, the secondary waves are spherical. The rays
are then perpendicular to both the wavefronts and the time of travel
is the same measured along any ray. This principle leads to the well
known laws of reflection and refraction.
                    </li>
                    <li>
                    The principle of superposition of waves applies whenever two or more
sources of light illuminate the same point. When we consider the
intensity of light due to these sources at the given point, there is an
interference term in addition to the sum of the individual intensities.
But this term is important only if it has a non-zero average, which
occurs only if the sources have the same frequency and a stable
phase difference.
                    </li>
                    <li>
                    Young’s double slit of separation d gives equally spaced fringes of
angular separation λ/d. The source, mid-point of the slits, and central
bright fringe lie in a straight line. An extended source will destroy
the fringes if it subtends angle more than λ/d at the slits.
                    </li>
                    <li>
                    Natural light, e.g., from the sun is unpolarised. This means the electric
vector takes all possible directions in the transverse plane, rapidly
and randomly, during a measurement. A polaroid transmits only one
component (parallel to a special axis). The resulting light is called
linearly polarised or plane polarised. When this kind of light is viewed
through a second polaroid whose axis turns through 2π, two maxima
and minima of intensity are seen. Polarised light can also be produced
by reflection at a special angle (called the Brewster angle) and by
scattering through π/2 in the earth’s atmosphere.
                    </li>
                    <li>
                    Waves from a point source spread out in all directions, while light was
seen to travel along narrow rays. It required the insight and experiment
of Huygens, Young and Fresnel to understand how a wave theory could
explain all aspects of the behaviour of light.
                    </li>
                    <li>
                    The crucial new feature of waves is interference of amplitudes from different
sources which can be both constructive and destructive, as shown in
Young’s experiment.
                    </li>
                    <li>
                    Diffraction phenomena define the limits of ray optics. The limit of the
ability of microscopes and telescopes to distinguish very close objects is
set by the wavelength of light.
                    </li>
                    <li>
                    Most interference and diffraction effects exist even for longitudinal waves
like sound in air. But polarisation phenomena are special to transverse
waves like light waves.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->