 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Systems of Particles and Rotational Motion</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Systems of Particles and Rotational Motion</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Systems of Particles and Rotational Motion</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Ideally, a rigid body is one for which the distances between different particles of the
body do not change, even though there are forces on them.
                    </li>
                    <li>
                    A rigid body fixed at one point or along a line can have only rotational motion. A rigid
body not fixed in some way can have either pure translational motion or a combination
of translational and rotational motions.
                    </li>
                    <li>
                    In rotation about a fixed axis, every particle of the rigid body moves in a circle which
lies in a plane perpendicular to the axis and has its centre on the axis. Every Point in
the rotating rigid body has the same angular velocity at any instant of time.
                    </li>
                    <li>
                    In pure translation, every particle of the body moves with the same velocity at any
instant of time.
                    </li>
                    <li>
                    Velocity of the centre of mass of a system of particles is given by V = P/M, where P is the
linear momentum of the system. The centre of mass moves as if all the mass of the
system is concentrated at this point and all the external forces act at it. If the total
external force on the system is zero, then the total linear momentum of the system is
constant.
                    </li>
                    <li>
                    The centre of gravity of an extended body is that point where the total gravitational
torque on the body is zero.
                    </li>
                    <li>
                    Rotation about a fixed axis is directly analogous to linear motion in respect of kinematics
and dynamics
                    </li>
                    <li>
                    To determine the motion of the centre of mass of a system no knowledge of internal
forces of the system is required. For this purpose we need to know only the external
forces on the body.
                    </li>
                    <li>
                    Newton’s Second Law for finite sized bodies (or systems of particles) is based in Newton’s
Second Law and also Newton’s Third Law for particles.
                    </li>
                    <li>
                    The angular momentum L and the angular velocity ω are not necessarily parallel vectors.
However, for the simpler situations discussed in this chapter when rotation is about a
fixed axis which is an axis of symmetry of the rigid body, the relation L = Iω holds good,
where I is the moment of the inertia of the body about the rotation axis.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->