 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Waves</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Waves</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Waves</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Mechanical waves can exist in material media and are governed by Newton’s Laws.
                    </li>
                    <li>
                    Transverse waves are waves in which the particles of the medium oscillate perpendicular
to the direction of wave propagation.
                    </li>
                    <li>
                    Longitudinal waves are waves in which the particles of the medium oscillate along the
direction of wave propagation.  
                    </li>
                    <li>
                    Progressive wave is a wave that moves from one point of medium to another   
                    </li>
                    <li>
                    Wavelength λ of a progressive wave is the distance between two consecutive points of
the same phase at a given time. In a stationary wave, it is twice the distance between
two consecutive nodes or antinodes.     
                    </li>
                    <li>
                    A string of length L fixed at both ends or an air column closed at one end and open at
the other end or open at both the ends, vibrates with certain frequencies called their
normal modes. Each of these frequencies is a resonant frequency of the system.
                    </li>
                    <li>
                    A wave is not motion of matter as a whole in a medium. A wind is different from the
sound wave in air. The former involves motion of air from one place to the other. The
latter involves compressions and rarefactions of layers of air.
                    </li>
                    <li>
                    In a wave, energy and not the matter is transferred from one point to the other.
                    </li>
                    <li>
                    Transverse waves can propagate only in medium with shear modulus of elasticity,
Longitudinal waves need bulk modulus of elasticity and are therefore, possible in all
media, solids, liquids and gases.
                    </li>
                    <li>
                    In a harmonic progressive wave of a given frequency, all particles have the same
amplitude but different phases at a given instant of time. In a stationary wave, all
particles between two nodes have the same phase at a given instant but have different
amplitudes.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->