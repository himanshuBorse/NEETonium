 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Motion in a Straight Line</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Motion in a Straight Line</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Motion in a Straight Line</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                        An object is said to be in motion if its position changes with time. The position of the
                        object can be specified with reference to a conveniently chosen origin. For motion in
                        a straight line, position to the right of the origin is taken as positive and to the left as
                        negative.
                    </li>
                    <li>
                        Path length is defined as the total length of the path traversed by an object
                    </li>
                    <li>
                        Displacement is the change in position : ∆x = x<sub>2</sub> – x<sub>1</sub>. Path length is greater or equal to
                        the magnitude of the displacement between the same points.
                    </li>
                    <li>
                        An object is said to be in uniform motion in a straight line if its displacement is equal
                        in equal intervals of time. Otherwise, the motion is said to be non-uniform.
                    </li>
                    <li>
                        Average Speed is the ratio of total path length traversed and the corresponding time interval.
                        The average speed of an object is greater or equal to the magnitude of the average
                        velocity over a given time interval.
                    </li>
                    <li>
                        The area under the velocity-time curve between times t<sub>1</sub> and t<sub>2</sub>
                        is equal to the displacement of the object during that interval of time
                    </li>
                    <li>
                        The path length traversed by an object between two points is, in general, not the same
                        as the magnitude of displacement. The displacement depends only on the end points;
                        the path length (as the name implies) depends on the actual path. In one dimension,
                        the two quantities are equal only if the object does not change its direction during the
                        course of motion. In all other cases, the path length is greater than the magnitude of
                        displacement.
                    </li>
                    <li>
                        In view of point 1 above, the average speed of an object is greater than or equal to the
                        magnitude of the average velocity over a given time interval. The two are equal only if
                        the path length is equal to the magnitude of displacement.
                    </li>
                    <li>
                        The origin and the positive direction of an axis are a matter of choice. You should first
                        specify this choice before you assign signs to quantities like displacement, velocity
                        and acceleration.
                    </li>
                    <li>
                        If a particle is speeding up, acceleration is in the direction of velocity; if its speed is
                        decreasing, acceleration is in the direction opposite to that of the velocity. This
                        statement is independent of the choice of the origin and the axis.
                    </li>
                    <li>
                        The sign of acceleration does not tell us whether the particle’s speed is increasing or
                        decreasing. The sign of acceleration depends on the choice
                        of the positive direction of the axis. For example, if the vertically upward direction is
                        chosen to be the positive direction of the axis, the acceleration due to gravity is
                        negative. If a particle is falling under gravity, this acceleration, though negative,
                        results in increase in speed. For a particle thrown upward, the same negative
                        acceleration (of gravity) results in decrease in speed.
                    </li>
                    <li>
                        The zero velocity of a particle at any instant does not necessarily imply zero acceleration
                        at that instant. A particle may be momentarily at rest and yet have non-zero
                        acceleration. For example, a particle thrown up has zero velocity at its uppermost
                        point but the acceleration at that instant continues to be the acceleration due to
                        gravity.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">1</span>
                            <span class="question">A man moves 4m along east direction, then 3m along the north direction, after that he climbs
                                 up a pole to a height 12m. What is the distance and displacement covered by him
                            </span>
                            <div class="option"><span class="optionNum">A</span>19m and 11m</div>
                            <div class="option"><span class="optionNum">B</span>9m and 13m</div>
                            <div class="option"><span class="optionNum">C</span>19m and 13m</div>
                            <div class="option"><span class="optionNum">D</span>1m and 13m</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">19m and 13m</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">2</span>
                            <span class="question">A man has to go 50m due north, 40m due east and 20m due south to reach a cafe from his home. 
                                What is the distance and displacement is to be covered by him
                            </span>
                            <div class="option"><span class="optionNum">A</span>110m and 50m</div>
                            <div class="option"><span class="optionNum">B</span>110m and 55m</div>
                            <div class="option"><span class="optionNum">C</span>90m and 45m</div>
                            <div class="option"><span class="optionNum">D</span>90m and 50m</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol2')">
                            <div id="textsol2" class="textSolution" style="display:none">110m and 50m</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">3</span>
                            <span class="question">A car movs with a velocity 2.24 km/h in first minute, with 3.60 km/h in the second minute and with 
                                5.18 km/h in the third minute. What will be the average in these three minutes.
                            </span>
                            <div class="option"><span class="optionNum">A</span>3.67 km/h</div>
                            <div class="option"><span class="optionNum">B</span>3.70 km/h</div>
                            <div class="option"><span class="optionNum">C</span>4.67 km/h</div>
                            <div class="option"><span class="optionNum">D</span>4.75 km/h</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol3')">
                            <div id="textsol3" class="textSolution" style="display:none">3.67 km/h</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">4</span>
                            <span class="question">If displacement of a particle is zero, the distance covered</span>
                            <div class="option"><span class="optionNum">A</span>must be zero</div>
                            <div class="option"><span class="optionNum">B</span>may or may not be zero</div>
                            <div class="option"><span class="optionNum">C</span>cannot be zero</div>
                            <div class="option"><span class="optionNum">D</span>depends upon the particla</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol4')">
                            <div id="textsol4" class="textSolution" style="display:none">may or may not be zero</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">5</span>
                            <span class="question">An athelete  completes one round of a circular track of radius R in 20 seconds. What will be his 
                                displacement at the end of 2 minutes 20 seconds
                            </span>
                            <div class="option"><span class="optionNum">A</span>Zero</div>
                            <div class="option"><span class="optionNum">B</span>2R</div>
                            <div class="option"><span class="optionNum">C</span>3R</div>
                            <div class="option"><span class="optionNum">D</span>4R</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol5')">
                            <div id="textsol5" class="textSolution" style="display:none">Zero</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">6</span>
                            <span class="question">A train covers the first half of the distance between two stations with a speed of 40 km/h 
                                and the other half with 60 km/h. Then its aveage speed is
                            </span>
                            <div class="option"><span class="optionNum">A</span>50 km/h</div>
                            <div class="option"><span class="optionNum">B</span>48 km/h</div>
                            <div class="option"><span class="optionNum">C</span>38 km/h</div>
                            <div class="option"><span class="optionNum">D</span>55 km/h</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol6')">
                            <div id="textsol6" class="textSolution" style="display:none">48 km/h</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">7</span>
                            <span class="question">The numerical ration of displacement to the distance covered is always</span>
                            <div class="option"><span class="optionNum">A</span>less than one</div>
                            <div class="option"><span class="optionNum">B</span>equal to one</div>
                            <div class="option"><span class="optionNum">C</span>equal to or less than one</div>
                            <div class="option"><span class="optionNum">D</span>equal to or greater than one</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol7')">
                            <div id="textsol7" class="textSolution" style="display:none">equal to or less than one</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">8</span>
                            <span class="question">If the body starts from rest, the time in which it covers a particular displacement with uniform acceleration is</span>
                            <div class="option"><span class="optionNum">A</span>inversely proportional to the square root of the displacement</div>
                            <div class="option"><span class="optionNum">B</span>inversely proportional to the displacement</div>
                            <div class="option"><span class="optionNum">C</span>directly proportional to the displacement</div>
                            <div class="option"><span class="optionNum">D</span>directly proportional to the square root of the displacement</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol8')">
                            <div id="textsol8" class="textSolution" style="display:none">directly proportional to the square root of the displacement</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">9</span>
                            <span class="question">A car moving with a speed of the 40 km/h can be stopped by applying brakes after at least 2m. If the 
                                same car is moving with a speed  of 80 km/h, what is the minimum stopping distance
                            </span>
                            <div class="option"><span class="optionNum">A</span>2m</div>
                            <div class="option"><span class="optionNum">B</span>4m</div>
                            <div class="option"><span class="optionNum">C</span>6m</div>
                            <div class="option"><span class="optionNum">D</span>8m</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol9')">
                            <div id="textsol9" class="textSolution" style="display:none">8m</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">10</span>
                            <span class="question">A bus is moving with a speed of 10 m/s on a straight road. A scooterist wishes to overtake the bus in 100s. If the bus is 
                                 at a distance of 1km from the scooterist, with what speed should the scooterist chase the bus
                            </span>
                            <div class="option"><span class="optionNum">A</span>10 m/s</div>
                            <div class="option"><span class="optionNum">B</span>20 m/s</div>
                            <div class="option"><span class="optionNum">C</span>40 m/s</div>
                            <div class="option"><span class="optionNum">D</span>25 m/s</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol10')">
                            <div id="textsol10" class="textSolution" style="display:none">20 m/s</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">11</span>
                            <span class="question">A stone is dropped from a height h. It hits the ground with certaing momentum P. If the same stone is dropped from a height 
                                100% more than the previous height, the momentum when it hits the ground will change by
                            </span>
                            <div class="option"><span class="optionNum">A</span>200%</div>
                            <div class="option"><span class="optionNum">B</span>100%</div>
                            <div class="option"><span class="optionNum">C</span>68%</div>
                            <div class="option"><span class="optionNum">D</span>41%</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol11')">
                            <div id="textsol11" class="textSolution" style="display:none">41%</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">12</span>
                            <span class="question">A particle travels 10m in first 5 seconds and 10m in next 3 seconds. Assuming constant acceleration, 
                                what is the distance travelled in next 2 second
                            </span>
                            <div class="option"><span class="optionNum">A</span>8.3m</div>
                            <div class="option"><span class="optionNum">B</span>9.3m</div>
                            <div class="option"><span class="optionNum">C</span>10.3m</div>
                            <div class="option"><span class="optionNum">D</span>None of these</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol12')">
                            <div id="textsol12" class="textSolution" style="display:none">8.3m</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">13</span>
                            <span class="question">The location of a particle is changed. What can we say about the displacement and distance covered by the particle</span>
                            <div class="option"><span class="optionNum">A</span>Both cannot be zero</div>
                            <div class="option"><span class="optionNum">B</span>One of the two may be zero</div>
                            <div class="option"><span class="optionNum">C</span>Both must be zero</div>
                            <div class="option"><span class="optionNum">D</span>If one is positive, the other is negative and vice-versa</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol13')">
                            <div id="textsol13" class="textSolution" style="display:none">Both cannot be zero</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">14</span>
                            <span class="question">The magnitude of average velocity is equal to the average speed when a particle moves</span>
                            <div class="option"><span class="optionNum">A</span>on a curved path</div>
                            <div class="option"><span class="optionNum">B</span>in the same direction</div>
                            <div class="option"><span class="optionNum">C</span>with constant acceleration</div>
                            <div class="option"><span class="optionNum">D</span>with constant retardation</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol14')">
                            <div id="textsol14" class="textSolution" style="display:none">in the same direction</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">15</span>
                            <span class="question">A particle starts from the rest  with constant acceleration. The ration of space-average velocity to 
                                the time average velocity is
                            </span>
                            <div class="option"><span class="optionNum">A</span>1/2</div>
                            <div class="option"><span class="optionNum">B</span>3/4</div>
                            <div class="option"><span class="optionNum">C</span>4/3</div>
                            <div class="option"><span class="optionNum">D</span>3/2</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol15')">
                            <div id="textsol15" class="textSolution" style="display:none">4/3</div>
                        </form>
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->