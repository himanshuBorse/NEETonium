 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Ray Optics and Optical Instuments</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Ray Optics and Optical Instuments</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Ray Optics and Optical Instuments</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Reflection is governed by the equation ∠i = ∠r′ and refraction by the
Snell’s law, sini/sinr = n, where the incident ray, reflected ray, refracted
ray and normal lie in the same plane. Angles of incidence, reflection
and refraction are i, r ′ and r, respectively.
                    </li>
                    <li>
                    Cartesian sign convention: Distances measured in the same direction
as the incident light are positive; those measured in the opposite
direction are negative. All distances are measured from the pole/optic
centre of the mirror/lens on the principal axis. The heights measured
upwards above x-axis and normal to the principal axis of the mirror/
lens are taken as positive. The heights measured downwards are taken
as negative.
                    </li>
                    <li>
                    The laws of reflection and refraction are true for all surfaces and
pairs of media at the point of the incidence.
                    </li>
                    <li>
                    The real image of an object placed between f and 2f from a convex lens
can be seen on a screen placed at the image location. If the screen is
removed, is the image still there? This question puzzles many, because
it is difficult to reconcile ourselves with an image suspended in air
without a screen. But the image does exist. Rays from a given point
on the object are converging to an image point in space and diverging
away. The screen simply diffuses these rays, some of which reach our
eye and we see the image. This can be seen by the images formed in
air during a laser show.
                    </li>
                    <li>
                    Image formation needs regular reflection/refraction. In principle, all
rays from a given point should reach the same image point. This is
why you do not see your image by an irregular reflecting object, say
the page of a book.
                    </li>
                    <li>
                    Thick lenses give coloured images due to dispersion. The variety in
colour of objects we see around us is due to the constituent colours
of the light incident on them. A monochromatic light may produce an
entirely different perception about the colours on an object as seen in
white light.

                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->