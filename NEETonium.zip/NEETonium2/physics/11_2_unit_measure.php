 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Units and Measurement</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Units and Measurement</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Units and Measurement</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Physics is a quantitative science, based on measurement of physical quantities. Certain
physical quantities have been chosen as fundamental or base quantities (such as length,
mass, time, electric current, thermodynamic temperature, amount of substance, and
luminous intensity).
                    </li>
                    <li>
                    Each base quantity is defined in terms of a certain basic, arbitrarily chosen but properly
standardised reference standard called unit (such as metre, kilogram, second, ampere,
kelvin, mole and candela). The units for the fundamental or base quantities are called
fundamental or base units.
                    </li>
                    <li>
                    Other physical quantities, derived from the base quantities, can be expressed as a
combination of the base units and are called derived units. A complete set of units,
both fundamental and derived, is called a system of units.
                    </li>
                    <li>
                    The International System of Units (SI) based on seven base units is at present
internationally accepted unit system and is widely used throughout the world.
                    </li>
                    <li>
                    The SI units are used in all physical measurements, for both the base quantities and
the derived quantities obtained from them. Certain derived units are expressed by
means of SI units with special names (such as joule, newton, watt, etc).
                    </li>
                    <li>
                    The SI units have well defined and internationally accepted unit symbols (such as m for
metre, kg for kilogram, s for second, A for ampere, N for newton etc.).
                    </li>
                    <li>
                    Physical measurements are usually expressed for small and large quantities in scientific
notation, with powers of 10. Scientific notation and the prefixes are used to simplify
measurement notation and numerical computation, giving indication to the precision
of the numbers.
                    </li>
                    <li>
                    Certain general rules and guidelines must be followed for using notations for physical
quantities and standard symbols for SI units, some other units and SI prefixes for
expressing properly the physical quantities and measurements.
                    </li>
                    <li>
                    In computing any physical quantity, the units for derived quantities involved in the
relationship(s) are treated as though they were algebraic quantities till the desired
units are obtained.
                    </li>
                    <li>
                    Direct and indirect methods can be used for the measurement of physical quantities.
In measured quantities, while expressing the result, the accuracy and precision of
measuring instruments along with errors in measurements should be taken into account.
                    </li>
                    <li>
                    In measured and computed quantities proper significant figures only should be retained.
Rules for determining the number of significant figures, carrying out arithmetic
operations with them, and ‘rounding off ‘ the uncertain digits must be followed.
                    </li>
                    <li>
                    The dimensions of base quantities and combination of these dimensions describe the
nature of physical quantities. Dimensional analysis can be used to check the dimensional
consistency of equations, deducing relations among the physical quantities, etc. A
dimensionally consistent equation need not be actually an exact (correct) equation,
but a dimensionally wrong or inconsistent equation must be wrong.
                    </li>
                </ul>    
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">1</span>
                            <span class="question">Which of the following quantity is unitless</span>
                            <div class="option"><span class="optionNum">A</span>Velocity gradient</div>
                            <div class="option"><span class="optionNum">B</span>Pressure gradient</div>
                            <div class="option"><span class="optionNum">C</span>Displacement gradient</div>
                            <div class="option"><span class="optionNum">D</span>Force gradient</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">Displacement gradient</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">2</span>
                            <span class="question">The fundamental unit which has same power in the dimensional formula of surface
                                tensioin and co-efficient of viscosity is
                            </span>
                            <div class="option"><span class="optionNum">A</span>Mass</div>
                            <div class="option"><span class="optionNum">B</span>Length</div>
                            <div class="option"><span class="optionNum">C</span>Time</div>
                            <div class="option"><span class="optionNum">D</span>None</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol2')">
                            <div id="textsol2" class="textSolution" style="display:none">Mass</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">3</span>
                            <span class="question">Temperature can be expressed as a derived quantity in terms of which of the following</span>
                            <div class="option"><span class="optionNum">A</span>Length and mass</div>
                            <div class="option"><span class="optionNum">B</span>Mass and time</div>
                            <div class="option"><span class="optionNum">C</span>Length, mass and time</div>
                            <div class="option"><span class="optionNum">D</span>None of these</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol3')">
                            <div id="textsol3" class="textSolution" style="display:none">None of these</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">4</span>
                            <span class="question">A dimensionaless quantity </span>
                            <div class="option"><span class="optionNum">A</span>Never has a unit</div>
                            <div class="option"><span class="optionNum">B</span>Always has a unit</div>
                            <div class="option"><span class="optionNum">C</span>May have a unit</div>
                            <div class="option"><span class="optionNum">D</span>Does not exist</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol4')">
                            <div id="textsol4" class="textSolution" style="display:none">May have a unit</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">5</span>
                            <span class="question">A student measured the diameter of a wire using a screw guage with least
                                count 0.001cm and listed the measurements. The correct measurement is 
                            </span>
                            <div class="option"><span class="optionNum">A</span>5.3cm</div>
                            <div class="option"><span class="optionNum">B</span>5.32cm</div>
                            <div class="option"><span class="optionNum">C</span>5.320cm</div>
                            <div class="option"><span class="optionNum">D</span>5.3200cm</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol5')">
                            <div id="textsol5" class="textSolution" style="display:none">5.320cm</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">6</span>
                            <span class="question">Which of the following pairs does not have similar dimensions</span>
                            <div class="option"><span class="optionNum">A</span>Tension and surface tension</div>
                            <div class="option"><span class="optionNum">B</span>Stress and pressure</div>
                            <div class="option"><span class="optionNum">C</span>Planck's constant and angular momentum</div>
                            <div class="option"><span class="optionNum">D</span>Angle and strain</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol6')">
                            <div id="textsol6" class="textSolution" style="display:none">Tension and surface tension</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">7</span>
                            <span class="question">Which of the following does not have the same unit as others</span>
                            <div class="option"><span class="optionNum">A</span>wavelength</div>
                            <div class="option"><span class="optionNum">B</span>kilowatt-hour</div>
                            <div class="option"><span class="optionNum">C</span>eV</div>
                            <div class="option"><span class="optionNum">D</span>J-s</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol7')">
                            <div id="textsol7" class="textSolution" style="display:none">J-s</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">8</span>
                            <span class="question">The SI unit of enthropy is</span>
                            <div class="option"><span class="optionNum">A</span>joule/kelvin</div>
                            <div class="option"><span class="optionNum">B</span>newton-meter</div>
                            <div class="option"><span class="optionNum">C</span>calorie/second</div>
                            <div class="option"><span class="optionNum">D</span>joule/calorie</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol8')">
                            <div id="textsol8" class="textSolution" style="display:none">joule/kelvin</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">9</span>
                            <span class="question">Which of the following is not the unit of self inductance</span>
                            <div class="option"><span class="optionNum">A</span>weber/ampere</div>
                            <div class="option"><span class="optionNum">B</span>ohm-second</div>
                            <div class="option"><span class="optionNum">C</span>joule-ampere</div>
                            <div class="option"><span class="optionNum">D</span>joule-ampere^-2</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol9')">
                            <div id="textsol9" class="textSolution" style="display:none">joule-ampere</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">10</span>
                            <span class="question">In a particular system the units of length, mass and  time 
                                are chose to be 10cm, 10g and 0.1s respectively. The unit of force in this system will be 
                            </span>
                            <div class="option"><span class="optionNum">A</span>0.1N</div>
                            <div class="option"><span class="optionNum">B</span>1N</div>
                            <div class="option"><span class="optionNum">C</span>10N</div>
                            <div class="option"><span class="optionNum">D</span>100N</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol10')">
                            <div id="textsol10" class="textSolution" style="display:none">0.1N</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">11</span>
                            <span class="question">The period of oscillation of a simple pendulum in and experiment is recorded
                                as 2.63s, 2.56s, 2.42s, 2.71s and 2.80s respectively. The average absolute error is 
                            </span>
                            <div class="option"><span class="optionNum">A</span>0.1s</div>
                            <div class="option"><span class="optionNum">B</span>0.11s</div>
                            <div class="option"><span class="optionNum">C</span>0.01s</div>
                            <div class="option"><span class="optionNum">D</span>1.0s</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol11')">
                            <div id="textsol11" class="textSolution" style="display:none">0.11s</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">12</span>
                            <span class="question">If the error in the measurement of radius of a sphere is 2% then the error 
                                in the determination of volume of the sphere will be
                            </span>
                            <div class="option"><span class="optionNum">A</span>8%</div>
                            <div class="option"><span class="optionNum">B</span>2%</div>
                            <div class="option"><span class="optionNum">C</span>4%</div>
                            <div class="option"><span class="optionNum">D</span>6%</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol12')">
                            <div id="textsol12" class="textSolution" style="display:none">6%</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">13</span>
                            <span class="question">If voltage across a bulb rated 220 Volt, 100 Watt drops by 2.5% of its 
                                rated value, the percentage of the rated value by which the power would decrease is 
                            </span>
                            <div class="option"><span class="optionNum">A</span>5%</div>
                            <div class="option"><span class="optionNum">B</span>10%</div>
                            <div class="option"><span class="optionNum">C</span>20%</div>
                            <div class="option"><span class="optionNum">D</span>2.5%</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol13')">
                            <div id="textsol13" class="textSolution" style="display:none">5%</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">14</span>
                            <span class="question">One centimeter on the main scale of vernier callipers is divided into ten equal parts.
                                 If 10 divisions of vernier scale coincide with 8 small divisions of the main scale, the least count of the 
                                 callipers is
                            </span>
                            <div class="option"><span class="optionNum">A</span>0.01cm</div>
                            <div class="option"><span class="optionNum">B</span>0.02cm</div>
                            <div class="option"><span class="optionNum">C</span>0.05cm</div>
                            <div class="option"><span class="optionNum">D</span>0.005cm</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol14')">
                            <div id="textsol14" class="textSolution" style="display:none">0.02cm</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">15</span>
                            <span class="question">Which of the following is incorrect</span>
                            <div class="option"><span class="optionNum">A</span>All derived quantities may be represented dimensionally 
                        in term of the base quantites</div>
                            <div class="option"><span class="optionNum">B</span>A base quantity cannot be represented dimensionally 
                        in terms of other base quantites</div>
                            <div class="option"><span class="optionNum">C</span>The dimension of a derived quantity is never zero in any base quantity</div>
                            <div class="option"><span class="optionNum">D</span>The dimension of a base quantity in other base quantites is always zero</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol15')">
                            <div id="textsol15" class="textSolution" style="display:none">The dimension of a derived quantity is never zero in any base quantity</div>
                        </form>
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->