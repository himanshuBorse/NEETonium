 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Current Electricity</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Current Electricity</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Current Electricity</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Current through a given area of a conductor is the net charge passing
per unit time through the area.
                    </li>
                    <li>
                    To maintain a steady current, we must have a closed circuit in which
an external agency moves electric charge from lower to higher potential
energy. The work done per unit charge by the source in taking the
charge from lower to higher potential energy (i.e., from one terminal
of the source to the other) is called the electromotive force, or emf, of
the source. Note that the emf is not a force; it is the voltage difference
between the two terminals of a source in open circuit. 
                    </li>
                    <li>
                    Ohm’s law: The electric current I flowing through a substance is
proportional to the voltage V across its ends, i.e., V ∝ I or V = RI,
where R is called the resistance of the substance. The unit of resistance
is ohm: 1Ω = 1 V A–1.
                    </li>
                    <li>
                    In most substances, the carriers of current are electrons; in some
cases, for example, ionic crystals and electrolytic liquids, positive and
negative ions carry the electric current.
                    </li>
                    <li>
                    In the temperature range in which resistivity increases linearly with
temperature, the temperature coefficient of resistivity α is defined as
the fractional increase in resistivity per unit increase in temperature.
                    </li>
                    <li>
                    Junction Rule: At any junction of circuit elements, the sum of
currents entering the junction must equal the sum of currents
leaving it.
                    </li>
                    <li>
                    Loop Rule: The algebraic sum of changes in potential around any
closed loop must be zero.
                    </li>
                    <li>
                    The potentiometer is a device to compare potential differences. Since
the method involves a condition of no current flow, the device can be
used to measure potential difference; internal resistance of a cell and
compare emf’s of two sources.
                    </li>
                    <li>
                    Homogeneous conductors like silver or semiconductors like pure
germanium or germanium containing impurities obey Ohm’s law
within some range of electric field values. If the field becomes too
strong, there are departures from Ohm’s law in all cases.   
                    </li>
                    <li>
                    Kirchhoff’s junction rule is based on conservation of charge and the
outgoing currents add up and are equal to incoming current at a
junction. Bending or reorienting the wire does not change the validity
of Kirchhoff’s junction rule.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->