 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Laws of Motion</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Laws of Motion</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Laws of Motion</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Aristotle’s view that a force is necessary to keep a body in uniform motion is wrong. A
force is necessary in practice to counter the opposing force of friction.
                    </li>
                    <li>
                    Galileo extrapolated simple observations on motion of bodies on inclined planes, and
arrived at the law of inertia. Newton’s first law of motion is the same law rephrased
thus: “Everybody continues to be in its state of rest or of uniform motion in a straight line,
unless compelled by some external force to act otherwise”. In simple terms, the First Law
is “If external force on a body is zero, its acceleration is zero”.
                    </li>
                    <li>
                    Momentum (p ) of a body is the product of its mass (m) and velocity (v)
                    </li>
                    <li>
                    Newton’s second law of motion :
The rate of change of momentum of a body is proportional to the applied force and takes
place in the direction in which the force acts.
                    </li>
                    <li>
                    Impulse is the product of force and time which equals change in momentum.
The notion of impulse is useful when a large force acts for a short time to produce a
measurable change in momentum. Since the time of action of the force is very short,
one can assume that there is no appreciable change in the position of the body during
the action of the impulsive force.
                    </li>
                    <li>
                    Newton’s third law of motion:
To every action, there is always an equal and opposite reaction
In simple terms, the law can be stated thus :
Forces in nature always occur between pairs of bodies. Force on a body A by body
B is equal and opposite to the force on the body B by A.
Action and reaction forces are simultaneous forces. There is no cause-effect
relation between action and reaction. Any of the two mutual forces can be
called action and the other reaction. Action and reaction act on different
bodies and so they cannot be cancelled out. The internal action and reaction
forces between different parts of a body do, however, sum to zero.
                    </li>
                    <li>
                    Law of Conservation of Momentum
The total momentum of an isolated system of particles is conserved. The law
follows from the second and third law of motion.

                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">1</span>
                            <span class="question">A particle is in a straight line motion with uniform velocity. A force is not required</span>
                            <div class="option"><span class="optionNum">A</span>To increase the speed</div>
                            <div class="option"><span class="optionNum">B</span>To decrease the speed</div>
                            <div class="option"><span class="optionNum">C</span>To maintain the same speed</div>
                            <div class="option"><span class="optionNum">D</span>To change the direction</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">To maintain the same speed</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">2</span>
                            <span class="question">A body of mass 40g is moving with a constant velocity of 2cm/s on a horizontal frictionless table. 
                                The force on the body (in dynes) is
                            </span>
                            <div class="option"><span class="optionNum">A</span>Zero</div>
                            <div class="option"><span class="optionNum">B</span>39200</div>
                            <div class="option"><span class="optionNum">C</span>160</div>
                            <div class="option"><span class="optionNum">D</span>80</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol2')">
                            <div id="textsol2" class="textSolution" style="display:none">Zero</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">3</span>
                            <span class="question">If the force of gravity suddenly disappears</span>
                            <div class="option"><span class="optionNum">A</span>The mass of all bodies will become zero</div>
                            <div class="option"><span class="optionNum">B</span>The weight of all bodies will become zero</div>
                            <div class="option"><span class="optionNum">C</span>Both mass and weight of all bodies will become zero</div>
                            <div class="option"><span class="optionNum">D</span>Neither mass nor weight of all bodies will become zero</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol3')">
                            <div id="textsol3" class="textSolution" style="display:none">The weight of all bodies will become zero</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">4</span>
                            <span class="question">Gravel is dropped onto a conveyer belt at a rate of 0.5kg/s. The extra force required
                                in newton to keep the belt moving at 2m/s is
                            </span>
                            <div class="option"><span class="optionNum">A</span>1 N</div>
                            <div class="option"><span class="optionNum">B</span>2 N</div>
                            <div class="option"><span class="optionNum">C</span>4 N</div>
                            <div class="option"><span class="optionNum">D</span>0.5 N</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol4')">
                            <div id="textsol4" class="textSolution" style="display:none">1 N</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">5</span>
                            <span class="question">When we kick a stone, we get hurt. Due to which of the following properties of stone does it 
                                happens
                            </span>
                            <div class="option"><span class="optionNum">A</span>Inertia</div>
                            <div class="option"><span class="optionNum">B</span>Velocity</div>
                            <div class="option"><span class="optionNum">C</span>Reaction</div>
                            <div class="option"><span class="optionNum">D</span>Momentum</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol5')">
                            <div id="textsol5" class="textSolution" style="display:none">Inertia</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">6</span>
                            <span class="question">Drums of oil are carried in a truck. If the truck accelerates at a constant rate, the surface 
                                of the oil in the drum will
                            </span>
                            <div class="option"><span class="optionNum">A</span>Remain unaffected</div>
                            <div class="option"><span class="optionNum">B</span>Rise in the forward direction</div>
                            <div class="option"><span class="optionNum">C</span>Rise in the backward direction</div>
                            <div class="option"><span class="optionNum">D</span>Nothing in certain</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol6')">
                            <div id="textsol6" class="textSolution" style="display:none">Rise in the backward direction 8</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">7</span>
                            <span class="question">n bullet strike per second elastically on a wall and rebound. What will be the force extend on 
                                the wall by bullets if mass of each bullet is m
                            </span>
                            <div class="option"><span class="optionNum">A</span>mnv</div>
                            <div class="option"><span class="optionNum">B</span>4mnv</div>
                            <div class="option"><span class="optionNum">C</span>2mnv</div>
                            <div class="option"><span class="optionNum">D</span>(mnv)/2</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol7')">
                            <div id="textsol7" class="textSolution" style="display:none">2mnv</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">8</span>
                            <span class="question">A player catches a ball of 200g moving with a  speed of 20m/s. If the time 
                                taken to complete the catch is 0.5s, the force ecerted on the player's hand is
                            </span>
                            <div class="option"><span class="optionNum">A</span>8N</div>
                            <div class="option"><span class="optionNum">B</span>4N</div>
                            <div class="option"><span class="optionNum">C</span>2N</div>
                            <div class="option"><span class="optionNum">D</span>0</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol8')">
                            <div id="textsol8" class="textSolution" style="display:none">These</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">9</span>
                            <span class="question">A sphere of radius 25cm and mass 1lkg is hung by a string of negligible mass and length 40cm, 
                                then tension in the string is
                            </span>
                            <div class="option"><span class="optionNum">A</span>10.81 N</div>
                            <div class="option"><span class="optionNum">B</span>18.4 N</div>
                            <div class="option"><span class="optionNum">C</span>10 N</div>
                            <div class="option"><span class="optionNum">D</span>8 N</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol9')">
                            <div id="textsol9" class="textSolution" style="display:none">These</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">10</span>
                            <span class="question">A retarding force F = -2v is acting on a body of mass 10 gram. Find out time taken for its velocity to 
                                reduce to 37% of its initial value if initial velocity is 1m/s
                            </span>
                            <div class="option"><span class="optionNum">A</span>2.5ms</div>
                            <div class="option"><span class="optionNum">B</span>5ms</div>
                            <div class="option"><span class="optionNum">C</span>7.5ms</div>
                            <div class="option"><span class="optionNum">D</span>8ms</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol10')">
                            <div id="textsol10" class="textSolution" style="display:none">5ms</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">11</span>
                            <span class="question">Water jet is coming out of a hose pipe of diameter 20 cm with speed 20 cm/sec.
                                It strikes a man inelastically. Find the force exerted by water jet on the person
                            </span>
                            <div class="option"><span class="optionNum">A</span>5.04 N</div>
                            <div class="option"><span class="optionNum">B</span>1.26 N</div>
                            <div class="option"><span class="optionNum">C</span>2.52 N</div>
                            <div class="option"><span class="optionNum">D</span>9.4 N</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol11')">
                            <div id="textsol11" class="textSolution" style="display:none">1.26 N</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">12</span>
                            <span class="question">A body of 1000kg is moving with 0.3m/s in +x direction. A hole is present at the bottom of body 
                                such that, mass is dropping at rate of 20 gm/sec, in -y direction. Find out force exerted by ejecting mass on body
                            </span>
                            <div class="option"><span class="optionNum">A</span>0.4 N</div>
                            <div class="option"><span class="optionNum">B</span>0 N</div>
                            <div class="option"><span class="optionNum">C</span>0.6 N</div>
                            <div class="option"><span class="optionNum">D</span>None of these</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol12')">
                            <div id="textsol12" class="textSolution" style="display:none">0 N</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">13</span>
                            <span class="question">A block has been placed on an inclined plane with the slope angle &deg;, 
                                the block slides down the plane at constant speed. The coefficient of kinetic friction is equal to
                            </span>
                            <div class="option"><span class="optionNum">A</span>sin&deg;</div>
                            <div class="option"><span class="optionNum">B</span>cos&deg;</div>
                            <div class="option"><span class="optionNum">C</span>g</div>
                            <div class="option"><span class="optionNum">D</span>tan&deg;</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol13')">
                            <div id="textsol13" class="textSolution" style="display:none">tan&deg;</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">14</span>
                            <span class="question">A string of length L and mass M is lying on a horizontal table. A force F is applied at 
                                one of its ends. Tension in the string at a distance x from the end at which force is applied is
                            </span>
                            <div class="option"><span class="optionNum">A</span>Zero</div>
                            <div class="option"><span class="optionNum">B</span>F</div>
                            <div class="option"><span class="optionNum">C</span>F(L-x)/L</div>
                            <div class="option"><span class="optionNum">D</span>F(L-x)/M</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol14')">
                            <div id="textsol14" class="textSolution" style="display:none">F(L-x)/L</div>
                        </form>
                    </div>
                    <div class="quiz-wrap">
                        <form>
                            <span class="questionNum">15</span>
                            <span class="question">two blocks of masses 2 kg and 1 kg are in contact with each other on a frictionless table. 
                                When a horizontal force of 3.0 N is applied to the block of mass 2 kg the value of the force of contact between the 
                                two blocks is 
                            </span>
                            <div class="option"><span class="optionNum">A</span>4 N</div>
                            <div class="option"><span class="optionNum">B</span>3 N</div>
                            <div class="option"><span class="optionNum">C</span>5 N</div>
                            <div class="option"><span class="optionNum">D</span>1 N</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol15')">
                            <div id="textsol15" class="textSolution" style="display:none">1 N</div>
                        </form>
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->