 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Thermodynamics</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Thermodynamics</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Thermodynamics</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    The zeroth law of thermodynamics states that ‘two systems in thermal equilibrium with a
third system separately are in thermal equilibrium with each other’. The Zeroth Law leads
to the concept of temperature
                    </li>
                    <li>
                    Internal energy of a system is the sum of kinetic energies and potential energies of the
molecular constituents of the system. It does not include the over-all kinetic energy of
the system. Heat and work are two modes of energy transfer to the system. Heat is the
energy transfer arising due to temperature difference between the system and the
surroundings. Work is energy transfer brought about by other means, such as moving
the piston of a cylinder containing the gas, by raising or lowering some weight connected
to it.
                    </li>
                    <li>
                    Equilibrium states of a thermodynamic system are described by state variables. The
value of a state variable depends only on the particular state, not on the path used to
arrive at that state. Examples of state variables are pressure (P ), volume (V ), temperature
(T ), and mass (m ). Heat and work are not state variables. An Equation of State (like
the ideal gas equation PV = µ RT ) is a relation connecting different state variables.
                    </li>
                    <li>
                    A quasi-static process is an infinitely slow process such that the system remains in
thermal and mechanical equilibrium with the surroundings throughout. In a
quasi-static process, the pressure and temperature of the environment can differ from
those of the system only infinitesimally
                    </li>
                    <li>
                    A process is reversible if it can be reversed such that both the system and the surroundings
return to their original states, with no other change anywhere else in the universe.
Spontaneous processes of nature are irreversible. The idealised reversible process is a
quasi-static process with no dissipative factors such as friction, viscosity, etc.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->