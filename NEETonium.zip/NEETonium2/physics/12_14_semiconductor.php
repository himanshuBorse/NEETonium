 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Semiconductor Electronics</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Semiconductor Electronics</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Semiconductor Electronics</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Semiconductors are the basic materials used in the present solid state
electronic devices like diode, transistor, ICs, etc.
                    </li>
                    <li>
                    Lattice structure and the atomic structure of constituent elements
decide whether a particular material will be insulator, metal or
semiconductor
                    </li>
                    <li>
                    Semiconductors are elemental (Si, Ge) as well as compound (GaAs,
CdS, etc.).
                    </li>
                    <li>
                    Pure semiconductors are called ‘intrinsic semiconductors’. The presence
of charge carriers (electrons and holes) is an ‘intrinsic’ property of the
material and these are obtained as a result of thermal excitation. The
number of electrons (ne) is equal to the number of holes (nh) in intrinsic
conductors. Holes are essentially electron vacancies with an effective
positive charge
                    </li>
                    <li>
                    The number of charge carriers can be changed by ‘doping’ of a suitable
impurity in pure semiconductors. Such semiconductors are known as
extrinsic semiconductors. These are of two types (n-type and p-type).
                    </li>
                    <li>
                    For insulators Eg > 3 eV, for semiconductors Eg is 0.2 eV to 3 eV, while for metals Eg ≈ 0.
                    </li>
                    <li>
                    p-n junction is the ‘key’ to all semiconductor devices. When such a
junction is made, a ‘depletion layer’ is formed consisting of immobile
ion-cores devoid of their electrons or holes. This is responsible for a
junction potential barrier.
                    </li>
                    <li>
                    By changing the external applied voltage, junction barriers can be
changed. In forward bias (n-side is connected to negative terminal of the
battery and p-side is connected to the positive), the barrier is decreased
while the barrier increases in reverse bias. Hence, forward bias current
is more (mA) while it is very small (µA) in a p-n junction diode
                    </li>
                    <li>
                    Diodes can be used for rectifying an ac voltage (restricting the ac voltage
to one direction). With the help of a capacitor or a suitable filter, a dc
voltage can be obtained.
                    </li>
                    <li>
                    There are some special purpose diodes
                    </li>
                    <li>
                    Zener diode is one such special purpose diode. In reverse bias, after a
certain voltage, the current suddenly increases (breakdown voltage) in
a Zener diode. This property has been used to obtain voltage regulation.
                    </li>
                    <li>
                    p-n junctions have also been used to obtain many photonic or
optoelectronic devices where one of the participating entity is ‘photon’:
(a) Photodiodes in which photon excitation results in a change of reverse
saturation current which helps us to measure light intensity; (b) Solar
cells which convert photon energy into electricity; (c) Light Emitting
Diode and Diode Laser in which electron excitation by a bias voltage
results in the generation of light
                    </li>
                    <li>
                    There are some special circuits which handle the digital data consisting
of 0 and 1 levels. This forms the subject of Digital Electronics.
                    </li>
                    <li>
                    The important digital circuits performing special logic operations are
called logic gates. These are: OR, AND, NOT, NAND, and NOR gates.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->