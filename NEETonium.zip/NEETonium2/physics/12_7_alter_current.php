 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Alternating Current</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Alternating Current</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Alternating Current</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    The power rating of an element used in ac circuits refers to its average
power rating
                    </li>
                    <li>
                    The power consumed in an ac circuit is never negative.
                    </li>
                    <li>
                    Both alternating current and direct current are measured in amperes.
But how is the ampere defined for an alternating current? It cannot be
derived from the mutual attraction of two parallel wires carrying ac
currents, as the dc ampere is derived. An ac current changes direction
with the source frequency and the attractive force would average to
zero. Thus, the ac ampere must be defined in terms of some property
that is independent of the direction of the current. Joule heating
is such a property, and there is one ampere of rms value of
alternating current in a circuit if the current produces the same
average heating effect as one ampere of dc current would produce
under the same conditions.
                    </li>
                    <li>
                    Though in a phasor diagram, voltage and current are represented by
vectors, these quantities are not really vectors themselves. They are
scalar quantities. It so happens that the amplitudes and phases of
harmonically varying scalars combine mathematically in the same
way as do the projections of rotating vectors of corresponding
magnitudes and directions. The ‘rotating vectors’ that represent
harmonically varying scalar quantities are introduced only to provide
us with a simple way of adding these quantities using a rule that
we already know as the law of vector addition.
                    </li>
                    <li>
                    There are no power losses associated with pure capacitances and pure
inductances in an ac circuit. The only element that dissipates energy
in an ac circuit is the resistive element.
                    </li>
                    <li>
                    The power factor in a RLC circuit is a measure of how close the
circuit is to expending the maximum power.
                    </li>
                    <li>
                    In generators and motors, the roles of input and output are
reversed. In a motor, electric energy is the input and mechanical
energy is the output. In a generator, mechanical energy is the
input and electric energy is the output. Both devices simply
transform energy from one form to another.
                    </li>
                    <li>
                    A transformer (step-up) changes a low-voltage into a high-voltage.
This does not violate the law of conservation of energy. The
current is reduced by the same proportion.
                    </li>
                    <li>
                    The choice of whether the description of an oscillatory motion is
by means of sines or cosines or by their linear combinations is
unimportant, since changing the zero-time position transforms
the one to the other.
                    </li>
                    <li>
                    In a purely inductive or capacitive circuit, cosφ = 0 and no power is
dissipated even though a current is flowing in the circuit. In such cases,
current is referred to as a wattless current.
                    </li>
                    <li>
                    The phase relationship between current and voltage in an ac circuit
can be shown conveniently by representing voltage and current by
rotating vectors called phasors. A phasor is a vector which rotates
about the origin with angular speed ω. The magnitude of a phasor
represents the amplitude or peak value of the quantity (voltage or
current) represented by the phasor.
The analysis of an ac circuit is facilitated by the use of a phasor
diagram.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->