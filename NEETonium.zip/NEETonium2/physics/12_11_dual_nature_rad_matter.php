 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Dual Nature of Radiation and Matter</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Dual Nature of Radiation and Matter</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Dual Nature of Radiation and Matter</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    The minimum energy needed by an electron to come out from a metal
surface is called the work function of the metal. Energy (greater than
the work function (φο) required for electron emission from the metal
surface can be supplied by suitably heating or applying strong electric
field or irradiating it by light of suitable frequency
                    </li>
                    <li>
                    Photoelectric effect is the phenomenon of emission of electrons by metals
when illuminated by light of suitable frequency. Certain metals respond
to ultraviolet light while others are sensitive even to the visible light.
Photoelectric effect involves conversion of light energy into electrical
energy. It follows the law of conservation of energy. The photoelectric
emission is an instantaneous process and possesses certain special
features.
                    </li>
                    <li>
                    Photoelectric current depends on (i) the intensity of incident light, (ii)
the potential difference applied between the two electrodes, and (iii)
the nature of the emitter material.
                    </li>
                    <li>
                    Below a certain frequency (threshold frequency) ν 0, characteristic of
the metal, no photoelectric emission takes place, no matter how large
the intensity may be.
                    </li>
                    <li>
                    Radiation has dual nature: wave and particle. The nature of experiment
determines whether a wave or particle description is best suited for
understanding the experimental result. Reasoning that radiation and
matter should be symmetrical in nature, Louis Victor de Broglie
attributed a wave-like character to matter (material particles). The waves
associated with the moving material particles are called matter waves
or de Broglie waves.
                    </li>
                    <li>
                    The de Broglie wavelength (λ) associated with a moving particle is related
to its momentum p as: λ = h/p. The dualism of matter is inherent in the
de Broglie relation which contains a wave concept (λ) and a particle concept
(p). The de Broglie wavelength is independent of the charge and nature of
the material particle. It is significantly measurable (of the order of the
atomic-planes spacing in crystals) only in case of sub-atomic particles
like electrons, protons, etc. (due to smallness of their masses and hence,
momenta). However, it is indeed very small, quite beyond measurement,
in case of macroscopic objects, commonly encountered in everyday life.
                    </li>
                    <li>
                    Electron diffraction experiments by Davisson and Germer, and by G. P.
Thomson, as well as many later experiments, have verified and confirmed
the wave-nature of electrons. The de Broglie hypothesis of matter waves
supports the Bohr ’s concept of stationary orbits.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->