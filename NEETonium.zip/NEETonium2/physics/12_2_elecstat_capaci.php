 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Electrostatic Potential and Capacitance</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Electrostatic Potential and Capacitance</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Electrostatic Potential and Capacitance</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Electrostatic force is a conservative force. Work done by an external
force (equal and opposite to the electrostatic force) in bringing a charge
q from a point R to a point P is q(VP–VR), which is the difference in
potential energy of charge q between the final and initial points.
                    </li>
                    <li>
                    An equipotential surface is a surface over which potential has a constant
value. For a point charge, concentric spheres centred at a location of the
charge are equipotential surfaces. The electric field E at a point is
perpendicular to the equipotential surface through the point. E is in the
direction of the steepest decrease of potential.
                    </li>
                    <li>
                    The potential energy of a charge q in an external potential V(r) is qV(r).
The potential energy of a dipole moment p in a uniform electric field E is
–p.E.
                    </li>
                    <li>
                    Electrostatics deals with forces between charges at rest. But if there is a
force on a charge, how can it be at rest? Thus, when we are talking of
electrostatic force between charges, it should be understood that each
charge is being kept at rest by some unspecified force that opposes the
net Coulomb force on the charge
                    </li>
                    <li>
                    A capacitor is so configured that it confines the electric field lines within
a small region of space. Thus, even though field may have considerable
strength, the potential difference between the two conductors of a
capacitor is small.
                    </li>
                    <li>
                    The torque p × E on a dipole causes it to oscillate about E. Only if there
is a dissipative mechanism, the oscillations are damped and the dipole
eventually aligns with E.
                    </li>
                    <li>
                    Potential due to a charge q at its own location is not defined – it is
infinite.
                    </li>
                    <li>
                    In the expression qV(r) for potential energy of a charge q, V(r) is the
potential due to external charges and not the potential due to q. As seen
in point 5, this expression will be ill-defined if V (r) includes potential
due to a charge q itself.
                    </li>
                    <li>
                    A cavity inside a conductor is shielded from outside electrical influences.
It is worth noting that electrostatic shielding does not work the other
way round; that is, if you put charges inside the cavity, the exterior of
the conductor is not shielded from the fields by the inside charges.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->