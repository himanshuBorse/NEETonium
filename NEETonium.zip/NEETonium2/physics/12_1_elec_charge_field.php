 <!--Start header -->
 <?php
    include "../resources/header.php";
?>
<!-- End Header -->

 <!-- start include script for pagination -->
<script src="../assets/js/jquery-3.6.0.min.js"></script>
<script src="../assets/js/pagination.js"></script>
<!-- End include script for pagination -->

<!-- start include see more for summary script -->
<script src="../assets/js/seeMore.js"></script>
<!-- End include see more for summary script -->

<!-- Start head content of page -->
<div class="page-hero-section bg-image hero-mini" style="background-image: url(../assets/img/hero_mini.svg);">
    <div class="hero-caption">
        <div class="container fg-white h-100">
            <div class="row justify-content-center align-items-center text-center h-100">
                <div class="col-lg-6">
                    <h3 class="mb-4 fw-medium">Electric Charges and Fields</h3>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb breadcrumb-dark justify-content-center bg-transparent">
                            <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                            <li class="breadcrumb-item"><a href="../index.php">MCQs</a></li>
                            <li class="breadcrumb-item"><a href="../subjects/physics.php">Physics</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Electric Charges and Fields</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End head content of page -->

<div class="page-section">
    <div class="container">
<!-- Start summary of the chapter -->
        <div class="widget-wrap">
        <h3 class="widget-title">Electric Charges and Fields</h3>
            <p class="chapSummary">
                <ul>
                    <li>
                    Electric and magnetic forces determine the properties of atoms,
molecules and bulk matter.
                    </li>
                    <li>
                    From simple experiments on frictional electricity, one can infer that
there are two types of charges in nature; and that like charges repel
and unlike charges attract. By convention, the charge on a glass rod
rubbed with silk is positive; that on a plastic rod rubbed with fur is
then negative.
                    </li>
                    <li>
                    Conductors allow movement of electric charge through them, insulators
do not. In metals, the mobile charges are electrons; in electrolytes
both positive and negative ions are mobile.
                    </li>
                    <li>
                    Coulomb’s Law: The mutual electrostatic force between two point
charges q1 and q2 is proportional to the product q1q2 and inversely
proportional to the square of the distance r21 separating them.
                    </li>
                    <li>
                    Superposition Principle: The principle is based on the property that the
forces with which two charges attract or repel each other are not
affected by the presence of a third (or more) additional charge(s). For
an assembly of charges q1, q2, q3, ..., the force on any charge, say q1, is
the vector sum of the force on q1 due to q2, the force on q1 due to q3,
and so on. For each pair, the force is given by the Coulomb’s law for
two charges stated earlier.
                    </li>
                    <li>
                    The electric field E at a point due to a charge configuration is the
force on a small positive test charge q placed at the point divided by
the magnitude of the charge. Electric field due to a point charge q has
a magnitude |q|/4πε0r2; it is radially outwards from q, if q is positive,
and radially inwards if q is negative. Like Coulomb force, electric field
also satisfies superposition principle.
                    </li>
                    <li>
                    An electric field line is a curve drawn in such a way that the tangent
at each point on the curve gives the direction of electric field at that
point. The relative closeness of field lines indicates the relative strength
of electric field at different points; they crowd near each other in regions
of strong electric field and are far apart where the electric field is
weak. In regions of constant electric field, the field lines are uniformly
spaced parallel straight lines.
                    </li>
                    <li>
                    Some of the important properties of field lines are: (i) Field lines are
continuous curves without any breaks. (ii) Two field lines cannot cross
each other. (iii) Electrostatic field lines start at positive charges and
end at negative charges —they cannot form closed loops.
                    </li>
                    <li>
                    An electric dipole is a pair of equal and opposite charges q and –q
separated by some distance 2a. Its dipole moment vector p has
magnitude 2qa and is in the direction of the dipole axis from –q to q.
                    </li>
                </ul>
            </p>
        </div>
<!-- End summary of the chapter -->
        <div class="row">
            <div class="col-lg-8 py-3">
<!-- Start question list -->
                <div class="ques-content" style="display: none">
                    <div class="quiz-wrap">
                    <div class="option"><span class="icon mr-1"><span class="mai-globe"></span> Questions will be added shortly.</div>
                        <!-- <form>
                            <span class="questionNum">1</span>
                            <span class="question">What</span>
                            <div class="option"><span class="optionNum">A</span>These</div>
                            <div class="option"><span class="optionNum">B</span>These</div>
                            <div class="option"><span class="optionNum">C</span>They</div>
                            <div class="option"><span class="optionNum">D</span>They</div>
                            <input type="button" class="solutionBtn rounded-pill" value="solution" onclick="func('textsol1')">
                            <div id="textsol1" class="textSolution" style="display:none">These</div>

                        </form> -->
                    </div>
                </div>
<!-- End question list -->
<!-- Start include paging number code -->
                        <?php
                            include "../pagination/customPageList.php";
                        ?>
<!-- End include paging number code -->
            </div>

<!-- start include sidebar -->
            <?php
            include "../sidebar/physicsSidebar.php";
            ?>
<!-- End include sidebar -->
        </div>
    </div>
</div>
<!-- start include solution script -->
<script src="../assets/js/solutionScript.js"></script>
<!-- end include solution script -->

<!-- start include footer  -->
<?php
include "../resources/footer.php";
?>
<!-- end include footer -->