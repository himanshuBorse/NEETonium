<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta property="name" content="NEETonium: Free NEET preparation platform">
    <meta property="description" content="The website for the NEET competitive exam preparation">

    <title>NEETonium - NEET exam MCQs preparation</title>

    <link rel="shortcut icon" href="./assets/shortcutIcon.png" type="image/x-icon">

    <link rel="stylesheet" href="./assets/css/maicons.css">

    <link rel="stylesheet" href="./assets/vendor/animate/animate.css">

    <link rel="stylesheet" href="./assets/vendor/owl-carousel/css/owl.carousel.min.css">

    <link rel="stylesheet" href="./assets/css/bootstrap.css">

    <link rel="stylesheet" href="./assets/css/neetonium.css">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light navbar-floating">
        <div class="container">

            <!-- <img src="../assets/favicon-light.png" alt="" width="40"> -->
            <div class="logo-holder logo">
                <a class="navbar-brand" href="./index.php">
                    <h4>NEETonium</h4>
                    <p>The best is yet to come</p>
            </div>

            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggler" aria-controls="navbarToggler" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarToggler">
                <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
                    <li class="nav-item active">
                        <a class="nav-link" href="../index.php">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Subjects</a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="./subjects/physics.php">Physics</a>
                            <a class="dropdown-item" href="./subjects/chemistry.php">Chemistry</a>
                            <a class="dropdown-item" href="./subjects/biology.php">Biology</a>
                        </div>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="./aboutUs/aboutUs.php">About</a>
                    </li>

                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="updates.html">What's New</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="./aboutUs/contact.php">Contact</a>
                    </li>
                </ul>
                <div class="ml-auto my-2 my-lg-0">
                    <a  class="btn btn-primary rounded-pill" href="#page-section">Get Started</a>
                    <!-- <button class="btn btn-primary rounded-pill" onClick="#page-section">Get Started</button> -->
                </div>
            </div>
        </div>
    </nav>

    <main class="bg-light">

        <div class="page-hero-section bg-image hero-home-1" style="background-image: url(./assets/img/bg_hero_1.svg);">
            <div class="hero-caption pt-5">
                <div class="container h-100">
                    <div class="row align-items-center h-100">
                        <div class="col-lg-6 wow fadeInUp">
                            <div class="badge mb-2"><span class="icon mr-1"><span class="mai-globe"></span></span>The Website to friendly and efficient preparation for NEET
                         </div>
                            <h1 class="mb-4"> NEETonium </h1>
                            <p class="mb-4">Practice salient MCQs for the superior preparation</p>
                            <a href="#" class="btn btn-primary rounded-pill">ALL THE BEST </a>
                        </div>
                        <div class="col-lg-6 d-none d-lg-block wow zoomIn">
                            <div class="img-place mobile-preview shadow floating-animate">
                                <p class="font-weight-bold">The <span class="logo-text">NEETonium</span> is the best know  website for the neet examination prepartion.
                             The website won't charge you, So start your preparation with us at the moment. </p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>




        <div class="page-section bg-image" id="page-section" style="background-image: url(./assets/img/pattern_2.svg);">
            <div class="container">
                <div class="row justify-content-center align-items-center">

                    <div class="pricing-table">
                         <div class="pricing-item active wow zoomIn " data-wow-delay="200ms">
                            <div class="pricing-header">
                                <h5>Physics</h5>
                                <h1 class="fw-normal"></h1>
                            </div>
                            <div class="pricing-body">
                                <ul class="theme-list">
                                    <li class="list-item">Chapter Summary</li>
                                    <li class="list-item">Top 15 Selected Questions</li>
                                    <li class="list-item">Basic Questions</li>
                                    <li class="list-item">Advance Questions</li>
                                    <li class="list-item">Added Previous Year Questions</li>
                                    <li class="list-item">No Added Solution</li>
                                    
                                </ul>
                            </div>
                                <button class="btn btn-dark"  onClick="location.href='./subjects/physics.php'">Start Preparing</button> 
                        </div>

                        <div class="pricing-item active wow zoomIn" data-wow-delay="200ms">
                            <div class="pricing-header">
                                <h5>Biology</h5>
                                <h1 class="fw-normal"></h1>
                            </div>
                            <div class="pricing-body">
                                <ul class="theme-list">
                                    <li class="list-item">Chapter Summary</li>
                                    <li class="list-item">Top 15 Selected Questions</li>
                                    <li class="list-item">Basic Questions</li>
                                    <li class="list-item">Advance Questions</li>
                                    <li class="list-item">Added Previous Year Questions</li>
                                    <li class="list-item">No Added Solution</li>
                                </ul>
                            </div>
                            <button class="btn btn-dark" onClick="location.href='./subjects/biology.php'">Start Preparing</button>
                        </div>

                        <div class="pricing-item active wow zoomIn  " data-wow-delay="200ms">
                            <div class="pricing-header">
                                <h5>Chemistry</h5>
                                <h1 class="fw-normal"></h1>
                            </div>
                            <div cclass="pricing-body">
                                <div class="pricing-body">
                                    <ul class="theme-list">
                                        <li class="list-item">Chapter Summary</li>
                                        <li class="list-item">Top 15 Selected Questions</li>
                                        <li class="list-item">Basic Questions</li>
                                        <li class="list-item">Advance Questions</li>
                                        <li class="list-item">Added Previous Year Questions</li>
                                        <li class="list-item">No Added Solution</li>
                                    </ul>
                                </div>
                            </div>
                            <button class="btn btn-dark" onClick="location.href='./subjects/chemistry.php'">Start Preparing</button>
                        </div>
                    </div>

                </div>
            </div>
        </div>



        <div class="page-section bg-dark fg-white">
            <div class="container">
                <h1 class="text-center">Why Prepare With Neetonium</h1>

                <div class="row justify-content-center mt-5">
                    <div class="col-md-6 col-lg-3 py-3">
                        <div class="card card-body border-0 bg-transparent text-center wow zoomIn">
                            <div class="mb-3">
                                <img src="./assets/img/icons/rocket.svg" alt="">
                            </div>
                            <p class="fs-large">Very Efficient</p>
                            <p class="fs-small fg-grey">Chapter wise summary is available with appropriate context.</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3 py-3">
                        <div class="card card-body border-0 bg-transparent text-center wow zoomIn" data-wow-delay="200ms">
                            <div class="mb-3">
                                <img src="./assets/img/icons/testimony.svg" alt="">
                            </div>
                            <p class="fs-large">Mentors Availability</p>
                            <p class="fs-small fg-grey">Within fewer new versions the Mentors will be available over the website.</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3 py-3">
                        <div class="card card-body border-0 bg-transparent text-center wow zoomIn" data-wow-delay="400ms">
                            <div class="mb-3">
                                <img src="./assets/img/icons/promotion.svg" alt="">
                            </div>
                            <p class="fs-large">Updates</p>
                            <p class="fs-small fg-grey">Updates regarding NEET will be provided time to time.</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3 py-3">
                        <div class="card card-body border-0 bg-transparent text-center wow zoomIn" data-wow-delay="600ms">
                            <div class="mb-3">
                                <img src="./assets/img/icons/coins.svg" alt="">
                            </div>
                            <p class="fs-large">No Charges</p>
                            <p class="fs-small fg-grey">NEETonium is freely accessible</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3 py-3">
                        <div class="card card-body border-0 bg-transparent text-center wow zoomIn" data-wow-delay="800ms">
                            <div class="mb-3">
                                <img src="./assets/img/icons/support.svg" alt="">
                            </div>
                            <p class="fs-large">24/7 Support</p>
                            <p class="fs-small fg-grey">To contact us you can mail of DM us.</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3 py-3">
                        <div class="card card-body border-0 bg-transparent text-center wow zoomIn" data-wow-delay="1000ms">
                            <div class="mb-3">
                                <img src="./assets/img/icons/laptop.svg" alt="Laptop icon">
                            </div>
                            <p class="fs-large">Full Features</p>
                            <p class="fs-small fg-grey">We Promise to give new features by upgrading website version by version</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="position-realive bg-image" style="background-image: url(./assets/img/pattern_1.svg);">

            <div class="page-section">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5 py-3">
                            <!-- <div class="img-place mobile-preview shadow wow zoomIn">
                                <ul class="theme-list">
                                    <li class="list-item">Chapter W ise </li>
                                    <li class="list-item">Top 100 Selected Questions</li>
                                    <li class="list-item">Basic Question</li>
                                    <li class="list-item">Advance Question</li>
                                    
                                </ul>
                            </div>  -->
                        </div>
                        <div class="col-lg-6 py-3 mt-lg-5">
                            <div class="iconic-list">
                                <div class="iconic-item wow fadeInUp">
                                    <div class="iconic-md iconic-text bg-warning fg-white rounded-circle">
                                        <span class="mai-cube"></span>
                                    </div>
                                    <div class="iconic-content">
                                        <h5>Verified Question</h5>
                                        <p class="fs-small">All the question are verified by our expert team. These question are randomly arranged with basic 
                                            and advance concepts </p>
                                    </div>
                                </div>
                                <div class="iconic-item wow fadeInUp">
                                    <div class="iconic-md iconic-text bg-info fg-white rounded-circle">
                                        <span class="mai-shield"></span>
                                    </div>
                                    <div class="iconic-content">
                                        <h5>No Intergrated Solutions</h5>
                                        <p class="fs-small">The solutions for the question are not included. Try your best to solve them, After that mail us for the solutions.</p>
                                    </div>
                                </div>
                                <div class="iconic-item wow fadeInUp">
                                    <div class="iconic-md iconic-text bg-indigo fg-white rounded-circle">
                                        <span class="mai-desktop-outline"></span>
                                    </div>
                                    <div class="iconic-content">
                                        <h5>Easy Monitoring</h5>
                                        <p class="fs-small">The questions have four option and the best one suitable answer is added in the soluton</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
<div class="page-footer-section bg-dark fg-white">
  <div class="container">
    <div class="row mb-5 py-3">
      <div class="col-sm-6 col-lg-2 py-3">
        <h5 class="mb-3">Pages</h5>
        <ul class="menu-link">
          <li><a href="./subjects/physics.php" class="">Physics</a></li>
          <li><a href="./subjects/chemistry.php" class="">Chemsitry</a></li>
          <li><a href="./subjects/biology.php" class="">Biology</a></li>
          <li><a href="./aboutUs/aboutUs.php" class="">About</a></li>
          <li><a href="./aboutUs/whatsNew.php" class="">what's New</a></li>
          
        </ul>
      </div>
      <!-- <div class="col-sm-6 col-lg-2 py-3">
        <h5 class="mb-3">Company</h5>
        <ul class="menu-link">
          <li><a href="#" class="">About</a></li>
          <li><a href="#" class="">Team</a></li>
          <li><a href="#" class="">Leadership</a></li>
          <li><a href="#" class="">Careers</a></li>
          <li><a href="#" class="">HIRING!</a></li>
        </ul>
      </div> -->
      <div class="col-md-6 col-lg-4 py-3">
        <h5 class="mb-3">Contact</h5>
        <ul class="menu-link">
          <li><a href="./aboutUs/contact.php" class="">Contact Us</a></li>
          <!-- <li><a href="https://mail.google.com/mail/u/neetonium@email.com/#inbox?compose=new" class="">neetonium@gmail.com</a></li> -->
          <li><a href="mailto:neetonium@gmail.com" target="_newtab"  class="">neetonium@gmail.com</a></li>
          <li><a href="tel:9924133876" class="mobilesOnly">+91 9924133876</a></li>
        </ul>
      </div>
      <div class="col-md-6 col-lg-4 py-3">
        <h5 class="mb-3">Subscribe</h5>
        <p>Get some offers, news, or update features of application</p>
        <!-- <form method="POST">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Your email..">
            <div class="input-group-append">
              <button type="submit" class="btn btn-primary"><span class="mai-send"></span></button>
            </div>
          </div>
        </form> -->

        <!-- Social Media Button -->
        <div class="mt-4">
          <!-- <a href="#" class="btn btn-fab btn-primary fg-white"><span class="mai-logo-facebook"></span></a>
          <a href="#" class="btn btn-fab btn-primary fg-white"><span class="mai-logo-twitter"></span></a> -->
          <a href="https://www.instagram.com/neetonium/" target="_newtab" class="btn btn-fab btn-primary fg-white"><span class="mai-logo-instagram"></span></a>
          <a href="mailto:neetonium@gmail.com" target="_newtab"  class="btn btn-fab btn-primary fg-white"><span class="mai-logo-google"></span></a>
        </div>
      </div>
    </div>
  </div>

  <hr>

  <div class="container">
    <div class="row">
      <div class="col-12 col-md-6 py-2">
        <img src="./assets/img/favicon-light.png" alt="" width="40"> 
        <!-- Please don't remove or modify the credits below -->
        <p class="d-inline-block ml-2">Copyright &copy; <a href="https://www.neetonium.com/" class="fg-white fw-medium">MACode ID</a>. All rights reserved</p>
      </div>
      <div class="col-12 col-md-6 py-2">
        <ul class="nav justify-content-end">
          <li class="nav-item"><a href="#" class="nav-link">Terms of Use</a></li>
          <li class="nav-item"><a href="#" class="nav-link">Privacy Policy</a></li>
          <li class="nav-item"><a href="#" class="nav-link">Cookie Policy</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

<script src="./assets/js/jquery-3.5.1.min.js"></script>

<script src="./assets/js/bootstrap.bundle.min.js"></script>

<script src="./assets/vendor/owl-carousel/js/owl.carousel.min.js"></script>

<script src="./assets/vendor/wow/wow.min.js"></script>

<script src="./assets/js/neetonium.js"></script>

</body>
</html>
