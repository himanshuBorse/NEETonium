 
    <!-- Sidebar -->
    <div class="col-lg-4 py-3">
        <div class="widget-wrap">
            <form action="#" class="search-form">
            <h3 class="widget-title">Search</h3>
            <!-- <script async src="https://cse.google.com/cse.js?cx=daa0ebb3e2184efe9"></script> -->
            <div class="gcse-search"></div>
                <!-- <h3 class="widget-title">Search</h3>
                <div class="form-group">
                    <span class="icon mai-search"></span>
                    <input type="text" class="form-control" placeholder="Type a keyword and hit enter">
                </div> -->
            </form>
        

        <div class="widget-wrap">
            <h3 class="widget-title">Subjects</h3>
            <ul class="categories">
                <li><a href="../subjects/physics.php">Physics</a></li>
                <li><a href="../subjects/chemistry.php">Chemistry </a></li>
                <li><a href="../subjects/biology.php">Biology </a></li>
            </ul>
        </div>

        <div class="widget-wrap">
            <h3 class="widget-title">Chapters</h3>
            <div class="tag-clouds">
                <h4>11<sup>th</sup></h4>
              <a href="../chemistry/11_1_basic_chem.php" class="tag-cloud-link">Some Basic Concepts of Chemistry</a>
              <a href="../chemistry/11_2_struc_atom.php" class="tag-cloud-link">Structure Of The Atom</a>
              <a href="../chemistry/11_3_class_elem_prop.php" class="tag-cloud-link">Classification of Elements and Periodicity in Properties</a>
              <a href="../chemistry/11_4_chem_bond_mole.php" class="tag-cloud-link">Chemical Bonding and Molecular Structure</a>
              <a href="../chemistry/11_5_state_matter.php" class="tag-cloud-link">States of Matter</a>
              <a href="../chemistry/11_6_thermodynamics.php" class="tag-cloud-link">Thermodynamics</a>
              <a href="../chemistry/11_7_equilibrium.php" class="tag-cloud-link">Equilibrium</a>
              <a href="../chemistry/11_8_redox_rec.php" class="tag-cloud-link">Redox Reactions</a>
              <a href="../chemistry/11_9_hydrogen.php" class="tag-cloud-link">Hydrogen</a>
              <a href="../chemistry/11_10_s_block.php" class="tag-cloud-link">The s-Block Elements</a>
              <a href="../chemistry/11_11_p_block.php" class="tag-cloud-link">The p-Block Elements</a>
              <a href="../chemistry/11_12_org_chem.php" class="tag-cloud-link">Organic Chemistry: Some Basic Principles and Techniques</a>
              <a href="../chemistry/11_13_hydrocarbon.php" class="tag-cloud-link">Hydrocarbons</a>
              <a href="../chemistry/11_14_environ_chem.php" class="tag-cloud-link">Environmental Chemistry</a>
              

              <h4>12<sup>th</sup></h4>
              <a href="../chemistry/12_1_solid_state.php" class="tag-cloud-link">The Solid State</a>
              <a href="../chemistry/12_2_solutions.php" class="tag-cloud-link">Solutions</a>
              <a href="../chemistry/12_3_electrochemistry.php" class="tag-cloud-link">Electrochemistry</a>
              <a href="../chemistry/12_4_chem_kinec.php" class="tag-cloud-link">Chemical Kinetics</a>
              <a href="../chemistry/12_5_surface_chem.php" class="tag-cloud-link">Surface Chemistry</a>
              <a href="../chemistry/12_6_gen_prin_elem.php" class="tag-cloud-link">General Principles and Processes of Isolation of Elements</a>
              <a href="../chemistry/12_7_p_block.php" class="tag-cloud-link">The p-Block Elements</a>
              <a href="../chemistry/12_8_d_f_block.php" class="tag-cloud-link">The d- and f-Block Elements</a>
              <a href="../chemistry/12_9_coord_compound.php" class="tag-cloud-link">Coordination Compounds</a>
              <a href="../chemistry/12_10_haloalkane_arenes.php" class="tag-cloud-link">Haloalkanes and Haloarenes</a>
              <a href="../chemistry/12_11_alco_pheno_ether.php" class="tag-cloud-link">Alcohols, Phenols and Ethers</a>
              <a href="../chemistry/12_12_ald_keto_carbo.php" class="tag-cloud-link">Aldehydes, Ketones and Carboxylic Acids</a>
              <a href="../chemistry/12_13_amines.php" class="tag-cloud-link">Amines</a>
              <a href="../chemistry/12_14_biomolecules.php" class="tag-cloud-link">Biomolecules</a>
              <a href="../chemistry/12_15_polymers.php" class="tag-cloud-link">Polymers</a>
              <a href="../chemistry/12_16_chem_life.php" class="tag-cloud-link">Chemistry in Everyday Life</a>
                           
              

            </div>
            
        </div>
</div>
</div>