<!--Start Header-->
<?php
        include "./resources/mainInclude/header.php";
    ?>
<!--End header-->





<div class="container text-center">
<h1 class="bg-warning text-center" style="padding: 15px;">Chapters</h1>
    <div class="row mt-5 justify-content-center">
         
        <div class="card card-custom mx-2 mb-3">
            <a href="./quiz/quiz.php?q=PHYSICAL WORLD" class="tm-nav-link">
            <span class="tm-mb-1 text-center">01</span> <span>PHYSICAL WORLD</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
            <a href="./quiz/quiz.php?q=UNITS AND MEASUREMENTS" class="tm-nav-link">
            <span class="tm-mb-1 text-center">02</span> <span>UNITS AND MEASUREMENTS</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=MOTION IN A STRAIGHT LINE" class="tm-nav-link">
        <span class="tm-mb-1  text-center">03</span> <span>MOTION IN A STRAIGHT LINE</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=MOTION IN A PLANE" class="tm-nav-link">
        <span class="tm-mb-1 text-center">04</span> <span>MOTION IN A PLANE</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=LAWS OF MOTION" class="tm-nav-link">
        <span class="tm-mb-1 text-center">05</span> <span>LAWS OF MOTION</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=WORK, ENERGY AND POWER" class="tm-nav-link">
        <span class="tm-mb-1 text-center">06</span> <span>WORK, ENERGY AND POWER</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=SYSTEM OF PARTICLES AND ROTATIONAL MOTION" class="tm-nav-link">
        <span class="tm-mb-1 text-center">07</span> <span>SYSTEM OF PARTICLES AND ROTATIONAL MOTION</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=GRAVITATION" class="tm-nav-link">
        <span class="tm-mb-1 text-center">08</span> <span>GRAVITATION</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=MECHANICAL PROPERTIES OF SOLIDS" class="tm-nav-link">
        <span class="tm-mb-1  text-center">09</span> <span>MECHANICAL PROPERTIES OF SOLIDS</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=MECHANICAL PROPERTIES OF FLUIDS" class="tm-nav-link">
        <span class="tm-mb-1 text-center">10</span> <span>MECHANICAL PROPERTIES OF FLUIDS</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=THERMAL PROPERTIES OF MATTER" class="tm-nav-link">
        <span class="tm-mb-1 text-center">11</span> <span>THERMAL PROPERTIES OF MATTER</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=THERMODYNAMICS" class="tm-nav-link">
        <span class="tm-mb-1 text-center">12</span> <span>THERMODYNAMICS</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=KINETIC THEORY" class="tm-nav-link">
        <span class="tm-mb-1 text-center">13</span> <span>KINETIC THEORY</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3 text-center">
        <a href="./quiz/quiz.php?q=OSCILLATIONS" class="tm-nav-link">
        <span class="tm-mb-1">14</span> <span>OSCILLATIONS</span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=WAVES" class="tm-nav-link">
        <span class="tm-mb-1">15</span> <span>WAVES </span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=WAVES" class="tm-nav-link">
        <span class="tm-mb-1">15</span> <span>WAVES </span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=WAVES" class="tm-nav-link">
        <span class="tm-mb-1">15</span> <span>WAVES </span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=WAVES" class="tm-nav-link">
        <span class="tm-mb-1">15</span> <span>WAVES </span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=WAVES" class="tm-nav-link">
        <span class="tm-mb-1">15</span> <span>WAVES </span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=WAVES" class="tm-nav-link">
        <span class="tm-mb-1">15</span> <span>WAVES </span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=WAVES" class="tm-nav-link">
        <span class="tm-mb-1">15</span> <span>WAVES </span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=WAVES" class="tm-nav-link">
        <span class="tm-mb-1">15</span> <span>WAVES </span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=WAVES" class="tm-nav-link">
        <span class="tm-mb-1">15</span> <span>WAVES </span></a>
        </div>
        <div class="card card-custom mx-2 mb-3">
        <a href="./quiz/quiz.php?q=WAVES" class="tm-nav-link">
        <span class="tm-mb-1">15</span> <span>WAVES </span></a>
        </div>
        
       
    </div>
</div>


<!--Start Footer-->
<?php
        include "./resources/mainInclude/footer.php";
    ?>
<!--Start Footer-->
