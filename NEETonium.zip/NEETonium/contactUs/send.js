$(document).ready(function(){
    const send_btn = document.querySelector("#sendmail");
    send_btn.onclick = () => {
      var name = $("#name").val();
      var email = $("#email").val();
      var subject = $("#subject").val();
      var message = $("#message").val();
     
      
      //checking contact us  form field on submission  
      /*if(name.trim() == ""){
        
          $("#status1").html(statusmsg);
          $("#name").focus();
         }
         else{
            $("#status1").remove(statusmsg);
         }
         if(email.trim() == ""){
            $("#status2").html(statusmsg);
            $("#email").focus();
           }
           else{
            $("#status2").remove(statusmsg);
         }
           if(subject.trim() == ""){
            $("#status3").html("<small style= 'color: red;'>All Fields are Mandotory!</small>");
            $("#subject").focus();
           }
           else{
            $("#status3").remove(statusmsg);
         }
           if(message.trim() == ""){
            $("#status4").html("<small style= 'color: red;'>All Fields are Mandotory!</small>");
            $("#message").focus();
           }
           else{
            $("#status4").remove(stSatusmsg);
         }*/

         if(name.trim() == "" || email.trim() == "" || subject.trim() == "" || message.trim() == ""){
            $("#status1").html("<small style= 'color: red;'>All Fields are Mandotory!</small>");  
            return false;
        }
        else{
            $("#status1").remove();
            $.ajax({
                url: './send.php',
                method: 'POST',
                datatType: "json",

                data: {
                    name: name,
                    email: email,
                    subject: subject,
                    message: message
                },
                success: function(response){
                    if (response == "OK") {
                        $("#status1").html("<small style= 'color: red;'>All Fields are Mandotory!</small>");
                        //$("#success").html("<small style= 'color: red;' >Message Sent Successfully. We will reach  to you soon ! </small>");
                        
                    } else if (response == "FAILED") {
                       // $("#success").html("<small style= 'color: green;'>Opps! something went wrong. Try again later. </small>");
                       $("#status1").html("<small style= 'color: red;'>All Fields are Mandotory!</small>");
                    }
                }
            });
        }
}

});