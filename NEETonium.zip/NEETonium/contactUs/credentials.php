<?php
    define("EMAILID",'shanjborse13@gmail.com');
    define("PASSWORD",'Welcome2google');
    
?>