
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="initial-scale=1, minimum-scale=1, width=device-width">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <title>contactUs_phpmailer</title>
    </head>
    <body>
         
    <!--Start contact us-->
        <div class="container mt-4 " id="contactUs">
            <h2 class="text-center mb-4">Contact Us</h2>
            <h5 class="text-center text-success" id="success"></h5>
            <div class="row">
                <div class="col-md-10 mb-14 mt-5 ">
                    
                    <form action="" method="POST">

                        <span id="status1"></span>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Name"><br/>    
                        <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject"><br/>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Email"><br/>
                        <textarea class="form-control" name="message" id="message" placeholder="How can I help you ? " style="height:100px;"></textarea><br/>
                        <input class="btn btn-primary btn-block" type="button" value="Send" name="sendmail" id="sendmail"><br><br>
                    </form>
                </div>
                
            </div>  
        </div>
    <!--End contact us-->

    </body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="./contactUs/send.js"></script>
</html>
