 <!--Start Subject cards-->
 <div class="container mt-5 subjets-card">
       <h1 class="text-center">Subjects</h1>
        <div class="row">
            <div class="col-lg-6 mb-4">
                <div class="card mt-4">
                    <img class="card-img-top img-thumbnail" src="./resources/image/physics-icon.jpg" alt="The Physics icon">
  
                    <div class="card-body">
                        <h5 class="card-title">Daily Dose</h5>
                        <p class="card-text">
                           Multiple Choice Question.
                        </p>
  
                        <a href="chapters.php" class="btn btn-outline-primary btn-sm">
                            Start
                        </a>
                        <a href="#" class="btn btn-outline-secondary btn-sm">
                            <i class="far fa-heart"></i></a>
                    </div>
                </div>
            </div>  
            <div class="col-lg-6 mb-4">
                <div class="card mt-4">
                    <img class="card-img-top img-thumbnail" src="./resources/image/physics-icon.jpg" src="" alt="">
  
                    <div class="card-body">
                        <h5 class="card-title">Physics</h5>
                        <p class="card-text">
                           Multiple Choice Question.
                        </p>
  
                        <a href="chapters.php" class="btn btn-outline-primary btn-sm">
                            Card link
                        </a>
                        <a href="#" class="btn btn-outline-secondary btn-sm">
                            <i class="far fa-heart"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 mb-4">
                <div class="card mt-4">
                    <img class="card-img-top img-thumbnail" src="./resources/image/Chemistry-icon.jpg" src="" alt="">
  
                    <div class="card-body">
                        <h5 class="card-title">Chemistry</h5>
                        <p class="card-text">
                           Multiple Choice Question.
                        </p>
  
                        <a href="chapters.php" class="btn btn-outline-primary btn-sm">
                            Card link
                        </a>
                        <a href="#" class="btn btn-outline-secondary btn-sm">
                            <i class="far fa-heart"></i></a>
                    </div>
                </div>
            </div>  
            <div class="col-lg-6 mb-4">
                <div class="card mt-4">
                    <img class="card-img-top img-thumbnail" src="./resources/image/biology-icon.jpg" src="" alt="">
  
                    <div class="card-body">
                        <h5 class="card-title">Biology</h5>
                        <p class="card-text">
                            Some quick example text to build on the 
                            
                        </p>
                          
                        <a href="chapters.php" class="btn btn-outline-primary btn-sm">
                            Card link
                        </a>
                        <a href="#" class="btn btn-outline-secondary btn-sm">
                            <i class="far fa-heart"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--End Subject cards-->