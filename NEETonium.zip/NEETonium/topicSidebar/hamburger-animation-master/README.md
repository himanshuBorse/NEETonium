# hamburger-animation
From my YouTube video: https://youtu.be/dIyVTjJAkLw
