<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!--start quiz box-->
    <div class="quiz_box">
        <header>
            <div class="title"> The Keyword quiz</div>
        </header>
        <section>
            <div class="que_text">
            
            </div>
            <div class="option_list">
            
            </div>
        </section>

        <footer>
            <div class="total_que">
            
            </div>
            <button class="next_btn">Next</button>
        </footer>
    </div>


    <!--End quiz box-->
</body>
</html>